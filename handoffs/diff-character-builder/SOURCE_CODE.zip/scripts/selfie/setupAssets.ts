import {mkdir,copyFile,writeFile,readFile} from 'node:fs/promises';import {createHash} from 'node:crypto';
const root='assets/selfie/v1',pkg='node_modules/@mediapipe/tasks-vision';await mkdir(root+'/wasm',{recursive:true});
await copyFile(pkg+'/vision_bundle.mjs',root+'/vision_bundle.mjs');
for(const base of ['vision_wasm_internal','vision_wasm_module_internal','vision_wasm_nosimd_internal'])for(const ext of ['js','wasm'])await copyFile(pkg+'/wasm/'+base+'.'+ext,root+'/wasm/'+base+'.'+ext);
const modelUrl='https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';
try{await readFile(root+'/face_landmarker.task');}catch{const r=await fetch(modelUrl);if(!r.ok)throw Error('Model download failed '+r.status);const bytes=Buffer.from(await r.arrayBuffer());if(bytes.length<1000000||bytes.indexOf(Buffer.from([80,75,3,4]))!==2)throw Error('Unexpected model archive');await writeFile(root+'/face_landmarker.task',bytes);}
if(createHash('sha256').update(await readFile(root+'/face_landmarker.task')).digest('hex')!=='64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff')throw Error('Model checksum mismatch');
const hairModelUrl='https://storage.googleapis.com/mediapipe-models/image_segmenter/hair_segmenter/float32/1/hair_segmenter.tflite';
try{await readFile(root+'/hair_segmenter.tflite');}catch{const response=await fetch(hairModelUrl);if(!response.ok)throw Error('Hair model download failed');await writeFile(root+'/hair_segmenter.tflite',Buffer.from(await response.arrayBuffer()));}
if(createHash('sha256').update(await readFile(root+'/hair_segmenter.tflite')).digest('hex')!=='2628cf3ce5f695f604cbea2841e00befcaa3624bf80caf3664bef2656d59bf84')throw Error('Hair model checksum mismatch');
const license=await fetch('https://raw.githubusercontent.com/google-ai-edge/mediapipe/master/LICENSE');if(!license.ok)throw Error('License download failed');await writeFile(root+'/LICENSE.txt',await license.text());
const files=['vision_bundle.mjs','face_landmarker.task','hair_segmenter.tflite',...['vision_wasm_internal','vision_wasm_module_internal','vision_wasm_nosimd_internal'].flatMap(n=>['wasm/'+n+'.js','wasm/'+n+'.wasm'])],inventory=[];
for(const f of files){const bytes=await readFile(root+'/'+f);inventory.push({file:f,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});}
await writeFile(root+'/manifest.json',JSON.stringify({package:'@mediapipe/tasks-vision',version:'1.0.1',modelUrl,hairModelUrl,files:inventory},null,2));console.log(inventory.map(f=>({file:f.file,bytes:f.bytes})));
