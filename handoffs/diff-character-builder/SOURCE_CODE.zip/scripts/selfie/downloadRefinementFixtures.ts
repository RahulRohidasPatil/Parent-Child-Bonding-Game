import {mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const root='artifacts/selfie/refinement/';await mkdir(root,{recursive:true});
const sources=[];
for(const [id,title] of [['ride','Sally_Ride_in_1984.jpg'],['bluford','Guion_Bluford.jpg']]){
 const page='https://commons.wikimedia.org/wiki/File:'+title;
 const response=await fetch(page);if(!response.ok)throw Error('Source page '+response.status);
 const html=await response.text();
 // Bluford's full scan exceeds the app's 40 MP input limit; use the published 1200px derivative.
 const pattern=id==='bluford'?/<a href="([^"]+)"[^>]*>960 × 1,200 pixels<\/a>/:/<a href="([^"]+)"[^>]*>Original file<\/a>/;
 const url=html.match(pattern)?.[1]?.replaceAll('&amp;','&');if(!url)throw Error('Missing documented image link '+id);
 const r=await fetch(url);if(!r.ok)throw Error(id+': '+r.status);
 const bytes=Buffer.from(await r.arrayBuffer());await writeFile(root+id+'.jpg',bytes);
 sources.push({id,page,url,credit:'NASA, public domain (see source page)',bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
 await writeFile(root+'sources.json',JSON.stringify(sources,null,2));console.log(id,bytes.length);
}
