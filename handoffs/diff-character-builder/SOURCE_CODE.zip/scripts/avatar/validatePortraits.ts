import {readFile,readdir,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {portraitManifest,renderPortrait} from '../../src/portrait/render.js';
import {DEFAULT_PORTRAIT,PORTRAIT_SLOTS,PortraitConfig,PortraitManifest,validatePortrait} from '../../src/portrait/model.js';
export function randomPortrait(m:PortraitManifest,seed:number):PortraitConfig{let state=seed>>>0;const rand=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};const c=structuredClone(DEFAULT_PORTRAIT);c.skin=m.skins[Math.floor(rand()*12)].id as PortraitConfig['skin'];for(const slot of PORTRAIT_SLOTS){const items=m.cosmetics.filter(a=>a.slot===slot);c.equipment[slot]=items[Math.floor(rand()*items.length)].id;if(['hat','glasses','earrings','jacket'].includes(slot)&&rand()<.5)(c.equipment as Record<string,string|null>)[slot]=null;}return c;}
export async function validatePortraitPack(){
 const m=await portraitManifest(),root='assets/avatar/atelier-r3',files=new Set<string>();
 if(m.version!==3||m.size!==128||m.rig!=='front_idle_atelier_v1')throw new Error('Wrong pack protocol');
 if(new Set(m.cosmetics.map(c=>c.id)).size!==m.cosmetics.length)throw new Error('Duplicate cosmetic IDs');
 for(const l of [...m.skins.map(s=>s.layer),...m.cosmetics.flatMap(c=>c.layers)]){
  if(l.skinVariants&&m.skins.some(s=>!l.skinVariants?.[s.id]))throw new Error('Missing skin variant '+l.file);
  for(const f of new Set([l.file,...Object.values(l.skinVariants??{})])){
   files.add(f);if(!/^layers\/[a-z0-9_]+_v3\.png$/.test(f))throw new Error('Bad filename '+f);
   const bytes=await readFile(`${root}/${f}`),p=PNG.sync.read(bytes),[x,y,w,h]=m.regions[l.region];let count=0;
   if(p.width!==128||p.height!==128||p.colorType!==6)throw new Error('Invalid RGBA dimensions '+f);
   for(let yy=0;yy<128;yy++)for(let xx=0;xx<128;xx++){const a=p.data[(yy*128+xx)*4+3];if(a&&a!==255)throw new Error('Blurred alpha '+f);if(a){count++;if(xx<x||xx>=x+w||yy<y||yy>=y+h)throw new Error(`${f} forbidden pixel ${xx},${yy}`);}}
   if(!count||count===16384)throw new Error('Missing transparency or empty image '+f);
   if(f===l.file&&createHash('sha256').update(bytes).digest('hex')!==l.sha256)throw new Error('Changed compiled layer '+f);
  }
  if(!Object.values(m.sources).includes(l.source))throw new Error('Unlisted source '+l.source);
  for(const spec of l.hide??[]){const [region,mask]=spec.split(':');if(!m.regions[region]||!m.masks[mask])throw new Error('Bad mask metadata '+spec);}
 }
 for(const f of await readdir(`${root}/layers`))if(!files.has('layers/'+f))throw new Error('Orphaned layer '+f);
 for(const [f,old] of Object.entries(m.inherited))if(!(await readFile(`${root}/${f}`)).equals(await readFile(old)))throw new Error('Accepted artwork changed '+f);
 for(const [path,hash] of Object.entries(m.pictureHashes))if(createHash('sha256').update(await readFile(path)).digest('hex')!==hash)throw new Error('Source changed '+path);
 validatePortrait(DEFAULT_PORTRAIT,m);return{modules:m.cosmetics.length,heads:m.cosmetics.filter(c=>c.slot==='head').length,skins:12,layerFiles:files.size,inheritedFiles:Object.keys(m.inherited).length};
}
if(process.argv[1]&&/validatePortraits\.(ts|js)$/.test(process.argv[1])){const summary=await validatePortraitPack(),m=await portraitManifest(),started=Date.now();for(let i=0;i<5000;i++){const r=await renderPortrait(randomPortrait(m,9001+i));const p=PNG.sync.read(r.png);if(p.width!==128||p.height!==128)throw new Error('Invalid composite dimensions');for(let j=3;j<p.data.length;j+=4)if(p.data[j]!==0&&p.data[j]!==255)throw new Error('Corrupt composite alpha');}const report={...summary,randomRenders:5000,failures:0,seconds:(Date.now()-started)/1000};await mkdir('artifacts/avatar-faces-v3',{recursive:true});await writeFile('artifacts/avatar-faces-v3/validation.json',JSON.stringify(report,null,2));console.log(report);}
