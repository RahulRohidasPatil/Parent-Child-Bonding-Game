import {mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION} from '../../src/collection/model.js';
const root='assets/avatar/atelier-r6/previews/secondary-colors';await mkdir(root,{recursive:true});const m=await collectionManifest();
for(const slot of ['top','jacket','bottom','shoes','glasses','earrings']){
 const items=m.cosmetics.filter(c=>c.slot===slot&&c.layers.some(l=>l.accentMask)),w=192,h=192,out=new Raster(6*w,Math.ceil(items.length/6)*h);if(!items.length)continue;out.rect(0,0,out.width,out.height,[238,240,232,255]);
 const rows=[];for(let i=0;i<items.length;i++){const c=items[i],config={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,[slot]:c.id},wearColors:{...DEFAULT_COLLECTION.wearColors,[slot]:'wear.navy' as const},wearAccentColors:{...DEFAULT_COLLECTION.wearAccentColors,[slot]:'wear.cream' as const}},p=decodePng((await renderCollection(config)).png);rows.push({label:c.name,config});const crop=slot==='shoes'?[44,99,3]:slot==='bottom'?[44,67,3]:slot==='top'||slot==='jacket'?[40,29,3]:[40,5,3];for(let y=0;y<h;y++)for(let x=0;x<w;x++){const color=p.pixel(crop[0]+Math.floor(x/crop[2]),crop[1]+Math.floor(y/crop[2]));if(color[3])out.set(i%6*w+x,Math.floor(i/6)*h+y,color);}}
 await writePng(root+'/'+slot+'.png',out);await writeFile(root+'/'+slot+'.json',JSON.stringify(rows,null,2));
}
console.log(root);
