import {readFile,readdir,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {collectionManifest,renderCollection,createCollectionRenderer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,COLLECTION_SLOTS,EYE_COLORS,collectionPresets,validateCollection,type CollectionConfig,type CollectionManifest,type CollectionSlot} from '../../src/collection/model.js';
import {checkPng} from './validateExact.js';
import {decodePng} from '../../src/avatar/raster.js';
import {WEAR_SLOTS,WEAR_COLOR_IDS} from '../../src/collection/wearPalettes.js';
import {HAIR_COLOR_IDS} from '../../src/collection/hairPalettes.js';
import {uncoveredPixels} from '../../src/collection/coverage.js';
const ROOT='assets/avatar/atelier-r6';const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
export function options(m:CollectionManifest,slot:CollectionSlot){return [null,...m.cosmetics.filter(c=>c.slot===slot).map(c=>c.id)];}
export function randomCollection(m:CollectionManifest,seed:number){let state=Math.imul(seed^(seed>>>16),0x21f0aaad)>>>0;const pick=<T>(a:T[])=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return a[Math.floor(state/4294967296*a.length)];};const c=structuredClone(DEFAULT_COLLECTION);c.skin=pick(m.skins).id as CollectionConfig['skin'];c.eyeColor=pick([...EYE_COLORS]);c.hairColor=pick([...HAIR_COLOR_IDS]);for(const slot of WEAR_SLOTS)c.wearColors[slot]=pick([...WEAR_COLOR_IDS]);for(const slot of COLLECTION_SLOTS)c.equipment[slot]=pick(slot==='head'?options(m,slot).filter(Boolean) as string[]:options(m,slot))!;const tie=m.cosmetics.find(a=>a.id===c.equipment.tie);if(tie?.compatibleTops&&!tie.compatibleTops.includes(c.equipment.top??''))c.equipment.tie=null;return c;}
export async function validateCollectionPack(root=ROOT){
 const renderer=createCollectionRenderer(root),m=await renderer.manifest();if(new Set(m.cosmetics.map(c=>c.id)).size!==m.cosmetics.length)throw Error('Duplicate cosmetic ID');
 const files=new Set<string>();
 for(const l of [...m.skins.map(s=>s.layer),...m.cosmetics.flatMap(c=>c.layers)]){
  const mask=PNG.sync.read(await readFile(`${root}/${m.slotMasks![l.region]}`));
  if(l.skinVariants&&m.skins.some(s=>!l.skinVariants![s.id]))throw Error('Missing skin variant');
  if(l.eyeVariants&&EYE_COLORS.some(e=>!l.eyeVariants![e]))throw Error('Missing eye variant');
  for(const f of new Set([l.file,...Object.values(l.skinVariants??{}),...Object.values(l.eyeVariants??{})])){
   files.add(f);if(!/^layers\/[a-z0-9_]+_v[56]\.png$/.test(f))throw Error('Invalid filename '+f);
   const bytes=await readFile(`${root}/${f}`);checkPng(bytes,f,mask);if(sha(bytes)!==m.compiledHashes![f])throw Error('Changed pixels '+f);
  }
  for(const rule of l.hide??[]){const[region,key]=rule.split(':');if(!m.regions[region]||!m.masks[key])throw Error('Invalid mask '+rule);}
  if(!Object.values(m.sources).includes(l.source))throw Error('Missing source provenance '+l.source);
  if(l.clearanceMask){
   if(!Object.values(m.masks).includes(l.clearanceMask))throw Error('Unknown clearance mask');
   const clearance=decodePng(await readFile(`${root}/${l.clearanceMask}`)),layer=decodePng(await readFile(`${root}/${l.file}`));
   for(let i=3;i<layer.data.length;i+=4)if(layer.data[i]&&clearance.data[i])throw Error('Hair intersects face clearance: '+l.file);
  }
  if(l.accentMask){
   if(!Object.values(m.masks).includes(l.accentMask))throw Error('Unknown accent mask');
   const mask=checkPng(await readFile(`${root}/${l.accentMask}`),l.accentMask),base=decodePng(await readFile(`${root}/${l.file}`));
   for(let i=0;i<16384;i++)if(mask.data[i*4+3]&&!base.data[i*4+3])throw Error('Accent mask leaves geometry');
  }
  if(l.recolor){
   if(!['hair','wear'].includes(l.recolor.family)||!Object.values(m.masks).includes(l.recolor.mask))throw Error('Invalid recolor metadata');
   const role=checkPng(await readFile(`${root}/${l.recolor.mask}`),l.recolor.mask);
   const base=decodePng(await readFile(`${root}/${l.file}`));
   for(let i=0;i<16384;i++)if(role.data[i*4+3]&&!base.data[i*4+3])throw Error('Color mask leaves source geometry');
  }
 }
 for(const f of await readdir(`${root}/layers`))if(!files.has('layers/'+f))throw Error('Orphaned compiled layer '+f);
 for(const c of m.cosmetics.filter(c=>c.slot==='hair'))if(!c.layers.every(l=>l.recolor?.family==='hair'))throw Error('Hairstyle lacks color support: '+c.id);
 for(const c of m.cosmetics.filter(c=>WEAR_SLOTS.includes(c.slot as typeof WEAR_SLOTS[number])&&!c.fixedColors))if(!c.layers.some(l=>l.recolor?.family==='wear'))throw Error('Wearable lacks colors: '+c.id);
 for(const file of new Set([...Object.values(m.masks),...Object.values(m.coverageMasks??{})]))checkPng(await readFile(`${root}/${file}`),file);
 if(!m.coverageMasks?.shoulders)throw Error('Missing shared shoulder coverage mask');
 const shoulders=decodePng(await readFile(`${root}/${m.coverageMasks.shoulders}`));
 for(const c of m.cosmetics.filter(c=>c.slot==='top'||c.slot==='jacket')){
  const front=c.layers.filter(l=>l.z>20);if(!front.length||front.some(l=>l.coverage!=='shoulders'))throw Error('Missing coverage contract '+c.id);
  const missing=uncoveredPixels(shoulders,await Promise.all(front.map(l=>readFile(`${root}/${l.file}`).then(decodePng))));
  if(missing.length)throw Error(`${c.id} exposes ${missing.length} required shoulder pixels: ${JSON.stringify(missing)}`);
  const waistKey=front[0].waistCoverage;
  if(!waistKey||!m.coverageMasks[waistKey])throw Error('Missing waist coverage '+c.id);
  const waist=decodePng(await readFile(`${root}/${m.coverageMasks[waistKey]}`));
  const gaps=uncoveredPixels(waist,await Promise.all(front.map(l=>readFile(`${root}/${l.file}`).then(decodePng))));
  if(gaps.length)throw Error(`${c.id} exposes waistband skin at ${JSON.stringify(gaps)}`);
 }
 for(const[path,hash]of Object.entries(m.pictureHashes))if(sha(await readFile(path))!==hash)throw Error('Source modified '+path);
 for(const[f,path]of Object.entries(m.inherited))if(!(await readFile(`${root}/${f}`)).equals(await readFile(path)))throw Error('Inherited image changed '+f);
 const master=await readFile(`${root}/${m.master}`);if(sha(master)!==m.frozenDefaultHash||!(await renderer.render(DEFAULT_COLLECTION)).png.equals(master))throw Error('Approved base appearance changed');
 for(const p of collectionPresets())validateCollection(p.config,m);
 return{modules:m.cosmetics.length,clothing:m.cosmetics.filter(c=>['top','jacket','bottom','shoes'].includes(c.slot)).length,layers:files.size,heads:m.cosmetics.filter(c=>c.slot==='head').length};
}
export async function validateCombinationGroups(){
 const m=await collectionManifest(),counts:Record<string,number>={clothing:0,face:0,headgear:0,skin:0,random:0};
 const check=async(c:CollectionConfig,group:string)=>{const rendered=await renderCollection(c);if(rendered.warnings.length)throw Error('Unexpected fallback in '+group);checkPng(rendered.png,group+' '+counts[group]);counts[group]++;};
 const equip=(e:Partial<CollectionConfig['equipment']>)=>({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,...e}});
 for(const top of options(m,'top'))for(const jacket of options(m,'jacket'))for(const bottom of options(m,'bottom'))for(const shoes of options(m,'shoes'))await check(equip({top,jacket,bottom,shoes}),'clothing');
 for(const head of options(m,'head').filter(Boolean) as string[])for(const ears of options(m,'ears'))for(const eyes of options(m,'eyes'))for(const brows of options(m,'brows'))for(const nose of options(m,'nose'))for(const mouth of options(m,'mouth'))await check(equip({head,ears,eyes,brows,nose,mouth}),'face');
 for(const head of options(m,'head').filter(Boolean) as string[])for(const hair of options(m,'hair'))for(const hat of options(m,'hat'))for(const glasses of options(m,'glasses'))await check(equip({head,hair,hat,glasses}),'headgear');
 for(const s of m.skins)for(const head of options(m,'head').filter(Boolean) as string[])for(const top of [null,...m.cosmetics.filter(c=>c.slot==='top').map(c=>c.id)])await check({...equip({head,top}),skin:s.id as CollectionConfig['skin']},'skin');
 for(let i=0;i<5000;i++)await check(randomCollection(m,51000+i),'random');return counts;
}
if(process.argv[1]&&/validateCollection\.(ts|js)$/.test(process.argv[1])){const start=Date.now(),pack=await validateCollectionPack(),combinations=await validateCombinationGroups();const report={...pack,combinations,total:Object.values(combinations).reduce((a,b)=>a+b,0),failures:0,approvedDefaultUnchanged:true,seconds:(Date.now()-start)/1000};await mkdir('artifacts/avatar-revision-v6/qa',{recursive:true});await writeFile('artifacts/avatar-revision-v6/qa/validation.json',JSON.stringify(report,null,2));console.log(report);}
