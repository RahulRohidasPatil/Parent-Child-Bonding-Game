import { access } from 'node:fs/promises';
import { ASSETS, assetFile } from '../../src/avatar/manifest.js';
import { SLOT_MASKS } from '../../src/avatar/rig.js';
import { readPng } from '../../src/avatar/raster.js';
import { CHECKPOINT_VARIANTS } from '../../src/avatar/schema.js';
import { renderAvatar } from '../../src/avatar/renderer.js';

const errors: string[] = [];

for (const asset of ASSETS) {
  if (!/^[a-z0-9_./{}-]+$/.test(asset.file)) errors.push(`${asset.id}: filename must be lowercase snake_case.`);
  if (!SLOT_MASKS[asset.slot] || SLOT_MASKS[asset.slot].id !== asset.mask) errors.push(`${asset.id}: invalid slot mask ${asset.mask}.`);
  for (const color of asset.colors) {
    const path = assetFile(asset, color);
    try { await access(path); } catch { errors.push(`${asset.id}: missing ${path}.`); continue; }
    const image = await readPng(path);
    if (image.width !== 128 || image.height !== 128) errors.push(`${path}: expected 128×128.`);
    if (image.partialAlphaPixels()) errors.push(`${path}: partial alpha is forbidden.`);
    let transparent = 0;
    let opaque = 0;
    for (let y = 0; y < 128; y += 1) for (let x = 0; x < 128; x += 1) {
      const alpha = image.pixel(x, y)[3];
      if (alpha === 0) transparent += 1;
      if (alpha === 255) {
        opaque += 1;
        if (!SLOT_MASKS[asset.slot].containsLogical(Math.floor(x / 2), Math.floor(y / 2))) errors.push(`${path}: pixel escaped ${asset.mask} at ${x},${y}.`);
      }
    }
    if (!transparent || !opaque) errors.push(`${path}: layer must contain both transparent and opaque pixels.`);
  }
}

for (const [name, config] of Object.entries(CHECKPOINT_VARIANTS)) {
  try {
    const rendered = await renderAvatar(config);
    if (rendered.raster.width !== 128 || rendered.raster.height !== 128) errors.push(`${name}: wrong output size.`);
    if (rendered.raster.partialAlphaPixels()) errors.push(`${name}: partial alpha after rendering.`);
  } catch (error) { errors.push(`${name}: ${(error as Error).message}`); }
}

if (errors.length) {
  console.error(`Validation failed with ${errors.length} error(s).`);
  for (const error of errors.slice(0, 100)) console.error(`- ${error}`);
  process.exitCode = 1;
} else {
  console.log(`Validated ${ASSETS.reduce((sum, asset) => sum + asset.colors.length, 0)} isolated production layers and ${Object.keys(CHECKPOINT_VARIANTS).length} checkpoint renders at 128×128.`);
}
