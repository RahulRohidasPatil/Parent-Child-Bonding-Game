import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { ASSETS, assetFile } from '../../src/avatar/manifest.js';
import { createImagegenAsset } from '../../src/avatar/imageSources.js';
import { CANVAS, HAIR_VISIBILITY_MASKS, LANDMARKS, LAYER_ORDER, LOGICAL_CANVAS, RIG_ID, SCALE, SLOT_MASKS } from '../../src/avatar/rig.js';
import { Raster, writePng } from '../../src/avatar/raster.js';
import { CHECKPOINT_VARIANTS } from '../../src/avatar/schema.js';
import { renderAvatar } from '../../src/avatar/renderer.js';

const root = process.cwd();
const avatarRoot = resolve(root, 'assets/avatar/v1');

async function json(path: string, value: object): Promise<void> { await mkdir(dirname(path), { recursive: true }); await writeFile(path, `${JSON.stringify(value, null, 2)}\n`); }

function logicalMask(predicate: (x: number, y: number) => boolean): Raster {
  const logical = new Raster(LOGICAL_CANVAS, LOGICAL_CANVAS);
  for (let y = 0; y < LOGICAL_CANVAS; y += 1) for (let x = 0; x < LOGICAL_CANVAS; x += 1) if (predicate(x, y)) logical.set(x, y, [255, 255, 255, 255]);
  return logical.upscale(SCALE);
}

function gridOverlay(base: Raster): Raster {
  const output = new Raster(CANVAS, CANVAS); output.blit(base);
  const grid: [number, number, number, number] = [57, 255, 122, 255];
  const anchor: [number, number, number, number] = [59, 130, 246, 255];
  for (let x = 0; x < CANVAS; x += 8) output.line(x, 0, x, 127, grid);
  for (let y = 0; y < CANVAS; y += 8) output.line(0, y, 127, y, grid);
  for (const y of [LANDMARKS.headTop, LANDMARKS.eyeY, LANDMARKS.shoulderY, LANDMARKS.waistY, LANDMARKS.kneeY, LANDMARKS.footBaseline]) output.line(0, y, 127, y, anchor);
  output.line(LANDMARKS.centerX, 0, LANDMARKS.centerX, 127, anchor);
  return output;
}

function maskPreview(): Raster {
  const output = new Raster(CANVAS, CANVAS);
  const colors: Array<[number, number, number, number]> = [[57,255,122,255],[59,130,246,255],[237,112,91,255],[234,179,8,255],[168,85,247,255]];
  let index = 0;
  for (const slot of ['body_skin','bottoms','shoes','top','outerwear','hair_back','hair_front','eyes','brows','mouth','glasses','headwear'] as const) {
    const color = colors[index++ % colors.length]; const mask = SLOT_MASKS[slot];
    for (let y = 0; y < LOGICAL_CANVAS; y += 1) for (let x = 0; x < LOGICAL_CANVAS; x += 1) if (mask.containsLogical(x, y) && (x + y) % 3 === 0) output.rect(x * 2, y * 2, 2, 2, color);
  }
  return output;
}

async function main(): Promise<void> {
  for (const asset of ASSETS) for (const color of asset.colors) {
    await writePng(resolve(root, assetFile(asset, color)), await createImagegenAsset(asset.id, color));
  }

  for (const mask of Object.values(SLOT_MASKS)) await writePng(join(avatarRoot, 'masks', `${mask.id}.png`), logicalMask(mask.containsLogical));
  for (const [id, mask] of Object.entries(HAIR_VISIBILITY_MASKS)) await writePng(join(avatarRoot, 'masks', `${id}.png`), logicalMask(mask));

  const master = await createImagegenAsset('body.skin', 'skin_04');
  await writePng(join(avatarRoot, 'master/avatar_master_v1.png'), master);
  await writePng(join(avatarRoot, 'master/avatar_master_grid_v1.png'), gridOverlay(master));
  await writePng(join(avatarRoot, 'master/avatar_master_masks_v1.png'), maskPreview());

  await json(join(avatarRoot, 'avatar-rig-v1.json'), { version: 1, id: RIG_ID, locked: true, canvas: { width: CANVAS, height: CANVAS, rgba: true, transparent: true }, logicalCanvas: LOGICAL_CANVAS, scale: SCALE, landmarks: LANDMARKS, layers: LAYER_ORDER, slotMasks: Object.fromEntries(Object.entries(SLOT_MASKS).map(([slot, mask]) => [slot, mask.id])), transform: { x: 0, y: 0, rotation: 0, scale: 1 } });
  await json(join(avatarRoot, 'avatar-manifest-v1.json'), { version: 1, rig: RIG_ID, assets: ASSETS });
  await json(join(avatarRoot, 'presets/checkpoint-configs-v1.json'), CHECKPOINT_VARIANTS);

  const names = Object.keys(CHECKPOINT_VARIANTS);
  for (const [name, config] of Object.entries(CHECKPOINT_VARIANTS)) {
    const rendered = await renderAvatar(config);
    await writePng(join(avatarRoot, 'previews/checkpoint', '128', `${name}.png`), rendered.raster);
  }

  const sheet = new Raster(names.length * 132 + 8, 136);
  // Raster intentionally exposes only transform-free avatar blits. Build the sheet by copying pixels explicitly.
  for (let index = 0; index < names.length; index += 1) {
    const rendered = await renderAvatar(CHECKPOINT_VARIANTS[names[index]], { size: 128 });
    for (let y = 0; y < 128; y += 1) for (let x = 0; x < 128; x += 1) { const pixel = rendered.raster.pixel(x, y); if (pixel[3]) sheet.set(4 + index * 132 + x, 4 + y, pixel); }
  }
  await writePng(join(avatarRoot, 'previews/checkpoint/checkpoint_all_variants.png'), sheet);
  console.log(`Built ${ASSETS.length} Imagegen-backed definitions, ${ASSETS.reduce((sum, asset) => sum + asset.colors.length, 0)} production PNG layers and 7 renders at 128×128.`);
}

await main();
