import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {PNG} from 'pngjs';
import {Raster,writePng} from '../../src/avatar/raster.js';
const source=PNG.sync.read(await readFile('references/avatar-exact-v5/body-reference.png'));
const root='artifacts/avatar-exact-v5/recovery';await mkdir(root,{recursive:true});
function recover(dx:number,dy:number,refined=false){const out=new Raster(128,128),mask=new Uint8Array(16384);for(let y=0;y<128;y++)for(let x=0;x<128;x++){
 let sx=Math.floor((x-40+.5)*15.2+dx),sy=Math.floor((y+.5)*15.2+dy);
 if(refined&&x>=62&&x<=66&&y>=29&&y<=31){sx+=4;sy=[442,455,467][y-29];}
 if(refined&&y===122)sy=1854;
 if(sx<0||sx>=source.width||sy<0||sy>=source.height)continue;
 const i=(sy*source.width+sx)*4,[r,g,b]=source.data.subarray(i,i+3),dark=Math.max(r,g,b)<23,warm=r>g+7&&r>b+7,blue=b>r+7&&b>g+3;
 const head=y<=39&&x>=47&&x<=83&&(warm||dark);
 const cloth=y>=35&&y<=114&&x>=(refined&&y>=77?52:43)&&x<=(refined&&y>=77?77:85)&&(blue||dark);
 const hand=y>=70&&y<=77&&((x>=49&&x<=57)||(x>=71&&x<=80))&&((warm&&(!refined||r>160))||dark);
 const shoes=y>=112&&y<=125&&x>=44&&x<=83&&dark;
 if(head||cloth||hand||shoes)mask[y*128+x]=1;
 out.set(x,y,[r,g,b,255]);
 }
 if(refined)for(let y=112;y<=122;y++)for(const [x0,x1]of [[46,64],[65,84]]){let lo=128,hi=-1;for(let x=x0;x<=x1;x++){const c=out.pixel(x,y);if(c[3]&&Math.max(...c.slice(0,3))<23){lo=Math.min(lo,x);hi=Math.max(hi,x);}}if(hi>=lo)for(let x=lo;x<=hi;x++)mask[y*128+x]=1;}
 // Enclosed holes are interior artwork (eye whites, shoe planes), never a matte-color flood.
 const seen=new Uint8Array(16384),q=[0];seen[0]=1;for(let i=0;i<q.length;i++){const p=q[i],x=p%128,y=Math.floor(p/128);for(const [xx,yy]of [[x-1,y],[x+1,y],[x,y-1],[x,y+1]])if(xx>=0&&xx<128&&yy>=0&&yy<128){const j=yy*128+xx;if(!mask[j]&&!seen[j]){seen[j]=1;q.push(j);}}}
 for(let i=0;i<16384;i++){if(seen[i])out.data.fill(0,i*4,i*4+4);else mask[i]=1;}
 return out;
}
const samples=[[-3,-3],[-5,-5],[0,0],[-3,-5]];
for(let i=0;i<samples.length;i++){const[dx,dy]=samples[i],r=recover(dx,dy);await writePng(`${root}/candidate_${i}.png`,r);await writePng(`${root}/candidate_${i}_review.png`,r.upscale(4));}
const master=recover(0,0,true);await writePng(`${root}/master.png`,master);await writePng(`${root}/master_review.png`,master.upscale(4));
await writeFile(`${root}/grid.json`,JSON.stringify({source:'references/avatar-exact-v5/body-reference.png',pitchX:15.2,pitchY:15.2,canvasX:40,selectedPhase:[0,0],samples,sourceSamplingCalibration:{mouth:{canvas:[62,29,5,3],sourceXAdjustment:4,sourceRows:[442,455,467]},sole:{canvasRow:122,sourceRow:1854}},note:'Screenshot grid recovery. These are offline source-sampling coordinates, never renderer offsets.'},null,2));
