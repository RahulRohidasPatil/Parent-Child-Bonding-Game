import {mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION} from '../../src/collection/model.js';
import {HAIR_PALETTES,HAIR_COLOR_STYLE} from '../../src/collection/hairPalettes.js';
const root='artifacts/avatar-hair-colors';await mkdir(root,{recursive:true});
const sheet=new Raster(768,720);sheet.rect(0,0,768,720,[238,240,232,255]);
for(let i=0;i<HAIR_PALETTES.length;i++){
 const palette=HAIR_PALETTES[i],c={...DEFAULT_COLLECTION,hairColor:palette.id},p=decodePng((await renderCollection(c)).png);
 await writePng(`${root}/${palette.id.replace('.','_')}.png`,p);
 for(let y=0;y<240;y++)for(let x=0;x<192;x++){const color=p.pixel(48+Math.floor(x/6),Math.floor(y/6));if(color[3])sheet.set((i%4)*192+x,Math.floor(i/4)*240+y,color);}
}
await writePng(`${root}/12_hair_colors.png`,sheet);
await writeFile(`${root}/index.json`,JSON.stringify({hairstyle:HAIR_COLOR_STYLE,order:'left to right, top to bottom',colors:HAIR_PALETTES.map(({id,name})=>({id,name}))},null,2));
console.log(root+'/12_hair_colors.png');
