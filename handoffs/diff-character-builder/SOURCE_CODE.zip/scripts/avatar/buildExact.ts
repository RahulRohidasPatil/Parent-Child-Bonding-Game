import {mkdir,readFile,writeFile,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {Raster,decodePng,writePng,encodePng} from '../../src/avatar/raster.js';
import {fit,bounds,type Box} from '../../src/atelier/pixels.js';
import {rawSource,isolatedSource,irisPalette} from '../../src/refined/authoring.js';
import {EYE_COLORS} from '../../src/refined/model.js';
import type {PortraitManifest} from '../../src/portrait/model.js';
import type {ExactManifest,ExactLayer,ExactCosmetic} from '../../src/exact/model.js';
import {partitionMaster,LABELS,skinVariant,textureToTemplate,resampleSupport,clipTo} from '../../src/exact/authoring.js';
const ROOT='assets/avatar/atelier-r5',OLD='assets/avatar/atelier-r3',REF='references/avatar-exact-v5';
const old=JSON.parse(await readFile(`${OLD}/manifest.json`,'utf8')) as PortraitManifest;
const master=decodePng(await readFile('artifacts/avatar-exact-v5/recovery/master.png')),parts=partitionMaster(master),sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const regions:ExactManifest['regions']={body:[43,33,44,91],head:[47,2,36,33],hair_front:[43,0,43,70],hair_back:[43,0,43,70],eyes:[56,19,18,5],brows:[55,17,20,3],nose:[61,22,6,7],mouth:[61,29,7,3],ears:[48,19,35,11],top:[43,33,44,43],top_back:[48,29,34,20],jacket:[43,33,44,45],jacket_back:[48,29,34,20],bottom:[49,72,32,44],shoes:[43,112,43,12],glasses:[53,19,24,7],headwear:[47,0,35,21],earrings:[49,23,32,8]};
const m:ExactManifest={version:5,pack:'atelier-r5',rig:'front_reference_v1',size:128,cosmetics:[],skins:[],regions,masks:{},sources:{},pictureHashes:{},inherited:{},faceSources:{},eyeColorSources:{},normalization:{method:'Reference pixel recovery; shared geometry, no independent facial enlargement',grid:'artifacts/avatar-exact-v5/recovery/grid.json',irisPixels:[[60,22],[69,22]]},master:'rig/reference_master.png',masterHash:sha(encodePng(master)),partitionMasks:{}};
await mkdir(`${ROOT}/layers`,{recursive:true});await mkdir(`${ROOT}/rig`,{recursive:true});await mkdir(`${ROOT}/masks`,{recursive:true});
const reference=`${REF}/body-reference.png`;
async function source(path:string){if(!m.pictureHashes[path]){m.sources[path.split('/').at(-1)!.replace('.png','')]=path;m.pictureHashes[path]=sha(await readFile(path));}return path;}
async function write(id:string,r:Raster,region:string,path:string,z:number):Promise<ExactLayer>{await source(path);const file=`layers/${id.replace(/[.-]/g,'_')}_v5.png`,[x,y,w,h]=regions[region];let n=0;for(let yy=0;yy<128;yy++)for(let xx=0;xx<128;xx++)if(r.pixel(xx,yy)[3]){n++;if(xx<x||xx>=x+w||yy<y||yy>=y+h)throw new Error(`${id} outside ${region} at ${xx},${yy}`);}if(!n)throw new Error('Empty '+id);await writePng(`${ROOT}/${file}`,r);return{file,z,region,source:path,sha256:sha(await readFile(`${ROOT}/${file}`))};}
async function skinLayers(id:string,r:Raster,region:string,path:string,z:number){const layers:ExactLayer[]=[];for(const skin of old.skins)layers.push(await write(id+'_'+skin.id,skinVariant(r,skin.id),region,path,z));const l=layers[1];l.skinVariants=Object.fromEntries(old.skins.map((s,i)=>[s.id,layers[i].file]));return l;}
async function oldImage(c:ExactCosmetic){await source(c.layers[0].source);return decodePng(await readFile(`${OLD}/${c.layers[0].skinVariants?.skin_02??c.layers[0].file}`));}
async function referenceHoodie(){
 const raw=(await rawSource(`${REF}/forest-reference.png`)).r,out=new Raster(raw.width,raw.height);
 for(let y=515;y<=1225;y++){
  const xs:number[]=[];
  for(let x=60;x<raw.width-40;x++){const p=raw.pixel(x,y);if(p[1]>p[0]*1.25&&p[1]>p[2]*1.15&&p[1]>30)xs.push(x);}
  if(!xs.length)continue;
  for(let x=xs[0]-12;x<=xs.at(-1)!+12;x++){const p=raw.pixel(x,y);if(!(p[0]>p[1]+10&&p[0]>90))out.set(x,y,[p[0],p[1],p[2],255]);}
 }
 return out;
}
function clone(r:Raster){const p=new Raster(128,128);p.data.set(r.data);return p;}
function regionMask(r:Raster,b:Box){for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(x<b[0]||x>=b[0]+b[2]||y<b[1]||y>=b[1]+b[3])r.set(x,y,[0,0,0,0]);return r;}
await source(reference);await writePng(`${ROOT}/${m.master}`,master);
for(const label of LABELS){const file=`masks/reference_${label}_v5.png`;await writePng(`${ROOT}/${file}`,parts[label]);m.partitionMasks[label]=file;}
const bodySupportPath=`${REF}/body-support.png`,headSupportPath=`${REF}/blank-head-support.png`;
await source(bodySupportPath);await source(headSupportPath);
const body=resampleSupport((await rawSource(bodySupportPath)).r,master);body.blit(parts.body);
const head=resampleSupport((await rawSource(headSupportPath)).r,master,true);for(let i=3;i<head.data.length;i+=4)if(parts.ears.data[i])head.data.fill(0,i-3,i+1);head.blit(parts.head);
for(const skin of old.skins)m.skins.push({id:skin.id,color:skin.color,layer:await write('body_'+skin.id,skinVariant(body,skin.id),'body',bodySupportPath,20)});
for(const c of old.cosmetics.filter(c=>c.slot==='head')){let r:Raster,path:string;if(c.id==='head.soft_oval'){r=head;path=reference;}else{path=c.layers[0].source;const raw=c.id==='head.angular'?await oldImage(c):(await isolatedSource(path));r=fit(raw,[c.id==='head.narrow'?55:53,5,c.id==='head.narrow'?20:24,29]);
 // A shared attachment patch, sampled from the reference, replaces the old closed jaw outline.
 for(let y=32;y<=33;y++)for(let x=60;x<=69;x++)r.set(x,y,parts.head.pixel(x,y));
 if(c.id==='head.angular')for(let y=5;y<32;y++)for(let x=0;x<128;x++){const p=r.pixel(x,y);if(p[3]&&p[0]>100&&p[0]>p[1]+12)r.set(x,y,p[0]>245?master.pixel(65,25):p[0]>220?master.pixel(70,29):master.pixel(61,33));}
 }m.cosmetics.push({...c,name:c.id==='head.soft_oval'?'Reference head':c.name,layers:[await skinLayers(c.id,r,'head',path,21)]});}
const palettes:Record<string,ReturnType<typeof irisPalette>>={};for(const color of EYE_COLORS){const path=`references/avatar-refinement-v4/eyes-${color==='eye.blue'?'blue-clean':color.replace('eye.','').replace('_','-')}.png`;await source(path);m.eyeColorSources[color]=path;palettes[color]=irisPalette((await rawSource(path)).r,color==='eye.gray');}
for(const c of old.cosmetics.filter(c=>c.slot==='eyes')){let eye=clone(parts.eyes);if(!c.id.endsWith('neutral')){const sampled=textureToTemplate(await oldImage(c),parts.eyes);for(let i=0;i<16384;i++){const j=i*4;if(!eye.data[j+3])continue;const a=eye.pixel(i%128,Math.floor(i/128)),b=sampled.pixel(i%128,Math.floor(i/128));if(Math.max(...a.slice(0,3))<130&&b[3]&&Math.max(...b.slice(0,3))<130)eye.set(i%128,Math.floor(i/128),b);}}
 const variants:ExactLayer[]=[];for(const color of EYE_COLORS){const r=clone(eye);if(color!=='eye.dark_brown')for(const[x,y]of [[60,22],[69,22]])if(r.pixel(x,y)[3])r.set(x,y,palettes[color][1]);variants.push(await write(c.id+'_'+color,r,'eyes',reference,50));}const l=variants[0];l.eyeVariants=Object.fromEntries(EYE_COLORS.map((e,i)=>[e,variants[i].file]));m.cosmetics.push({...c,layers:[l]});}
for(const slot of ['brows','nose','mouth','ears'] as const)for(const c of old.cosmetics.filter(c=>c.slot===slot)){let r=clone(parts[slot]);if(!c.id.endsWith('neutral')&&!(slot==='ears'&&c.id==='ears.small'))r=textureToTemplate(await oldImage(c),parts[slot]);const z={brows:52,nose:53,mouth:54,ears:22}[slot];m.cosmetics.push({...c,layers:[slot==='brows'?await write(c.id,r,slot,reference,z):await skinLayers(c.id,r,slot,reference,z)]});}
for(const c of old.cosmetics.filter(c=>c.slot==='hair')){if(c.id==='hair.textured'){m.cosmetics.push({...c,layers:[await write(c.id,parts.hair,'hair_front',reference,60)]});continue;}const merged=new Raster(128,128);for(const l of c.layers)merged.blit(decodePng(await readFile(`${OLD}/${l.file}`)));const b=bounds(merged),long=c.layers.length>1;let r=fit(merged,[Math.round(64-(b[2]*1.1)/2),2,Math.round(b[2]*1.1),long?Math.round(b[3]*1.12):21]);const layers:ExactLayer[]=[];layers.push(await write(c.id+'_back',r,'hair_back',c.layers[0].source,10));r=clone(r);r.clearRect(55,19,19,16);layers.push(await write(c.id+'_front',r,'hair_front',c.layers[0].source,60));m.cosmetics.push({...c,layers});}
// The reference's clothing silhouette supplies all shoulder, wrist, waist and ankle anchors.
for(const c of old.cosmetics.filter(c=>['top','jacket','bottom','shoes'].includes(c.slot))){const slot=c.slot as 'top'|'jacket'|'bottom'|'shoes';const isReference=c.id==='top.navy'||c.id==='bottom.denim'||c.id==='shoes.black';const template=clone(parts[slot==='jacket'?'top':slot]);let r:Raster,path:string;
 if(isReference){r=template;path=reference;}else{path=c.layers[0].source;let s:Raster;
  if(c.id==='shoes.white'){path='references/avatar-refinement-v4/shoes-white-final.png';s=await isolatedSource(path);}else if(c.id==='top.forest_hoodie'){path=`${REF}/forest-reference.png`;s=await referenceHoodie();}else s=await oldImage(c);
  if(c.id==='top.white_tee'||c.id==='top.polo'){for(let y=52;y<74;y++)for(let x=0;x<128;x++)if(x<55||x>73)template.set(x,y,[0,0,0,0]);}
  r=textureToTemplate(s,template,slot==='jacket');}
 const layers:ExactLayer[]=[];
 if(c.id.includes('hoodie')){const s=await oldImage(c),b=bounds(s),hood=fit(s,[55,33,20,9],[b[0],b[1],b[2],Math.round(b[3]*.25)]);hood.clearRect(58,34,13,10);for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(!master.pixel(x,y)[3]&&y>=37)hood.set(x,y,[0,0,0,0]);layers.push(await write(c.id+'_back',hood,'top_back',c.layers[0].source,15));}
 const front=await write(c.id,r,slot,path,{top:40,jacket:42,bottom:32,shoes:34}[slot]);if(slot==='jacket')front.hide=['top:top_sleeves'];layers.push(front);m.cosmetics.push({...c,layers});}
for(const c of old.cosmetics.filter(c=>['hat','glasses','earrings'].includes(c.slot))){const s=await oldImage(c),r=fit(s,c.slot==='hat'?[49,1,31,19]:c.slot==='glasses'?[54,20,23,6]:[52,25,25,4]);const l=await write(c.id,r,c.slot==='hat'?'headwear':c.slot,c.layers[0].source,{hat:80,glasses:72,earrings:70}[c.slot as 'hat'|'glasses'|'earrings']!);if(c.slot==='hat')l.hide=['hair_front:hair_crown','hair_back:hair_crown'];m.cosmetics.push({...c,layers:[l]});}
const crown=new Raster(128,128);crown.rect(43,0,43,20,[255,255,255,255]);const sleeves=new Raster(128,128);sleeves.rect(43,39,12,37,[255,255,255,255]);sleeves.rect(74,39,13,37,[255,255,255,255]);for(const[id,r]of Object.entries({hair_crown:crown,top_sleeves:sleeves})){const file=`masks/${id}_v5.png`;await writePng(`${ROOT}/${file}`,r);m.masks[id]=file;}
await writeFile(`${ROOT}/rig/coordinates.json`,JSON.stringify({rig:m.rig,size:128,hairTop:2,browLine:18,eyeRows:[20,22],noseRows:[23,27],mouthRows:[29,31],chinLine:33,neckRows:[34,37],shoulderLine:40,waistLine:73,ankleLine:113,footBaseline:122},null,2));
m.slotMasks={};m.compiledHashes={};
for(const [region,b]of Object.entries(regions)){
 const mask=new Raster(128,128);
 if(['eyes','brows','nose','mouth','ears'].includes(region))mask.blit(parts[region as keyof typeof parts]);
 else if(region==='top'||region==='jacket')mask.blit(parts.top);
 else if(region==='bottom')mask.blit(parts.bottom);
 else if(region==='shoes')mask.blit(parts.shoes);
 else mask.rect(...b,[255,255,255,255]);
 const file=`masks/slot_${region}_v5.png`;await writePng(`${ROOT}/${file}`,mask);m.slotMasks[region]=file;
}
for(const l of [...m.skins.map(s=>s.layer),...m.cosmetics.flatMap(c=>c.layers)])for(const f of new Set([l.file,...Object.values(l.skinVariants??{}),...Object.values(l.eyeVariants??{})]))m.compiledHashes[f]=sha(await readFile(`${ROOT}/${f}`));
await writeFile(`${ROOT}/manifest.json`,JSON.stringify(m,null,2));console.log(`${m.cosmetics.length} reference-rig cosmetics built. Default pixels derive from the supplied master.`);
