import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {fit,bounds,type Box} from '../../src/atelier/pixels.js';
import {SKIN_PALETTES} from '../../src/avatar/palettes.js';
import type {PortraitManifest} from '../../src/portrait/model.js';
import {EYE_COLORS,RefinedManifest,RefinedLayer,RefinedCosmetic} from '../../src/refined/model.js';
import {rawSource,isolatedSource,stripMatte,paletteSkin,sourceEye,EYE_GUIDES,FACE_GUIDES,eyeIrisPixels,irisPalette,extractBand,pairBoxes} from '../../src/refined/authoring.js';
const ROOT='assets/avatar/atelier-r4',OLD='assets/avatar/atelier-r3',REF='references/avatar-refinement-v4';
const old=JSON.parse(await readFile(`${OLD}/manifest.json`,'utf8')) as PortraitManifest;
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const m:RefinedManifest={version:4,pack:'atelier-r4',rig:'front_idle_atelier_v2',size:128,cosmetics:[],skins:[],regions:{...old.regions,body:[42,26,44,96],head:[52,7,24,25],brows:[54,17,20,1],eyes:[54,19,20,4],nose:[62,22,5,4],mouth:[61,27,6,3],ears:[51,19,26,7],top_back:[40,26,48,12],jacket_back:[40,26,48,12],shoes:[45,109,38,12]},sources:{},pictureHashes:{},inherited:{},masks:{},faceSources:{},eyeColorSources:{},normalization:{faceGuides:FACE_GUIDES,eyeAlphaGuides:EYE_GUIDES,headBottom:31,neckVisibleRows:[32,33,34,35],footBaseline:120}};
await mkdir(`${ROOT}/layers`,{recursive:true});await mkdir(`${ROOT}/masks`,{recursive:true});
async function register(path:string){if(!m.pictureHashes[path]){m.sources[path.split('/').at(-1)!.replace('.png','')]=path;m.pictureHashes[path]=sha(await readFile(path));}return path;}
async function raw(path:string){await register(path);return(await rawSource(path)).r;}
async function isolated(path:string){await register(path);return isolatedSource(path);}
async function layer(id:string,r:Raster,region:string,path:string,z:number):Promise<RefinedLayer>{await register(path);const file=`layers/${id.replace(/[.-]/g,'_')}_v4.png`,[x,y,w,h]=m.regions[region];let count=0;for(let yy=0;yy<128;yy++)for(let xx=0;xx<128;xx++)if(r.pixel(xx,yy)[3]){count++;if(xx<x||xx>=x+w||yy<y||yy>=y+h)throw new Error(`${id}: forbidden ${region} pixel ${xx},${yy}`);}if(!count)throw new Error('Empty layer '+id);await writePng(`${ROOT}/${file}`,r);return{file,z,region,source:path,sha256:sha(await readFile(`${ROOT}/${file}`))};}
async function skins(id:string,r:Raster,region:string,path:string,z:number,part:'head'|'neck'|'nose'|'mouth'='head'){const all:RefinedLayer[]=[];for(const skin of old.skins)all.push(await layer(id+'_'+skin.id,paletteSkin(r,skin.id,part),region,path,z));const selected=all[1];selected.skinVariants=Object.fromEntries(old.skins.map((s,i)=>[s.id,all[i].file]));return selected;}
async function inherit(c:RefinedCosmetic){const next=structuredClone(c);for(const l of next.layers){const prior=l.file;l.file=prior.replace('_v3.png','_v4.png');await copyFile(`${OLD}/${prior}`,`${ROOT}/${l.file}`);m.inherited[l.file]=`${OLD}/${prior}`;await register(l.source);}return next;}
const neckPath=`${REF}/neck-skin.png`,neck=fit(await isolated(neckPath),FACE_GUIDES.neck);
await writePng(`${ROOT}/masks/neck_coverage_v4.png`,neck);
for(const s of old.skins){const body=decodePng(await readFile(`${OLD}/${s.layer.file}`));body.blit(paletteSkin(neck,s.id,'neck'));m.skins.push({...s,layer:await layer('body_'+s.id,body,'body',neckPath,20)});}
const headGeometry:Record<string,Raster>={};
for(const c of old.cosmetics.filter(c=>c.slot==='head')){
 const prior=decodePng(await readFile(`${OLD}/${c.layers[0].file}`)),box=bounds(prior),target:Box=[box[0],8,box[2],24];let original:Raster;
 if(c.id==='head.angular')original=prior;else original=await isolated(c.layers[0].source);
 const head=fit(original,target);headGeometry[c.id]=head;
 m.cosmetics.push({...c,layers:[await skins(c.id,head,'head',c.layers[0].source,21)]});
}
for(const [id,path]of Object.entries(old.masks)){const file=path.replace('_v3.png','_v4.png');await copyFile(`${OLD}/${path}`,`${ROOT}/${file}`);m.masks[id]=file;m.inherited[file]=`${OLD}/${path}`;}
// Keep the source hair pixels, assigning face-overlapping strands to the back component.
for(const c of old.cosmetics.filter(c=>c.slot==='hair')){
 const next=await inherit(c);if(c.layers.length>1){for(let i=0;i<next.layers.length;i++)if(next.layers[i].z===60){const r=decodePng(await readFile(`${OLD}/${c.layers[i].file}`));r.clearRect(55,17,18,15);const replacement=await layer(c.id+'_front',r,'hair_front',c.layers[i].source,60);delete m.inherited[next.layers[i].file];next.layers[i]=replacement;}}
 m.cosmetics.push(next);
}
for(const c of old.cosmetics.filter(c=>['bottom','hat','glasses','earrings'].includes(c.slot)))m.cosmetics.push(await inherit(c));
// Rear collars/hoods sit behind the neck; front edges remain above its lower sides.
function splitCollar(r:Raster){const back=new Raster(128,128),front=new Raster(128,128);for(let y=0;y<128;y++)for(let x=0;x<128;x++){const behind=y<=31||(y<=33&&neck.pixel(x,y)[3]===255);(behind?back:front).set(x,y,r.pixel(x,y));}return{back,front};}
function hoodFit(r:Raster,target:Box){const b=bounds(r),split=Math.round(b[1]+b[3]*.28),out=fit(r,[target[0],28,target[2],6],[b[0],b[1],b[2],split-b[1]]);out.blit(fit(r,[target[0],34,target[2],36],[b[0],split,b[2],b[1]+b[3]-split]));return out;}
for(const c of old.cosmetics.filter(c=>['top','jacket'].includes(c.slot))){let r:Raster,path=c.layers[0].source;if(c.id==='top.forest_hoodie'||c.id==='top.hoodie'){path=`${REF}/${c.id==='top.hoodie'?'hoodie-black-neck':'hoodie-forest-neck'}.png`;const garment=await raw(path);r=hoodFit(stripMatte(garment,c.id==='top.forest_hoodie'?[[625,400]]:[]),[42,28,44,42]);}else{await register(path);r=decodePng(await readFile(`${OLD}/${c.layers[0].file}`));}const {back,front}=splitCollar(r),layers:RefinedLayer[]=[];if(back.data.some((p,i)=>i%4===3&&p))layers.push(await layer(c.id+'_back',back,c.slot+'_back',path,c.slot==='top'?15:16));const f=await layer(c.id+'_front',front,c.slot,path,c.slot==='top'?40:42);f.hide=c.layers[0].hide;layers.push(f);m.cosmetics.push({...c,layers});}
// Eyes: source-traced alpha is independent of pale matte colors. White corners survive.
const eyeSpecs={neutral:{path:`${REF}/eyes-blue-clean.png`,boxes:[[181,401,455,179],[900,401,456,179]]},friendly:{path:'references/avatar-faces-v3/face-friendly-raw.png',boxes:[[441,478,177,88],[795,478,178,88]]},focused:{path:'references/avatar-faces-v3/face-focused-raw.png',boxes:[[350,432,266,127],[869,432,266,127]]}};
const palettes:Record<string,ReturnType<typeof irisPalette>>={};for(const color of EYE_COLORS){const name=color.replace('eye.','').replace('_','-'),path=`${REF}/eyes-${color==='eye.blue'?'blue-clean':name}.png`;m.eyeColorSources[color]=path;palettes[color]=irisPalette(await raw(path),color==='eye.gray');}
for(const kind of ['neutral','friendly','focused'] as const){const spec=eyeSpecs[kind],r=await raw(spec.path),eyes=sourceEye(r,spec.boxes[0] as Box,FACE_GUIDES.leftEye,EYE_GUIDES[kind]);eyes.blit(sourceEye(r,spec.boxes[1] as Box,FACE_GUIDES.rightEye,EYE_GUIDES[kind],true));const iris=eyeIrisPixels(eyes,kind),variants:RefinedLayer[]=[];
 if(iris.length<4)throw new Error('Iris role information missing '+kind);
 for(const color of EYE_COLORS){const p=new Raster(128,128);p.data.set(eyes.data);for(const i of iris){const y=Math.floor(i/128);p.set(i%128,y,palettes[color][y===22?2:0]);}variants.push(await layer('eyes_reference_'+kind+'_'+color,p,'eyes',spec.path,50));}
 const selected=variants[0];selected.eyeVariants=Object.fromEntries(EYE_COLORS.map((c,i)=>[c,variants[i].file]));m.cosmetics.push({id:'eyes.reference_'+kind,name:kind[0].toUpperCase()+kind.slice(1)+' eyes',slot:'eyes',collection:'Expression',color:'Selectable iris',layers:[selected]});m.normalization['iris_'+kind]=iris;
}
for(const c of old.cosmetics.filter(c=>c.slot==='brows')){await register(c.layers[0].source);const r=decodePng(await readFile(`${OLD}/${c.layers[0].file}`));m.cosmetics.push({...c,layers:[await layer(c.id,fit(r,[55,17,18,1]),'brows',c.layers[0].source,52)]});}
const nosePath=`${REF}/nose-detail.png`,noseSource=await isolated(nosePath),nose=new Raster(128,128),noseBox=bounds(noseSource);
// The source's landmark rows preserve bridge, tip, nostrils and lower tip independently.
for(let y=0;y<4;y++)for(let x=0;x<3;x++){const p=noseSource.pixel(Math.floor(noseBox[0]+(x+.5)*noseBox[2]/3),[473,620,723,784][y]);if(p[3]>=192)nose.set(63+x,22+y,[p[0],p[1],p[2],255]);}
for(const c of old.cosmetics.filter(c=>c.slot==='nose')){let r=nose,path=nosePath;if(!c.id.endsWith('neutral')){path=c.layers[0].source;const s=await isolated(path),box=c.id.endsWith('friendly')?[660,618,90,47]:[672,632,130,44];r=fit(s,[63,24,3,2],box as Box);}m.cosmetics.push({...c,layers:[await skins(c.id,r,'nose',path,53,'nose')]});}
for(const c of old.cosmetics.filter(c=>c.slot==='mouth')){const path=c.layers[0].source,s=await isolated(path),box:Box=c.id.endsWith('neutral')?[670,718,144,83]:c.id.endsWith('friendly')?[642,720,126,68]:[663,732,151,35];const r=fit(s,c.id.endsWith('focused')?[62,27,4,1]:FACE_GUIDES.mouth,box);m.cosmetics.push({...c,layers:[await skins(c.id,r,'mouth',path,54,'mouth')]});}
// Ears use the same source sprites, compiled against each head's temple anchors.
for(const c of old.cosmetics.filter(c=>c.slot==='ears')){const path=c.layers[0].source;await register(path);const r=decodePng(await readFile(`${OLD}/${c.layers[0].file}`)),boxes=pairBoxes(r),table:Record<string,Record<string,string>>={};let selected:RefinedLayer|undefined;
 for(const [headId,head]of Object.entries(headGeometry)){let left=128,right=0;for(let y=20;y<=23;y++)for(let x=0;x<128;x++)if(head.pixel(x,y)[3]){left=Math.min(left,x);right=Math.max(right,x);}const pair=fit(r,[left-1,20,2,5],boxes[0]);pair.blit(fit(r,[right,20,2,5],boxes[1]));const l=await skins(c.id+'_'+headId,pair,'ears',path,22);table[headId]=l.skinVariants!;if(headId==='head.soft_oval')selected=l;}
 selected!.headSkinVariants=table;m.cosmetics.push({...c,layers:[selected!]});
}
for(const color of ['white','black']){const path=`${REF}/shoes-${color}-clean.png`,s=await isolated(path),boxes=pairBoxes(s),out=new Raster(128,128);for(let side=0;side<2;side++){const t:Box=[side?65:48,110,15,11];out.blit(fit(s,t,boxes[side]));}m.cosmetics.push({id:'shoes.'+color,name:color==='white'?'White low sneakers':'Black low sneakers',slot:'shoes',collection:'Essentials',color:color==='white'?'White':'Black',layers:[await layer('shoes_'+color,out,'shoes',path,34)]});}
await mkdir(`${ROOT}/rig`,{recursive:true});await writeFile(`${ROOT}/rig/coordinates.json`,JSON.stringify({rig:m.rig,size:128,headTop:8,headBottom:31,browLine:17,eyeLine:20,noseRows:[22,25],mouthRows:[27,29],neckRows:[32,35],shoulderLine:34,waistLine:60,footBaseline:120,regions:m.regions},null,2));await writeFile(`${ROOT}/manifest.json`,JSON.stringify(m,null,2));console.log(`${m.cosmetics.length} cosmetics; six eye colors; head/neck overlap and rear collar layers compiled.`);
