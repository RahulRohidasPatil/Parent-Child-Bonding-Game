import {mkdir,rename,stat} from 'node:fs/promises';
import {join} from 'node:path';

/** Validate first, retain the previous pack, and roll back if installing the new directory fails. */
export async function publishValidatedPack(staging:string,destination:string,archiveRoot:string,validate:(root:string)=>Promise<unknown>){
 await validate(staging);
 await mkdir(archiveRoot,{recursive:true});
 const archived=join(archiveRoot,'pack_'+new Date().toISOString().replace(/[^0-9]/g,''));
 let previous=false;
 try{await stat(destination);previous=true;}catch(error){if((error as NodeJS.ErrnoException).code!=='ENOENT')throw error;}
 if(previous)await rename(destination,archived);
 try{await rename(staging,destination);}
 catch(error){if(previous){try{await stat(destination);}catch{await rename(archived,destination);}}throw error;}
 return previous?archived:null;
}
