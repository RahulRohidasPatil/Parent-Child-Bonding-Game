import {mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {renderRefined,refinedManifest} from '../../src/refined/render.js';
import {DEFAULT_REFINED,EYE_COLORS,RefinedConfig} from '../../src/refined/model.js';
const root=process.argv[2]??'assets/avatar/atelier-r4/previews',m=await refinedManifest();await mkdir(root,{recursive:true});
async function render(c:RefinedConfig){return decodePng((await renderRefined(c)).png);}
async function sheet(name:string,cells:{label:string;config:RefinedConfig}[],cols:number,face=false){const w=face?256:128,h=face?224:128,out=new Raster(cols*w,Math.ceil(cells.length/cols)*h);out.rect(0,0,out.width,out.height,[238,240,232,255]);for(let i=0;i<cells.length;i++){const p=await render(cells[i].config);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const c=face?p.pixel(48+Math.floor(x/8),12+Math.floor(y/8)):p.pixel(x,y);if(c[3])out.set((i%cols)*w+x,Math.floor(i/cols)*h+y,c);}}await writePng(`${root}/${name}.png`,out);await writeFile(`${root}/${name}.json`,JSON.stringify(cells,null,2));}
for(const [name,c]of Object.entries({default:DEFAULT_REFINED,green_hoodie:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,top:'top.forest_hoodie'}},black_hoodie:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,top:'top.hoodie'}},quarter_zip:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,top:'top.quarter'}}})){const p=await render(c);await writePng(`${root}/${name}.png`,p);await writePng(`${root}/${name}_review_4x.png`,p.upscale(4));}
const eyeCells=m.cosmetics.filter(c=>c.slot==='eyes').flatMap(e=>EYE_COLORS.map(eyeColor=>({label:e.name+' '+eyeColor,config:{...DEFAULT_REFINED,eyeColor,equipment:{...DEFAULT_REFINED.equipment,eyes:e.id}}})));
await sheet('eye_colors',eyeCells,6,true);await sheet('head_shapes',m.cosmetics.filter(c=>c.slot==='head').map(h=>({label:h.name,config:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,head:h.id}}})),6,true);
await sheet('all_necklines',m.cosmetics.filter(c=>['top','jacket'].includes(c.slot)).map(t=>({label:t.name,config:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,[t.slot]:t.id}}})),4,true);
await sheet('all_shoes',m.cosmetics.filter(c=>c.slot==='shoes').flatMap(s=>m.cosmetics.filter(c=>c.slot==='bottom').map(b=>({label:s.name+' '+b.name,config:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,shoes:s.id,bottom:b.id}}}))),4);
await sheet('skin_tones',m.skins.map(s=>({label:s.id,config:{...DEFAULT_REFINED,skin:s.id as RefinedConfig['skin']}})),6,true);
console.log('Stable review sheets saved in '+root);
