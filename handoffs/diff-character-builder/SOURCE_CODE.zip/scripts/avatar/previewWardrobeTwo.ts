import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {createCollectionRenderer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,type CollectionConfig} from '../../src/collection/model.js';
import {WEAR_COLOR_IDS} from '../../src/collection/wearPalettes.js';
const state=JSON.parse(await readFile('artifacts/avatar-wardrobe-two/build-state.json','utf8'));
const pack=process.argv[2]??(state.published?'assets/avatar/atelier-r6':state.staging),root='artifacts/avatar-wardrobe-two/previews';await mkdir(root,{recursive:true});
const renderer=createCollectionRenderer(pack),m=await renderer.manifest();
const jobs=m.cosmetics.filter(c=>c.layers.some(l=>l.source.startsWith('references/avatar-wardrobe-two/')));
type Cell={label:string;config:CollectionConfig};let renders=0;
async function sheet(name:string,cells:Cell[],cols:number){if(!cells.length)return;const w=256,h=256,out=new Raster(cols*w,Math.ceil(cells.length/cols)*h);out.rect(0,0,out.width,out.height,[238,240,232,255]);for(let i=0;i<cells.length;i++){const result=await renderer.render(cells[i].config);if(result.warnings.length)throw Error('Preview fallback: '+cells[i].label);const r=decodePng(result.png);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const p=r.pixel(Math.floor(x/2),Math.floor(y/2));if(p[3])out.set(i%cols*w+x,Math.floor(i/cols)*h+y,p);}renders++;}await writePng(root+'/'+name+'.png',out);await writeFile(root+'/'+name+'.json',JSON.stringify(cells,null,2));}
const equip=(id:string):CollectionConfig=>{const item=m.cosmetics.find(c=>c.id===id)!;const c=structuredClone(DEFAULT_COLLECTION);c.equipment[item.slot]=id;c.wearColors[item.slot as 'top'|'jacket'|'bottom']=item.slot==='bottom'?'wear.blue':item.slot==='jacket'?'wear.charcoal':'wear.cream';return c;};
const showcase=['wear.navy','wear.cream','wear.burgundy','wear.sky','wear.forest','wear.red','wear.white','wear.tan','wear.brown','wear.black','wear.olive','wear.charcoal','wear.tan','wear.forest','wear.brown','wear.charcoal','wear.charcoal','wear.olive','wear.blue','wear.navy'];
await sheet('new_20',jobs.map((item,index)=>{const config=equip(item.id);config.wearColors[item.slot as 'top'|'jacket'|'bottom']=showcase[index] as typeof config.wearColors.top;return{label:item.name,config};}),5);
for(const slot of ['top','jacket','bottom'])await sheet('new_'+slot,jobs.filter(c=>c.slot===slot).map(c=>({label:c.name,config:equip(c.id)})),4);
for(const item of jobs){
 const colorCells=WEAR_COLOR_IDS.map(color=>{const c=equip(item.id);c.wearColors[item.slot as 'top'|'jacket'|'bottom']=color;return{label:item.name+' '+color,config:c};});await sheet('colors_'+item.id.replace('.','_'),colorCells,6);
 if(item.slot==='jacket')await sheet('fit_'+item.id.replace('.','_'),m.cosmetics.filter(c=>c.slot==='top').map(t=>{const c=equip(item.id);c.equipment.top=t.id;return{label:item.name+' / '+t.name,config:c};}),6);
 if(item.slot==='bottom')await sheet('fit_'+item.id.replace('.','_'),m.cosmetics.filter(c=>c.slot==='shoes').map(s=>{const c=equip(item.id);c.equipment.shoes=s.id;return{label:item.name+' / '+s.name,config:c};}),6);
 if(item.slot==='top')await sheet('fit_'+item.id.replace('.','_'),m.cosmetics.filter(c=>c.slot==='jacket').map(j=>{const c=equip(item.id);c.equipment.jacket=j.id;return{label:item.name+' / '+j.name,config:c};}),6);
}
await writeFile(root+'/summary.json',JSON.stringify({items:jobs.length,renders,pack},null,2));console.log({items:jobs.length,renders,root});
