import {mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {DEFAULT_ATELIER,Slot,AtelierConfig} from '../../src/atelier/model.js';
import {atelierManifest,renderAtelier,atelierPresets} from '../../src/atelier/render.js';
import {randomConfiguration} from './validateAtelier.js';
const root='assets/avatar/atelier-r2/previews',m=await atelierManifest();await mkdir(root,{recursive:true});
const replace=(slot:Slot,id:string|null,c=DEFAULT_ATELIER)=>({...c,equipment:{...c.equipment,[slot]:id}});
async function sheet(name:string,cells:{label:string;config:AtelierConfig}[],cols=8){
  const out=new Raster(cols*128,Math.ceil(cells.length/cols)*128);out.rect(0,0,out.width,out.height,[238,239,230,255]);
  for(let i=0;i<cells.length;i++){const r=decodePng((await renderAtelier(cells[i].config)).png);for(let y=0;y<128;y++)for(let x=0;x<128;x++){const p=r.pixel(x,y);if(p[3])out.set((i%cols)*128+x,Math.floor(i/cols)*128+y,p);}}
  await writePng(`${root}/${name}.png`,out);await writeFile(`${root}/${name}.json`,JSON.stringify(cells.map((c,i)=>({index:i,...c})),null,2));
}
for(const slots of [['hair'],['top'],['bottom','shoes'],['jacket'],['eyes','brows','nose','mouth','ears'],['hat','glasses','earrings']] as Slot[][]){await sheet(slots.join('_'),m.cosmetics.filter(c=>slots.includes(c.slot)).map(c=>({label:c.name,config:replace(c.slot,c.id)})));}
await sheet('skin_tones',m.skins.map(s=>({label:s.id,config:{...DEFAULT_ATELIER,skin:s.id as AtelierConfig['skin']}})),6);
await sheet('hair_hat_matrix',m.cosmetics.filter(c=>c.slot==='hair').flatMap(h=>[null,...m.cosmetics.filter(c=>c.slot==='hat').map(c=>c.id)].map(hat=>({label:h.id+' + '+hat,config:replace('hat',hat,replace('hair',h.id))}))),3);
await sheet('top_jacket_matrix',m.cosmetics.filter(c=>c.slot==='top').flatMap(t=>[null,...m.cosmetics.filter(c=>c.slot==='jacket').map(c=>c.id)].map(j=>({label:t.id+' + '+j,config:replace('jacket',j,replace('top',t.id))}))),4);
await sheet('random_200',Array.from({length:200},(_,i)=>({label:'Seed '+(75001+i),config:randomConfiguration(m,75001+i)})),10);
await sheet('starter_looks',atelierPresets(DEFAULT_ATELIER).map(p=>({label:p.name,config:p.config})),4);
await writeFile(`${root}/default.png`,(await renderAtelier(DEFAULT_ATELIER)).png);
console.log('Generated collection previews, compatibility matrices and 200 deterministic sample avatars.');
