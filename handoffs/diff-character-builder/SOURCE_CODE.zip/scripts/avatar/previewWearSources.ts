import {readFile,access,mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {isolateWearSource,compileWearSource,type WearSourceJob} from '../../src/collection/wearAuthoring.js';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION} from '../../src/collection/model.js';
const m=await collectionManifest(),root='artifacts/avatar-wardrobe-expansion/pilot';await mkdir(root,{recursive:true});
const body=decodePng(await readFile('assets/avatar/atelier-r6/'+m.skins[1].layer.file)),top=decodePng(await readFile('assets/avatar/atelier-r6/'+m.partitionMasks.top));
const jobs=JSON.parse(await readFile('references/avatar-wardrobe-expansion/prompts.json','utf8')).jobs as WearSourceJob[],rows=[];let i=0;const out=new Raster(6*256,Math.ceil(jobs.length/6)*256);out.rect(0,0,out.width,out.height,[238,240,232,255]);
for(const j of jobs){const path='references/avatar-wardrobe-expansion/'+j.source;try{await access(path)}catch{continue}
 try{const raw=await isolateWearSource(path),p=compileWearSource(raw,j,body,top);await writePng(root+'/'+j.id+'_front.png',p.front);await writePng(root+'/'+j.id+'_back.png',p.back);const base=decodePng((await renderCollection({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,[j.kind]:null}})).png);const result=new Raster(128,128);result.blit(p.back);result.blit(base);result.blit(p.front);for(let y=0;y<256;y++)for(let x=0;x<256;x++){const p=result.pixel(Math.floor(x/2),Math.floor(y/2));if(p[3])out.set(i%6*256+x,Math.floor(i/6)*256+y,p);}rows.push({index:i++,id:j.id,status:'compiled'});}catch(e){rows.push({id:j.id,error:String(e)});}}
await writePng(root+'/sheet.png',out);await writeFile(root+'/index.json',JSON.stringify(rows,null,2));console.log(rows);
