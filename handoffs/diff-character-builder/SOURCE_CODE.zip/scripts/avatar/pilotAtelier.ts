import {mkdir,writeFile} from 'node:fs/promises';
import {sourcePng,fit} from '../../src/atelier/pixels.js';
import {Raster,encodePng} from '../../src/avatar/raster.js';
const root='references/avatar-atelier/';
const files={body:'body-source',top:'top-navy',quarter:'top-quarter',bottom:'bottom-denim',shoes:'shoe-white',hair:'hair-textured',eyes:'eyes-neutral',brows:'brows-straight',mouth:'mouth-neutral'};
const targets:Record<keyof typeof files,[number,number,number,number]>={body:[44,8,40,112],top:[43,30,42,40],quarter:[43,29,42,41],bottom:[52,60,24,56],shoes:[47,111,34,10],hair:[51,3,26,19],eyes:[57,20,14,3],brows:[57,18,14,2],mouth:[62,25,4,1]};
const images:Record<string,Raster>={};
await mkdir('artifacts/avatar-atelier/pilot',{recursive:true});
for(const [id,file]of Object.entries(files)){images[id]=fit(await sourcePng(root+file+'.png'),targets[id as keyof typeof files]);await writeFile(`artifacts/avatar-atelier/pilot/${id}.png`,encodePng(images[id]));}
for(const top of ['top','quarter']){const image=new Raster(128,128);for(const key of ['body','bottom','shoes',top,'eyes','brows','mouth','hair'])image.blit(images[key]);await writeFile(`artifacts/avatar-atelier/pilot/${top}-composite.png`,encodePng(image));}
