import {readFile,writeFile,mkdir,copyFile,readdir,rename,access} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {SKIN_PALETTES} from '../../src/avatar/palettes.js';
import {fit,bounds,Box} from '../../src/atelier/pixels.js';
import type {AtelierManifest} from '../../src/atelier/model.js';
import type {PortraitManifest,PortraitSlot,ImageLayer} from '../../src/portrait/model.js';
const ROOT='assets/avatar/atelier-r3',OLD='assets/avatar/atelier-r2',REF='references/avatar-faces-v3';
const old=JSON.parse(await readFile(`${OLD}/manifest.json`,'utf8')) as AtelierManifest;
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const m:PortraitManifest={version:3,pack:'atelier-r3',rig:old.rig,size:128,cosmetics:[],skins:[],regions:{...old.regions,body:[42,28,44,94],head:[52,7,24,21],brows:[56,17,16,1],eyes:[56,18,16,4],nose:[61,22,6,2],mouth:[60,24,8,3],ears:[53,17,22,7]},masks:{},sources:{},pictureHashes:{},inherited:{},faceSources:{}};
await mkdir(`${ROOT}/layers`,{recursive:true});await mkdir(`${ROOT}/masks`,{recursive:true});
async function source(path:string){const bytes=await readFile(path);m.sources[path.split('/').at(-1)!.replace('.png','')]=path;m.pictureHashes[path]=sha(bytes);const p=PNG.sync.read(bytes),r=new Raster(p.width,p.height);r.data.set(p.data);return{r,alpha:p.alpha};}
/** Source-matte cleanup, not artwork generation: only exterior pale neutral pixels are removed. */
function removeMatte(r:Raster){
 const marked=new Uint8Array(r.width*r.height),queue=new Int32Array(r.width*r.height);let start=0,end=0;
 const darkMatte=Math.max(...r.pixel(0,0).slice(0,3))<12;
 const pale=(i:number)=>{const p=i*4,a=r.data[i*4+3],lo=Math.min(r.data[p],r.data[p+1],r.data[p+2]),hi=Math.max(r.data[p],r.data[p+1],r.data[p+2]);return a===0||(darkMatte?hi<14&&hi-lo<8:lo>=210&&hi-lo<=12);};
 const add=(i:number)=>{if(!marked[i]&&pale(i)){marked[i]=1;queue[end++]=i;}};
 for(let x=0;x<r.width;x++){add(x);add((r.height-1)*r.width+x);}for(let y=0;y<r.height;y++){add(y*r.width);add(y*r.width+r.width-1);}
 while(start<end){const i=queue[start++],x=i%r.width,y=Math.floor(i/r.width);if(x)add(i-1);if(x<r.width-1)add(i+1);if(y)add(i-r.width);if(y<r.height-1)add(i+r.width);}
 for(let i=0;i<marked.length;i++)if(marked[i])r.data.fill(0,i*4,i*4+4);return r;
}
async function isolated(path:string){const {r,alpha}=await source(path);return alpha?r:removeMatte(r);}
const SOFT_FACE_TONES=['#b88470','#ac7560','#98624d','#89513e','#764632','#633629','#542c20','#442218','#361b14','#2a1511','#1f100c','#160b09'];
function tone(r:Raster,id:string,facial=false){const out=new Raster(128,128),p=SKIN_PALETTES[id],hex=SOFT_FACE_TONES[Number(id.slice(-2))-1],soft:[number,number,number,number]=[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16),255];for(let y=0;y<128;y++)for(let x=0;x<128;x++){const c=r.pixel(x,y);if(!c[3])continue;if(facial)out.set(x,y,c[0]<120?p.outlineShadow:c[0]<180?p.shadow:soft);else if(c[0]>c[1]+12&&c[1]>c[2]+7&&c[0]>80)out.set(x,y,c[0]>=237?p.highlight:c[0]>=202?p.base:c[0]>=156?p.shadow:p.outlineShadow);else out.set(x,y,c);}return out;}
async function writeLayer(name:string,r:Raster,region:string,source:string,z:number):Promise<ImageLayer>{const file=`layers/${name.replace(/[.-]/g,'_')}_v3.png`;const [x,y,w,h]=m.regions[region];let count=0;for(let yy=0;yy<128;yy++)for(let xx=0;xx<128;xx++)if(r.pixel(xx,yy)[3]){count++;if(xx<x||xx>=x+w||yy<y||yy>=y+h)throw new Error(`${name} outside ${region} at ${xx},${yy}`);}if(!count)throw new Error('Empty '+name);await writePng(`${ROOT}/${file}`,r);return{file,z,region,source,sha256:sha(await readFile(`${ROOT}/${file}`))};}
async function skinVariants(id:string,r:Raster,region:string,source:string,z:number){const variants:ImageLayer[]=[];for(const skin of Object.keys(SKIN_PALETTES))variants.push(await writeLayer(id+'_'+skin,tone(r,skin,['nose','mouth'].includes(region)),region,source,z));const layer=variants[3];layer.skinVariants=Object.fromEntries(Object.keys(SKIN_PALETTES).map((id,i)=>[id,variants[i].file]));return layer;}
// Accepted clothing, hair and accessories are copied byte-for-byte, never regenerated.
for(const c of old.cosmetics.filter(c=>!['eyes','brows','nose','mouth','ears'].includes(c.slot))){const copy=structuredClone(c);for(const l of copy.layers){const previous=l.file;l.file=previous.replace('_v2.png','_v3.png');await copyFile(`${OLD}/${previous}`,`${ROOT}/${l.file}`);m.inherited[l.file]=`${OLD}/${previous}`;m.sources[l.source.split('/').at(-1)!.replace('.png','')]=l.source;m.pictureHashes[l.source]=sha(await readFile(l.source));}m.cosmetics.push(copy);}
for(const [id,file] of Object.entries(old.masks)){const next=file.replace('_v2.png','_v3.png');await copyFile(`${OLD}/${file}`,`${ROOT}/${next}`);m.masks[id]=next;m.inherited[next]=`${OLD}/${file}`;}
for(const skin of old.skins){const body=decodePng(await readFile(`${OLD}/${skin.layer.file}`));body.clearRect(0,0,128,28);m.skins.push({...skin,layer:await writeLayer('body_'+skin.id,body,'body',skin.layer.source,20)});}
const baseSource=old.skins[3].layer.source;m.sources['body-source']=baseSource;m.pictureHashes[baseSource]=sha(await readFile(baseSource));
const shapes:[string,string,string,Box][]=[['soft_oval','Soft oval','head-oval',[54,8,20,20]],['round','Round','head-round',[53,8,22,20]],['soft_square','Soft square','head-soft-square',[54,8,20,20]],['full_round','Full round','head-full-round',[53,8,22,20]],['narrow','Narrow oval','head-narrow',[55,8,18,20]]];
for(const [id,name,key,target] of shapes){const path=`${REF}/${key}.png`,r=fit(await isolated(path),target);m.cosmetics.push({id:'head.'+id,name,slot:'head',collection:'Head shape',color:'Skin matched',layers:[await skinVariants('head_'+id,r,'head',path,21)]});}
// Retain the former head as an explicit optional shape without changing its pixels.
const oldHead=decodePng(await readFile(`${OLD}/${old.skins[3].layer.file}`));oldHead.clearRect(0,28,128,100);
const legacyHeadLayers:ImageLayer[]=[];for(const skin of old.skins){const head=decodePng(await readFile(`${OLD}/${skin.layer.file}`));head.clearRect(0,28,128,100);legacyHeadLayers.push(await writeLayer('head_angular_'+skin.id,head,'head',baseSource,21));}
legacyHeadLayers[3].skinVariants=Object.fromEntries(old.skins.map((s,i)=>[s.id,legacyHeadLayers[i].file]));m.cosmetics.push({id:'head.angular',name:'Angular',slot:'head',collection:'Head shape',color:'Skin matched',layers:[legacyHeadLayers[3]]});
// Read each coordinated expression draft once and export each part to its own locked PNG guide.
const frame:Box=[58,17,12,10],parts:Record<string,Box>={brows:[58,17,12,1],eyes:[58,19,12,2],nose:[63,23,2,1],mouth:[62,25,4,1]};
for(const expression of ['neutral','friendly','focused']){
 const path=`${REF}/face-${expression}-raw.png`,s=await isolated(path),[sx,sy,sw,sh]=bounds(s);
 // Eyes and brows retain one horizontal source scale; nose and mouth use the locked center guides.
 const bands:[number,number][]=[];let begin=-1,last=-1;
 for(let y=sy;y<sy+sh;y++){let count=0;for(let x=sx;x<sx+sw;x++)if(s.pixel(x,y)[3]>=192)count++;if(count>=Math.max(4,sw/40)){if(begin<0)begin=y;last=y;}else if(begin>=0&&y-last>4){bands.push([begin,last-begin+1]);begin=-1;}}
 if(begin>=0)bands.push([begin,last-begin+1]);if(bands.length<4)throw new Error('Missing face bands '+expression+': '+JSON.stringify(bands));
 const guides={brows:bands[0],eyes:bands[1],nose:bands[2],mouth:bands[3]};
 m.faceSources[expression]={file:path,frame,parts};
 for(const [slot,target] of Object.entries(parts)){const [y,h]=guides[slot as keyof typeof guides];let left=sx,right=sx+sw-1;if(['nose','mouth'].includes(slot)){left=s.width;right=0;for(let yy=y;yy<y+h;yy++)for(let xx=sx;xx<sx+sw;xx++)if(s.pixel(xx,yy)[3]>=192){left=Math.min(left,xx);right=Math.max(right,xx);}}
  const separated=fit(s,target,[left,y,right-left+1,h]),depth={brows:52,eyes:50,nose:53,mouth:54}[slot]!;const layer=['nose','mouth'].includes(slot)?await skinVariants(`${slot}_reference_${expression}`,separated,slot,path,depth):await writeLayer(`${slot}_reference_${expression}`,separated,slot,path,depth);m.cosmetics.push({id:`${slot}.reference_${expression}`,name:`${expression[0].toUpperCase()+expression.slice(1)} ${slot}`,slot:slot as PortraitSlot,collection:'Expression',color:'Natural',layers:[layer]});}
 console.log(expression,JSON.stringify(bands));
}
// Small ears come from an Imagegen head draft; the second silhouette uses the earlier ear artwork.
for(const [id,name,path,clips] of [
 ['small','Small ears',`${REF}/head-soft-square-raw.png`,[[140,410,176,320],[1014,410,176,320]]],
 ['rounded','Rounded ears','references/avatar-atelier/ears-rounded.png',null]
] as const){
 const s=(await source(path)).r;let pair:Raster;
 if(clips){pair=fit(s,[54,18,2,4],[...clips[0]] as Box);pair.blit(fit(s,[72,18,2,4],[...clips[1]] as Box));}
 else{const left=new Raster(s.width,s.height),right=new Raster(s.width,s.height);for(let y=0;y<s.height;y++)for(let x=0;x<s.width;x++)(x<s.width/2?left:right).set(x,y,s.pixel(x,y));pair=fit(left,[54,18,2,4]);pair.blit(fit(right,[72,18,2,4]));}
 m.cosmetics.push({id:'ears.'+id,name,slot:'ears',collection:'Ears',color:'Skin matched',layers:[await skinVariants('ears_'+id,pair,'ears',path,22)]});
}
await mkdir(`${ROOT}/rig`,{recursive:true});await writeFile(`${ROOT}/rig/coordinates.json`,JSON.stringify({rig:m.rig,size:128,headTop:8,headBottom:27,neckTop:28,browLine:17,eyeLine:19,noseLine:23,mouthLine:25,footBaseline:120,sourceMatte:'Exterior-connected pale neutral source pixels only; original RGB retained',regions:m.regions},null,2));
// Preserve superseded compiler drafts outside the active pack instead of deleting pictures.
const active=new Set([...m.skins.map(s=>s.layer),...m.cosmetics.flatMap(c=>c.layers)].flatMap(l=>[l.file,...Object.values(l.skinVariants??{})]));
for(const f of await readdir(`${ROOT}/layers`))if(!active.has('layers/'+f)){
 const archive=`${REF}/compilation-history`;await mkdir(archive,{recursive:true});let index=1,destination=`${archive}/${f}`;
 while(true){try{await access(destination);destination=`${archive}/${f.replace('.png','')}_draft_${index++}.png`;}catch{break;}}
 await rename(`${ROOT}/layers/${f}`,destination);
}
await writeFile(`${ROOT}/manifest.json`,JSON.stringify(m,null,2));console.log(`${m.cosmetics.length} modules with six head shapes and independent facial PNGs.`);
