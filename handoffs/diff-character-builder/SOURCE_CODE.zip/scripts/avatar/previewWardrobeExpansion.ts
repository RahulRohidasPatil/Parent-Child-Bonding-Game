import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,type CollectionConfig} from '../../src/collection/model.js';
import {WEAR_SLOTS,WEAR_COLOR_IDS,type WearSlot} from '../../src/collection/wearPalettes.js';
const root=process.argv[2]??'artifacts/avatar-wardrobe-expansion/review';await mkdir(root,{recursive:true});
const m=await collectionManifest(),jobs=JSON.parse(await readFile('references/avatar-wardrobe-expansion/prompts.json','utf8')).jobs;
type Cell={label:string;config:CollectionConfig};
async function sheet(name:string,cells:Cell[],cols:number,zone='full'){
 const crop=zone==='shoes'?[44,100,42,26,4]:zone==='torso'?[42,29,44,48,3]:zone==='bottom'?[47,70,36,55,3]:[0,0,128,128,2],w=crop[2]*crop[4],h=crop[3]*crop[4],out=new Raster(cols*w,Math.ceil(cells.length/cols)*h);out.rect(0,0,out.width,out.height,[238,240,232,255]);
 for(let i=0;i<cells.length;i++){const p=decodePng((await renderCollection(cells[i].config)).png);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const c=p.pixel(crop[0]+Math.floor(x/crop[4]),crop[1]+Math.floor(y/crop[4]));if(c[3])out.set(i%cols*w+x,Math.floor(i/cols)*h+y,c);}}
 await writePng(root+'/'+name+'.png',out);await writeFile(root+'/'+name+'.json',JSON.stringify(cells,null,2));
}
const equip=(slot:WearSlot,id:string):CollectionConfig=>({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,[slot]:id,...(slot==='tie'?{top:'top.dress_white'}:{})}});
for(const slot of WEAR_SLOTS){const items=m.cosmetics.filter(c=>c.slot===slot),cells=items.map(c=>({label:c.name,config:equip(slot,c.id)}));await sheet('all_'+slot,cells,6,slot==='shoes'?'shoes':'full');
 for(let start=0;start<items.length;start+=6)await sheet('colors_'+slot+'_'+Math.floor(start/6),items.slice(start,start+6).flatMap(c=>WEAR_COLOR_IDS.map(color=>({label:c.name+' '+color,config:{...equip(slot,c.id),wearColors:{...DEFAULT_COLLECTION.wearColors,[slot]:color}}}))),18,slot==='shoes'?'shoes':slot==='bottom'?'bottom':slot==='top'||slot==='jacket'?'torso':'full');
}
await sheet('new_50',jobs.map((j:{id:string;name:string;kind:WearSlot})=>({label:j.name,config:{...equip(j.kind,j.id),wearColors:{...DEFAULT_COLLECTION.wearColors,[j.kind]:j.kind==='shoes'?'wear.brown':j.kind==='jacket'?'wear.charcoal':j.kind==='bottom'?'wear.blue':'wear.cream'}}})),6);
for(const jacket of m.cosmetics.filter(c=>c.slot==='jacket'&&c.layers.some(l=>l.source.includes('wardrobe-expansion'))))await sheet('fit_'+jacket.id.replace('.','_'),m.cosmetics.filter(c=>c.slot==='top').map(t=>({label:jacket.name+' / '+t.name,config:{...equip('top',t.id),equipment:{...equip('top',t.id).equipment,jacket:jacket.id},wearColors:{...DEFAULT_COLLECTION.wearColors,top:'wear.cream',jacket:'wear.forest'}}})),6);
for(const bottom of m.cosmetics.filter(c=>c.slot==='bottom'&&c.layers.some(l=>l.source.includes('wardrobe-expansion'))))await sheet('fit_'+bottom.id.replace('.','_'),m.cosmetics.filter(c=>c.slot==='shoes').map(s=>({label:bottom.name+' / '+s.name,config:{...equip('bottom',bottom.id),equipment:{...equip('bottom',bottom.id).equipment,shoes:s.id},wearColors:{...DEFAULT_COLLECTION.wearColors,bottom:'wear.blue',shoes:'wear.brown'}}})),6,'bottom');
console.log(root);
