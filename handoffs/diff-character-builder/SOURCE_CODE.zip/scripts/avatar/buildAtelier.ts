import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {Raster,writePng} from '../../src/avatar/raster.js';
import {SKIN_PALETTES} from '../../src/avatar/palettes.js';
import {fit,sourcePng} from '../../src/atelier/pixels.js';
import {SOURCE_ITEMS,REGIONS} from '../../src/atelier/collection.js';
import type {AtelierManifest,ImageLayer,Slot} from '../../src/atelier/model.js';

const root='assets/avatar/atelier-r2',refs='references/avatar-atelier';
const digest=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const manifest:AtelierManifest={version:2,rig:'front_idle_atelier_v1',pack:'atelier-r2',size:128,cosmetics:[],skins:[],regions:REGIONS,masks:{},sources:{},pictureHashes:{}};
const z:Record<Slot,number>={ears:22,bottom:32,shoes:34,top:40,jacket:42,eyes:50,brows:52,nose:53,mouth:54,hair:60,earrings:70,glasses:72,hat:80};
async function source(name:string){const path=`${refs}/${name}.png`;manifest.sources[name]=path;manifest.pictureHashes[path]=digest(await readFile(path));return sourcePng(path);}
async function layer(name:string,raster:Raster,region:string,source:string,depth:number):Promise<ImageLayer>{
  const file=`layers/${name.replace(/[.-]/g,'_')}_v2.png`;
  if(!raster.data.some((p,i)=>i%4===3&&p))throw new Error('Empty layer: '+name);
  const [x,y,w,h]=REGIONS[region];
  for(let yy=0;yy<128;yy++)for(let xx=0;xx<128;xx++)if(raster.pixel(xx,yy)[3]&&(xx<x||xx>=x+w||yy<y||yy>=y+h))throw new Error(`${name} outside ${region} at ${xx},${yy}`);
  await writePng(`${root}/${file}`,raster);return {file,z:depth,region,source:`${refs}/${source}.png`,sha256:digest(await readFile(`${root}/${file}`))};
}
function tone(r:Raster,id:string){
  const out=new Raster(128,128),p=SKIN_PALETTES[id];
  for(let y=0;y<128;y++)for(let x=0;x<128;x++){
    const c=r.pixel(x,y);if(!c[3])continue;
    // A palette lookup on existing skin pixels, preserving outlines and neutral underwear.
    if(c[0]>c[1]+12&&c[1]>c[2]+7&&c[0]>80){out.set(x,y,c[0]>=237?p.highlight:c[0]>=202?p.base:c[0]>=156?p.shadow:p.outlineShadow);}else out.set(x,y,c);
  }return out;
}
await mkdir(root,{recursive:true});
const master=fit(await source('body-source'),[44,8,40,112]);
const ears=new Raster(128,128);
for(let y=18;y<=22;y++)for(let x=54;x<=73;x++)if(x<=56||x>=72){ears.set(x,y,master.pixel(x,y));master.set(x,y,[0,0,0,0]);}
const classic:ImageLayer[]=[];
for(const [id,p] of Object.entries(SKIN_PALETTES)){
  manifest.skins.push({id,color:`rgb(${p.base.slice(0,3).join(',')})`,layer:await layer(`body_${id}`,tone(master,id),'body','body-source',20)});
  classic.push(await layer(`ears_classic_${id}`,tone(ears,id),'ears','body-source',22));
}
classic[3].skinVariants=Object.fromEntries(Object.keys(SKIN_PALETTES).map((id,i)=>[id,classic[i].file]));
manifest.cosmetics.push({id:'ears.classic',name:'Classic ears',slot:'ears',collection:'Details',color:'Skin matched',layers:[classic[3]]});
for(const item of SOURCE_ITEMS){
  const r=fit(await source(item.source),item.target,item.sourceClip),region=item.slot==='hair'?'hair_front':item.slot==='hat'?'headwear':item.slot;
  let layers:ImageLayer[]=[];
  if(item.long){
    const back=new Raster(128,128),front=new Raster(128,128);
    for(let y=0;y<128;y++)for(let x=0;x<128;x++){
      // Standard head occlusion: face pixels below the brow stay in the back component.
      // Tresses outside the head continue in front of clothing, using the original hair pixels.
      back.set(x,y,r.pixel(x,y));if(!(y>=17&&y<28&&master.pixel(x,y)[3]))front.set(x,y,r.pixel(x,y));
    }
    layers=[await layer(item.id+'_back',back,'hair_back',item.source,10),await layer(item.id+'_front',front,'hair_front',item.source,60)];
  }else if(item.slot==='ears'){
    const variants:ImageLayer[]=[];
    for(const skin of Object.keys(SKIN_PALETTES))variants.push(await layer(item.id+'_'+skin,tone(r,skin),region,item.source,z[item.slot]));
    variants[3].skinVariants=Object.fromEntries(Object.keys(SKIN_PALETTES).map((id,i)=>[id,variants[i].file]));layers=[variants[3]];
  }else layers=[await layer(item.id,r,region,item.source,z[item.slot])];
  if(item.slot==='hat')layers[0].hide=['hair_front:hair_crown','hair_back:hair_crown'];
  if(item.slot==='jacket')layers[0].hide=['top:top_sleeves'];
  manifest.cosmetics.push({id:item.id,name:item.name,slot:item.slot,collection:item.collection,color:item.color,layers});
}
const crown=new Raster(128,128);crown.rect(47,0,34,17,[255,255,255,255]);
const sleeves=new Raster(128,128);sleeves.rect(40,27,17,45,[255,255,255,255]);sleeves.rect(71,27,17,45,[255,255,255,255]);
for(const [id,r] of Object.entries({hair_crown:crown,top_sleeves:sleeves})){const file=`masks/${id}_v2.png`;await writePng(`${root}/${file}`,r);manifest.masks[id]=file;}
await writePng(`${root}/rig/master.png`,master);
await writeFile(`${root}/rig/coordinates.json`,JSON.stringify({rig:manifest.rig,canvas:128,centerX:64,body:[44,8,40,112],headTop:8,eyeLine:19,browLine:17,noseLine:22,mouthLine:24,shoulderLine:34,waistLine:60,ankleLine:111,footBaseline:120,regions:REGIONS},null,2));
await writeFile(`${root}/manifest.json`,JSON.stringify(manifest,null,2));
console.log(`${manifest.cosmetics.length} image-backed cosmetics, ${manifest.skins.length} skin tones. Original sources preserved.`);
