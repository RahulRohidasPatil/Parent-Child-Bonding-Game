import {writeFile,mkdir} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {portraitManifest,renderPortrait} from '../../src/portrait/render.js';
import {DEFAULT_PORTRAIT,PortraitConfig} from '../../src/portrait/model.js';
const root='assets/avatar/atelier-r3/previews',m=await portraitManifest();await mkdir(root,{recursive:true});
async function sheet(name:string,cells:{label:string;config:PortraitConfig}[],cols=6){const out=new Raster(cols*128,Math.ceil(cells.length/cols)*128);out.rect(0,0,out.width,out.height,[238,239,230,255]);for(let i=0;i<cells.length;i++){const p=decodePng((await renderPortrait(cells[i].config)).png);for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(p.pixel(x,y)[3])out.set((i%cols)*128+x,Math.floor(i/cols)*128+y,p.pixel(x,y));}await writePng(`${root}/${name}.png`,out);await writeFile(`${root}/${name}.json`,JSON.stringify(cells,null,2));}
const heads=m.cosmetics.filter(c=>c.slot==='head');
await sheet('all_heads',heads.map(h=>({label:h.name,config:{...DEFAULT_PORTRAIT,equipment:{...DEFAULT_PORTRAIT.equipment,head:h.id}}})));
await sheet('heads_expressions',heads.flatMap(h=>['neutral','friendly','focused'].map(e=>({label:h.id+' '+e,config:{...DEFAULT_PORTRAIT,equipment:{...DEFAULT_PORTRAIT.equipment,head:h.id,eyes:'eyes.reference_'+e,brows:'brows.reference_'+e,nose:'nose.reference_'+e,mouth:'mouth.reference_'+e}}}))),3);
await sheet('heads_hair',heads.flatMap(h=>m.cosmetics.filter(c=>c.slot==='hair').map(hair=>({label:h.id+' '+hair.id,config:{...DEFAULT_PORTRAIT,equipment:{...DEFAULT_PORTRAIT.equipment,head:h.id,hair:hair.id}}}))),7);
await sheet('heads_skins',heads.flatMap(h=>m.skins.map(s=>({label:h.id+' '+s.id,config:{...DEFAULT_PORTRAIT,skin:s.id as PortraitConfig['skin'],equipment:{...DEFAULT_PORTRAIT.equipment,head:h.id}}}))),12);
await sheet('heads_ears',heads.flatMap(h=>m.cosmetics.filter(c=>c.slot==='ears').map(e=>({label:h.id+' '+e.id,config:{...DEFAULT_PORTRAIT,equipment:{...DEFAULT_PORTRAIT.equipment,head:h.id,hair:null,ears:e.id}}}))),2);
await writeFile(`${root}/default.png`,(await renderPortrait(DEFAULT_PORTRAIT)).png);
console.log('Head, expression, hair, ear and skin compatibility sheets generated.');
