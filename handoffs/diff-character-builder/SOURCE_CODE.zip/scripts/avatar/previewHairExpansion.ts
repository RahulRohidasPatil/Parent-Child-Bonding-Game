import {mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,type CollectionConfig} from '../../src/collection/model.js';
import {HAIR_COLOR_IDS} from '../../src/collection/hairPalettes.js';
const root=process.argv[2]??'artifacts/avatar-hair-expansion/review';await mkdir(root,{recursive:true});
const m=await collectionManifest(),hairs=m.cosmetics.filter(c=>c.slot==='hair');
type Cell={label:string;config:CollectionConfig};
async function sheet(name:string,cells:Cell[],cols:number,full=false,scale=4){
 const w=full?256:48*scale,h=full?256:70*scale,out=new Raster(cols*w,Math.ceil(cells.length/cols)*h);out.rect(0,0,out.width,out.height,[238,240,232,255]);
 for(let i=0;i<cells.length;i++){const p=decodePng((await renderCollection(cells[i].config)).png);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const c=full?p.pixel(Math.floor(x/2),Math.floor(y/2)):p.pixel(40+Math.floor(x/scale),Math.floor(y/scale));if(c[3])out.set(i%cols*w+x,Math.floor(i/cols)*h+y,c);}}
 await writePng(root+'/'+name+'.png',out);await writeFile(root+'/'+name+'.json',JSON.stringify(cells,null,2));
}
const equip=(hair:string,extra:Partial<CollectionConfig['equipment']>={}):CollectionConfig=>({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hair,...extra}});
await sheet('all_'+hairs.length+'_styles',hairs.map(h=>({label:h.name,config:equip(h.id)})),6,true);
for(const head of m.cosmetics.filter(c=>c.slot==='head'))await sheet('head_'+head.id.replace('head.',''),hairs.map(h=>({label:h.name,config:equip(h.id,{head:head.id})})),6);
for(const hat of m.cosmetics.filter(c=>c.slot==='hat'))await sheet('hat_'+hat.id.replace('hat.',''),hairs.map(h=>({label:h.name,config:{...equip(h.id,{hat:hat.id}),hairColor:'hair.platinum'}})),6);
for(let start=0;start<hairs.length;start+=9)await sheet('colors_'+(1+start/9),hairs.slice(start,start+9).flatMap(h=>HAIR_COLOR_IDS.map(hairColor=>({label:h.name+' '+hairColor,config:{...equip(h.id),hairColor}}))),12,false,3);
console.log(`Saved ${hairs.length} styles, six head matrices, two hat matrices, and ${hairs.length*HAIR_COLOR_IDS.length} color previews to ${root}`);
