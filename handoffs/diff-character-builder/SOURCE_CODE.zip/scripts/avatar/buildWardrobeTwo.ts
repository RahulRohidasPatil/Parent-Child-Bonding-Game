import {readFile,writeFile,mkdir,cp,mkdtemp} from 'node:fs/promises';
import {resolve} from 'node:path';
import {appendWardrobeTwo} from '../../src/collection/wardrobeTwoAuthoring.js';
import {applyCatalogNames} from '../../src/collection/catalogNames.js';
import {validateCollectionPack,randomCollection} from './validateCollection.js';
import {publishValidatedPack} from './publishPack.js';
import {createCollectionRenderer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,type CollectionManifest} from '../../src/collection/model.js';
const root='artifacts/avatar-wardrobe-two',output='assets/avatar/atelier-r6',publish=process.argv.includes('--publish');
await mkdir(root,{recursive:true});const staging=await mkdtemp(resolve(root,'staging_'));await cp(output,staging,{recursive:true});
const before=JSON.parse(await readFile(output+'/manifest.json','utf8')) as CollectionManifest,m=structuredClone(before);
const result=await appendWardrobeTwo(staging,m,process.argv.includes('--available'));applyCatalogNames(m);
await writeFile(staging+'/manifest.json',JSON.stringify(m,null,2));
const pack=await validateCollectionPack(staging),renderer=createCollectionRenderer(staging);
for(const [file,hash]of Object.entries(before.compiledHashes!))if(m.compiledHashes![file]!==hash)throw Error('Existing layer changed: '+file);
let rendered=0;
for(const id of result.included){const item=m.cosmetics.find(c=>c.id===id)!;for(const head of m.cosmetics.filter(c=>c.slot==='head'))for(const skin of m.skins){const c=structuredClone(DEFAULT_COLLECTION);c.equipment[item.slot]=id;c.equipment.head=head.id;c.skin=skin.id as typeof c.skin;const r=await renderer.render(c);if(r.warnings.length)throw Error('Render fallback: '+id);rendered++;}}
if(publish){if(result.missing.length||result.included.length!==20)throw Error('Cannot publish a partial pack');for(let i=0;i<5000;i++){if((await renderer.render(randomCollection(m,85000+i))).warnings.length)throw Error('Random fallback '+i);}await publishValidatedPack(staging,output,root+'/archives',validateCollectionPack);}
await writeFile(root+'/build-state.json',JSON.stringify({staging,...result,pack,rendered,published:publish},null,2));console.log({staging,...result,pack,rendered,published:publish});
