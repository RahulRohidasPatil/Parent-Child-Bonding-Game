import {mkdir,writeFile} from 'node:fs/promises';
const shoes=[
 ['court_high','Retro court high','Sneakers','Jordan-inspired retro basketball high-top sneakers: padded ankle collar, layered leather panels, perforated toe, broad flat rubber sole; original unbranded design',14],
 ['court_mid','Court mid','Sneakers','mid-top basketball sneakers with ankle strap, simple leather panels and flat cupsole',13],
 ['court_low','Court low','Sneakers','low-cut retro basketball leather sneakers with perforated toe box and contrast heel counter',10],
 ['skate_chunky','Chunky skate','Sneakers','wide padded skate shoes with fat tongue, thick laces and chunky gum sole',11],
 ['suede_terrace','Suede terrace','Sneakers','slim suede terrace sneakers, rounded T toe cap and low gum sole, no stripe logo',9],
 ['canvas_high','Canvas high','Sneakers','high-top canvas sneakers with circular metal eyelets and contrasting rubber toe cap',14],
 ['canvas_low','Canvas low','Sneakers','low canvas lace-up sneakers with contrasting rubber toe cap',9],
 ['slip_on','Canvas slip-on','Sneakers','canvas skate slip-on shoes with elastic gores and clean white rubber sole',9],
 ['retro_mesh','Retro mesh runner','Running','retro mesh running sneakers with layered suede panels, wedge midsole and dark tread',11],
 ['performance_runner','Performance runner','Running','modern running shoes with breathable mesh, curved rocker sole and small reflective panel',12],
 ['trail_grip','Trail grip','Running','trail running shoes with rugged lugged outsole, reinforced toe and quicklace detail',12],
 ['knit_runner','Knit runner','Running','sock-knit running sneakers with ribbed ankle opening and segmented cushioned sole',12],
 ['platform_sneaker','Platform sneaker','Sneakers','minimal low sneakers with tall platform rubber sole and simple laces',12],
 ['tennis_court','Tennis court','Sport','classic tennis court shoes with low leather uppers, narrow lacing and flat herringbone sole',10],
 ['hiking_lace','Hiking boot','Boots','ankle hiking boots with metal lace hooks, padded collar and rugged lug sole',16],
 ['work_lace','Work boot','Boots','sturdy lace-up work boots with round reinforced toe, six eyelets and thick welted sole',16],
 ['chelsea','Chelsea boot','Boots','sleek ankle Chelsea boots with elastic side panels, pull tabs and low heel',16],
 ['combat_lace','Lace-up combat boot','Boots','tall lace-up boots with eight eyelets, rounded toe and heavy tread',18],
 ['desert_suede','Desert boot','Boots','soft suede desert chukka boots, two eyelet lacing and thin crepe sole',14],
 ['winter_padded','Winter boot','Boots','padded winter boots with quilted shaft, drawcord and waterproof rubber lower',18],
 ['penny_loafer','Penny loafer','Smart','classic leather penny loafers, visible apron seam, saddle strap with small slot and low heel',9],
 ['tassel_loafer','Tassel loafer','Smart','leather tassel loafers with two tiny tassels, apron stitching and stacked low heel',9],
 ['derby_lace','Derby shoes','Smart','polished leather derby shoes with open lacing, rounded toe and slim welted soles',10],
 ['mary_jane','Mary Jane','Smart','rounded Mary Jane shoes with one instep strap and small metal buckle, low block heel',10],
 ['clog_cork','Cork clog','Relaxed','closed suede clogs with one side buckle and anatomically shaped cork sole; empty foot opening, no skin',10],
 ['house_mule','House mule','Relaxed','cozy closed-toe felt house mules with soft rounded uppers and thin flat outsole; empty opening, no feet',9]
] as const;
const tops=[
 ['boxy_heavy_tee','Boxy heavyweight tee','Everyday','boxy heavyweight crew-neck T-shirt, short sleeves ending at upper elbow, dropped shoulders and ribbed neck','short'],
 ['rugby_collar','Rugby shirt','Smart','long-sleeve rugby shirt with contrasting cream collar, broad two-tone chest band and ribbed cuffs','long'],
 ['knit_polo','Knit polo','Smart','short-sleeve knit polo with open three-button placket, ribbed hem and small collar','short'],
 ['waffle_henley','Waffle henley','Everyday','long-sleeve waffle henley, narrow three-button placket and subtle chunky waffle knit','long'],
 ['mockneck_zip','Mockneck half zip','Sport','athletic half zip with low standing collar, center zip ending at chest, narrow shoulder piping','long'],
 ['relaxed_cardigan','Relaxed cardigan','Smart','closed relaxed V-neck cardigan, five contrasting buttons, two patch pockets and ribbed cuffs','long']
] as const;
const jackets=[
 ['box_puffer','Box puffer','Winter','closed boxy puffer jacket with wide horizontal quilted baffles, low stand collar and center zipper',true],
 ['hooded_puffer','Hooded puffer','Winter','closed hooded winter puffer jacket, three broad quilted baffles, deep hood opening behind neck and zipper',true],
 ['quilt_liner','Quilted liner','Everyday','open collarless quilted liner jacket with subtle large diamond quilting and snap edges',false],
 ['flight_bomber','Flight bomber','Street','open flight bomber with ribbed collar and cuffs, sleeve utility pocket and zipper',false],
 ['varsity_wool','Wool varsity','Street','open wool varsity jacket with cream sleeves, plain ribbed collar and snap buttons, no lettering',false],
 ['denim_trucker','Denim trucker','Everyday','open denim trucker jacket with pointed collar, two angled chest flap pockets and metal buttons',false],
 ['leather_biker','Biker jacket','Street','open leather-style biker jacket with broad asymmetric lapels, diagonal zip and restrained silver hardware',false],
 ['rain_parka','Rain parka','Tech','closed hip-length hooded rain parka with storm flap, drawcord and two large slant pockets',true],
 ['sherpa_fleece','Sherpa fleece','Winter','open sherpa fleece jacket, chunky fleece blocks, contrast chest pocket and low standing collar',false],
 ['track_piped','Piped track jacket','Training','closed track warmup jacket with tall collar, center zipper and one curved contrast piping line along each sleeve; no brand stripe patterns',true]
] as const;
const bottoms=[
 ['baggy_denim','Baggy jeans','Denim','very baggy straight-leg jeans, wide relaxed thighs and stacked hems, five-pocket construction',30],
 ['wide_denim','Wide-leg jeans','Denim','wide-leg clean denim jeans with a generous continuous leg silhouette and broad hems',30],
 ['carpenter_denim','Carpenter jeans','Denim','relaxed carpenter jeans with double-knee panels, side utility pocket and hammer loop',28],
 ['barrel_denim','Barrel jeans','Denim','barrel-cut jeans with rounded outer legs tapering subtly at ankle, curved seams',30],
 ['parachute_cargo','Parachute cargo','Street','baggy nylon parachute cargo pants with large bellows thigh pockets and gathered ankle drawcords',30],
 ['pleated_wide','Wide pleated trousers','Smart','wide tailored trousers with double front pleats and clean pressed center creases',28],
 ['stacked_sweats','Stacked sweatpants','Everyday','relaxed straight sweatpants with drawstring waist, soft folds and stacked ribless hems',29],
 ['piped_warmup','Piped warmup pants','Training','loose track warmup pants with a single curved piping detail at side, subtly tapered ankle and drawcord waistband',28]
] as const;
const reference='/Users/vlad/Documents/ChatGPT/DIFF/references/avatar-exact-v5/body-reference.png';
const jobs=[...shoes.map(([key,name,collection,description,height])=>({id:'shoes.'+key,name,collection,description,kind:'shoes',height,width:36})),...tops.map(([key,name,collection,description,sleeve])=>({id:'top.'+key,name,collection,description,kind:'top',sleeve,closed:true})),...jackets.map(([key,name,collection,description,closed])=>({id:'jacket.'+key,name,collection,description,kind:'jacket',closed})),...bottoms.map(([key,name,collection,description,width])=>({id:'bottom.'+key,name,collection,description,kind:'bottom',width}))].map(j=>({...j,color:'Slate blue',source:j.id.replace('.','_')+'.png',refs:[reference],prompt:`Use case: stylized-concept. Asset type: ONE modular pixel-avatar ${j.kind==='shoes'?'matching pair of shoes':j.kind} layer. Reference image is the approved character style and exact pose. Create ONLY ${j.description}. ${j.kind==='shoes'?'Both shoes worn by a front-facing character, left toe points slightly left and right toe slightly right, mirrored pair at equal height, separated by a clear small central gap. Show BOTH entire shoes on the same horizontal sole baseline. No legs, feet, skin or socks.':j.kind==='bottom'?'Front-facing pants, upright, both legs straight and separated by a narrow clear gap, waistband level and hems on same line. Empty garment only: no torso, hands, legs, feet or shoes.':'Front-facing empty garment with both sleeves relaxed downward following the reference arms, narrow gaps between sleeves and torso. Neck opening clear. No head, face, neck, skin, hands, body or pants. Sleeves and hem must fit the reference stance.'} Use the same deliberately coarse modern pixel art as the character, clean stair-step silhouette, dark one-logical-pixel outline, broad clusters with 3–5 values per material, readable at small size. Main material is medium slate BLUE, highlights lighter blue and shadows dark navy. Secondary panels, rubber soles, laces, metal hardware and trim use neutral cream/gray so material roles can be isolated. No extra graphics, brand logos, text, watermarks or labels. Genuine transparent RGBA background including openings, NOT a painted checkerboard or solid backdrop. Center the entire item on a square canvas with generous clear margins. No display board, no additional items or characters. This is real source artwork for an aligned 128×128 avatar layer.`}));
if(jobs.length!==50)throw Error('Expected 50');await mkdir('references/avatar-wardrobe-expansion',{recursive:true});await writeFile('references/avatar-wardrobe-expansion/prompts.json',JSON.stringify({mode:'built-in image_gen',jobs},null,2));console.log('Defined '+jobs.length+' sources');
