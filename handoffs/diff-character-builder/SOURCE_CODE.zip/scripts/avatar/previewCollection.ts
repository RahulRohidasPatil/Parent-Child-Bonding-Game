import {mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng} from '../../src/avatar/raster.js';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,CollectionConfig,collectionPresets} from '../../src/collection/model.js';
const m=await collectionManifest(),root=process.argv[2]??'assets/avatar/atelier-r6/previews';await mkdir(root,{recursive:true});
type Cell={label:string;config:CollectionConfig};
async function sheet(name:string,cells:Cell[],cols:number,mode:'face'|'full'='full'){
 const w=mode==='face'?192:256,h=mode==='face'?228:256,out=new Raster(cols*w,Math.ceil(cells.length/cols)*h);out.rect(0,0,out.width,out.height,[238,240,232,255]);
 for(let i=0;i<cells.length;i++){const p=decodePng((await renderCollection(cells[i].config)).png);for(let y=0;y<h;y++)for(let x=0;x<w;x++){const color=mode==='face'?p.pixel(48+Math.floor(x/6),2+Math.floor(y/6)):p.pixel(Math.floor(x/2),Math.floor(y/2));if(color[3])out.set((i%cols)*w+x,Math.floor(i/cols)*h+y,color);}}
 await writePng(`${root}/${name}.png`,out);await writeFile(`${root}/${name}.json`,JSON.stringify(cells,null,2));
}
const equip=(values:Partial<CollectionConfig['equipment']>):CollectionConfig=>({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,...values}});
await writePng(`${root}/default.png`,decodePng((await renderCollection(DEFAULT_COLLECTION)).png));
await writePng(`${root}/default_4x.png`,decodePng((await renderCollection(DEFAULT_COLLECTION)).png).upscale(4));
await sheet('heads',m.cosmetics.filter(c=>c.slot==='head').flatMap(c=>[{label:c.name,config:equip({head:c.id})}]),6,'face');
await sheet('blank_heads',m.cosmetics.filter(c=>c.slot==='head').map(c=>({label:c.name,config:equip({head:c.id,hair:null,eyes:null,brows:null,nose:null,mouth:null,ears:null})})),6,'face');
await sheet('expressions',m.cosmetics.filter(c=>c.slot==='head').flatMap(h=>['neutral','friendly','focused'].map(f=>({label:h.name+' '+f,config:equip({head:h.id,eyes:'eyes.reference_'+f,brows:'brows.reference_'+f,nose:'nose.reference_'+f,mouth:'mouth.reference_'+f})}))),6,'face');
for(const slot of ['top','jacket','bottom','shoes'] as const)await sheet(slot,m.cosmetics.filter(c=>c.slot===slot).map(c=>({label:c.id,config:equip({[slot]:c.id})})),6);
await sheet('head_hair',m.cosmetics.filter(c=>c.slot==='head').flatMap(h=>[null,...m.cosmetics.filter(c=>c.slot==='hair').map(c=>c.id)].map(hair=>({label:h.name+' '+hair,config:equip({head:h.id,hair})}))),8,'face');
await sheet('presets',collectionPresets().map(p=>({label:p.name,config:p.config})),4);
const jackets=[null,...m.cosmetics.filter(c=>c.slot==='jacket').map(c=>c.id)],tops=[null,...m.cosmetics.filter(c=>c.slot==='top').map(c=>c.id)];
for(let j=0;j<jackets.length;j++)await sheet(`top_jacket_${String(j).padStart(2,'0')}`,tops.map(top=>({label:String(top)+' + '+jackets[j],config:equip({top,jacket:jackets[j]})})),5);
for(let i=0;i<m.skins.length;i++)await sheet(`skin_heads_${String(i+1).padStart(2,'0')}`,m.cosmetics.filter(c=>c.slot==='head').flatMap(h=>['neutral','friendly','focused'].map(f=>({label:m.skins[i].id+' '+h.name+' '+f,config:{...equip({head:h.id,eyes:'eyes.reference_'+f,brows:'brows.reference_'+f,nose:'nose.reference_'+f,mouth:'mouth.reference_'+f}),skin:m.skins[i].id as CollectionConfig['skin']}}))),6,'face');
console.log(root);
