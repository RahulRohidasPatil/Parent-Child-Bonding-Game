import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve } from 'node:path';
import { normalizeImagegenSource, IMAGEGEN_SOURCES } from '../../src/avatar/imageSources.js';
import { Raster, encodePng } from '../../src/avatar/raster.js';
import { SKIN_PALETTES } from '../../src/avatar/palettes.js';
import type { StudioAsset, StudioManifest } from '../../src/studio/model.js';

// Offline selection masks copy image pixels; no drawing primitives author cosmetics.
const out=resolve('assets/avatar/studio-r1');
const inputs=Object.fromEntries(await Promise.all(Object.keys(IMAGEGEN_SOURCES).map(async key=>[key,await normalizeImagegenSource(key as keyof typeof IMAGEGEN_SOURCES)]))) as Record<string,Raster>;
type Point=[number,number];
const polygon=(pts:Point[])=>(x:number,y:number)=>{let inside=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){const a=pts[i],b=pts[j];if((a[1]>y)!==(b[1]>y)&&x<(b[0]-a[0])*(y-a[1])/(b[1]-a[1])+a[0])inside=!inside;}return inside;};
const region=(l:number,t:number,r:number,b:number)=>(x:number,y:number)=>x>=l&&x<=r&&y>=t&&y<=b;
const dark=(p:readonly number[])=>p[3]===255&&Math.max(p[0],p[1],p[2])<150;
const skin=(p:readonly number[])=>p[3]===255&&p[0]>100&&p[0]>p[1]*1.12&&p[1]>p[2]*1.10;
const list:StudioAsset[]=[];
await mkdir(out,{recursive:true});
async function persist(file:string,bytes:Buffer){const target=resolve(out,file);try{const old=await readFile(target);if(!old.equals(bytes))throw new Error(`Preserved existing image differs: ${target}. Use a new pack revision.`);}catch(err){if((err as NodeJS.ErrnoException).code!=='ENOENT')throw err;await writeFile(target,bytes,{flag:'wx'});}}
async function layer(id:string,name:string,slot:string,z:number,source:string,bounds:[number,number,number,number],select:(x:number,y:number,p:readonly number[])=>boolean,src=inputs[source]){
  const img=new Raster(128,128);for(let y=0;y<128;y++)for(let x=0;x<128;x++){const p=src.pixel(x,y);if(p[3]&&select(x,y,p))img.set(x,y,p);}
  const file=id.replaceAll('.','_')+(id==='mouth.smile'?'_r2':'')+'.png';await persist(file,encodePng(img));list.push({id,name,slot,z,source:IMAGEGEN_SOURCES[source as keyof typeof IMAGEGEN_SOURCES],file,bounds});
}
// The single featureless master is fitted to the existing outfit's shared anchors at import time.
// The fit applies to every skin and every outfit; runtime never transforms a layer.
const body=new Raster(128,128), master=inputs.body;
const mapY=(y:number)=>y<38?4+(y-14)*30/24:y<76?34+(y-38)*42/38:76+(y-76)*48/48;
for(let y=14;y<124;y++)for(let x=42;x<=86;x++){
  const sx=Math.round(64+(x-64)*(y<38?1:1.15));
  body.set(x,y,master.pixel(sx,Math.round(mapY(y))));
}
for(const [id,pal] of Object.entries(SKIN_PALETTES)){
  const painted=new Raster(128,128);
  for(let y=0;y<128;y++)for(let x=0;x<128;x++){const p=body.pixel(x,y);const light=(p[0]+p[1]+p[2])/3;painted.set(x,y,skin(p)?light>207?pal.highlight:light>168?pal.base:light>122?pal.shadow:pal.outlineShadow:p);}
  await layer(`body.${id}`,`Skin ${id.slice(-2)}`,'body',20,'body',[42,14,86,124],()=>true,painted);
}
await layer('eyes.neutral','Neutral eyes','eyes',60,'base',[56,25,72,30],(x,y,p)=>region(57,25,61,29)(x,y)||region(68,25,72,29)(x,y));
await layer('brows.straight','Straight brows','brows',62,'base',[55,22,74,23],(x,y,p)=>(region(55,22,61,23)(x,y)||region(67,22,74,23)(x,y))&&dark(p));
await layer('mouth.smile','Small smile','mouth',64,'base',[62,32,66,34],(x,y,p)=>region(62,32,66,34)(x,y)&&p[0]<240);
await layer('hair.fluffy.front','Fluffy middle part','hair_front',70,'base',[47,4,81,30],(x,y,p)=>dark(p)&&((y<=21)||(y<=30&&(x<=55||x>=73))));
// Garments use full silhouettes. A cap is never a pixel difference against a hairstyle.
await layer('hat.cap','Classic cap','headwear',90,'cap',[50,2,79,18],(x,y,p)=>region(50,2,79,18)(x,y)&&dark(p));
await layer('hat.beanie','Folded beanie','headwear',90,'beanie',[49,2,79,18],(x,y,p)=>region(49,2,79,18)(x,y)&&dark(p));
const collar=polygon([[59,37],[62,43],[63,44],[65,44],[69,37],[70,36],[84,49],[87,71],[82,74],[77,72],[74,74],[51,74],[51,73],[44,74],[41,65],[46,45],[57,36]]);
await layer('top.cream','Fleece quarter zip','top',50,'base',[41,36,87,74],(x,y,p)=>collar(x,y)&&!region(61,36,68,40)(x,y));
await layer('bottom.straight','Straight trousers','bottom',30,'base',[52,74,76,116],(x,y,p)=>region(52,74,76,116)(x,y));
await layer('bottom.track','Track pants','bottom',30,'trackPants',[51,74,77,117],(x,y,p)=>region(51,74,77,117)(x,y)&&!skin(p));
await layer('shoes.white','Low sneakers','shoes',40,'base',[48,116,81,124],(x,y,p)=>region(48,116,81,124)(x,y));
const jacket=polygon([[58,36],[60,37],[60,76],[48,76],[42,72],[40,60],[43,47],[53,40]]);
const rightJacket=polygon([[70,36],[68,40],[68,76],[82,76],[86,73],[89,67],[86,49],[79,42]]);
await layer('jacket.track','Track jacket','outerwear',55,'trackJacket',[40,36,89,76],(x,y,p)=>(jacket(x,y)||rightJacket(x,y))&&!skin(p));
const hairArea=polygon([[46,8],[82,8],[82,61],[74,61],[72,47],[75,40],[72,35],[72,29],[73,26],[70,24],[69,20],[68,18],[59,18],[57,23],[54,27],[55,34],[54,41],[57,49],[55,61],[46,61]]);
await layer('hair.long_wavy.back','Long wavy · back','hair_back',10,'longWavy',[46,8,82,62],(x,y,p)=>hairArea(x,y)&&dark(p)&&y>=32&&(x<51||x>77));
await layer('hair.long_wavy.front','Long wavy · front','hair_front',70,'longWavy',[46,8,82,62],(x,y,p)=>hairArea(x,y)&&dark(p)&&!(y>=32&&(x<51||x>77)));
// Spectacle rims are selected from the original edit, with the lens interior excluded.
const leftLens=(x:number,y:number)=>((x-57)/4.4)**2+((y-27)/3.7)**2;
const rightLens=(x:number,y:number)=>((x-68)/4.4)**2+((y-27)/3.7)**2;
await layer('glasses.round','Round glasses','glasses',82,'glasses',[51,22,74,33],(x,y,p)=>region(51,22,74,33)(x,y)&&dark(p)&&((leftLens(x,y)>.55&&leftLens(x,y)<1.7)||(rightLens(x,y)>.55&&rightLens(x,y)<1.7)||region(61,25,64,26)(x,y)));
const sourceHashes:Record<string,string>={};for(const path of Object.values(IMAGEGEN_SOURCES))sourceHashes[path]=createHash('sha256').update(await readFile(resolve(path))).digest('hex');
const manifest:StudioManifest={version:1,pack:'studio-r1',size:128,assets:list,sources:IMAGEGEN_SOURCES,sourceHashes};
await writeFile(resolve(out,'manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(`Studio pack: ${list.length} image layers. All previous PNGs preserved.`);
