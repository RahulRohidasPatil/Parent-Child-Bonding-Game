import {applyCatalogNames} from '../../src/collection/catalogNames.js';
import {appendHairLibrary} from '../../src/collection/hairLibraryAuthoring.js';
import {readFile,writeFile,mkdir,cp,mkdtemp,stat} from 'node:fs/promises';
import {resolve} from 'node:path';
import {createHash} from 'node:crypto';
import {Raster,encodePng,decodePng,writePng} from '../../src/avatar/raster.js';
import {isolateHairSource,compileHairSource,type HairSourceJob} from '../../src/collection/hairAuthoring.js';
import {libraryHairTraits} from '../../src/selfie/hairLibraryTraits.js';
import {hairDetails,type HairDetails} from '../../src/collection/hairCatalog.js';
import {calibratedHairToneMask} from '../../src/collection/recolor.js';
import {createCollectionRenderer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,type CollectionManifest,type CollectionLayer} from '../../src/collection/model.js';
import {validateCollectionPack,randomCollection} from './validateCollection.js';
import {publishValidatedPack} from './publishPack.js';
const SOURCE='references/avatar-hair-library',OUTPUT='assets/avatar/atelier-r6',available=process.argv.includes('--available'),publish=process.argv.includes('--publish');
const definition=JSON.parse(await readFile(SOURCE+'/prompts.json','utf8'));
const jobs=definition.jobs as (HairSourceJob&{texture:string;fringe:string})[];
if(jobs.length!==65||new Set(jobs.map(j=>j.id)).size!==65)throw Error('Expected 65 distinct new hairstyle jobs');
await mkdir('artifacts/avatar-hair-library',{recursive:true});
const staging=await mkdtemp(resolve('artifacts/avatar-hair-library/staging_'));await cp(OUTPUT,staging,{recursive:true});
const m=JSON.parse(await readFile(staging+'/manifest.json','utf8')) as CollectionManifest;
const {included,missing}=await appendHairLibrary(staging,m,available);
if(publish&&(missing.length||included.length!==65))throw Error('Only the complete reviewed library may be published');
for(const item of m.cosmetics.filter(c=>c.slot==='hair'))item.hairDetails=hairDetails(item);
applyCatalogNames(m);
await writeFile(staging+'/manifest.json',JSON.stringify(m,null,2));
await validateCollectionPack(staging);
const renderer=createCollectionRenderer(staging),heads=m.cosmetics.filter(c=>c.slot==='head');
const cells: {label:string;png:Raster}[]=[];
for(const id of included)for(const head of heads){const result=await renderer.render({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hair:id,head:head.id}});if(result.warnings.length)throw Error('Unexpected render fallback '+id);cells.push({label:id+' / '+head.id,png:decodePng(result.png)});}
// Review sheets show real composites, with a shared head crop and nearest-neighbor display only.
const columns=6,scale=4,w=48*scale,h=76*scale,sheet=new Raster(columns*w,Math.ceil(cells.length/columns)*h);sheet.rect(0,0,sheet.width,sheet.height,[238,240,232,255]);
for(let i=0;i<cells.length;i++)for(let y=0;y<h;y++)for(let x=0;x<w;x++){const pixel=cells[i].png.pixel(40+Math.floor(x/scale),Math.floor(y/scale));if(pixel[3])sheet.set(i%columns*w+x,Math.floor(i/columns)*h+y,pixel);}
await writePng('artifacts/avatar-hair-library/checkpoint-all-heads.png',sheet);
for(let start=0;start<included.length;start+=5){const rows=Math.min(5,included.length-start),page=new Raster(columns*w,rows*h);page.rect(0,0,page.width,page.height,[238,240,232,255]);for(let y=0;y<page.height;y++)for(let x=0;x<page.width;x++)page.set(x,y,sheet.pixel(x,start*h+y));await writePng('artifacts/avatar-hair-library/heads_'+String(1+start/5).padStart(2,'0')+'.png',page);}
await writeFile('artifacts/avatar-hair-library/checkpoint-all-heads.json',JSON.stringify(cells.map(c=>c.label),null,2));
if(publish){for(let i=0;i<5000;i++){const result=await renderer.render(randomCollection(m,72000+i));if(result.warnings.length)throw Error('Random combination fallback '+i);}await publishValidatedPack(staging,OUTPUT,'artifacts/avatar-hair-library/archives',validateCollectionPack);}
await writeFile('artifacts/avatar-hair-library/build-state.json',JSON.stringify({staging,included,missing,published:publish},null,2));console.log({staging,included:included.length,missing:missing.length,published:publish});
