import {readFile,readdir,mkdir,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {exactManifest,renderExact} from '../../src/exact/render.js';
import {DEFAULT_EXACT,EXACT_SLOTS,EYE_COLORS,ExactConfig,ExactManifest,exactPresets,validateExact} from '../../src/exact/model.js';
import {decodePng,Raster,writePng} from '../../src/avatar/raster.js';

const ROOT='assets/avatar/atelier-r5';
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
export function randomExact(m:ExactManifest,seed:number):ExactConfig{
 // Mix neighboring seeds before the LCG so contact-sheet rows cover all palettes.
 let state=seed>>>0;state=Math.imul(state^(state>>>16),0x21f0aaad);state=Math.imul(state^(state>>>15),0x735a2d97);state=(state^(state>>>15))>>>0;
 const rand=()=>{state=(Math.imul(state,1664525)+1013904223)>>>0;return state/4294967296;};
 const pick=<T>(items:T[])=>items[Math.floor(rand()*items.length)];
 const c=structuredClone(DEFAULT_EXACT);c.skin=pick(m.skins).id as ExactConfig['skin'];c.eyeColor=pick([...EYE_COLORS]);
 for(const slot of EXACT_SLOTS){c.equipment[slot]=pick(m.cosmetics.filter(a=>a.slot===slot)).id;if(['hat','glasses','jacket','earrings'].includes(slot)&&rand()<.55)(c.equipment as Record<string,string|null>)[slot]=null;}
 return validateExact(c,m);
}
export function checkPng(bytes:Buffer,name:string,mask?:PNG){
 const p=PNG.sync.read(bytes);if(p.width!==128||p.height!==128||bytes[24]!==8||bytes[25]!==6)throw new Error('Expected RGBA8 128×128: '+name);
 let opaque=0;for(let i=0;i<16384;i++){const a=p.data[i*4+3];if(a!==0&&a!==255)throw new Error('Partial alpha: '+name);if(a){opaque++;if(mask&&!mask.data[i*4+3])throw new Error(`Forbidden pixel ${i%128},${Math.floor(i/128)}: ${name}`);}}
 if(!opaque||opaque===16384)throw new Error('Expected nonempty transparent layer: '+name);
 for(let at=8;at<bytes.length;){const n=bytes.readUInt32BE(at),type=bytes.toString('ascii',at+4,at+8);if(!['IHDR','IDAT','IEND'].includes(type))throw new Error('Unexpected PNG metadata '+type+': '+name);at+=n+12;}
 return p;
}
export async function validateExactPack(){
 const m=await exactManifest(),files=new Set<string>();
 if(m.version!==5||m.size!==128||m.rig!=='front_reference_v1')throw new Error('Wrong rig protocol');
 if(new Set(m.cosmetics.map(c=>c.id)).size!==m.cosmetics.length)throw new Error('Duplicate IDs');
 if(m.skins.length!==12||Object.keys(m.eyeColorSources).length!==6)throw new Error('Incomplete palettes');
 for(const l of [...m.skins.map(s=>s.layer),...m.cosmetics.flatMap(c=>c.layers)]){
  if(l.skinVariants&&m.skins.some(s=>!l.skinVariants![s.id]))throw new Error('Missing skin variant');
  if(l.eyeVariants&&EYE_COLORS.some(e=>!l.eyeVariants![e]))throw new Error('Missing eye variant');
  const maskFile=m.slotMasks?.[l.region];if(!maskFile)throw new Error('Missing legal slot mask '+l.region);
  const mask=checkPng(await readFile(`${ROOT}/${maskFile}`),maskFile);
  for(const f of new Set([l.file,...Object.values(l.skinVariants??{}),...Object.values(l.eyeVariants??{})])){
   files.add(f);if(!/^layers\/[a-z0-9_]+_v5\.png$/.test(f))throw new Error('Bad filename '+f);
   const bytes=await readFile(`${ROOT}/${f}`);checkPng(bytes,f,mask);
   if(sha(bytes)!==m.compiledHashes?.[f])throw new Error('Changed compiled pixels '+f);
  }
  if(!Object.values(m.sources).includes(l.source))throw new Error('Unlisted source '+l.source);
  for(const spec of l.hide??[]){const [region,key]=spec.split(':');if(!m.regions[region]||!m.masks[key])throw new Error('Invalid masking rule '+spec);}
 }
 for(const f of await readdir(`${ROOT}/layers`))if(!files.has('layers/'+f))throw new Error('Orphaned layer '+f);
 for(const f of new Set([...Object.values(m.masks),...Object.values(m.partitionMasks),...Object.values(m.slotMasks!)]))checkPng(await readFile(`${ROOT}/${f}`),f);
 for(const [path,hash]of Object.entries(m.pictureHashes))if(sha(await readFile(path))!==hash)throw new Error('Source changed '+path);
 const master=await readFile(`${ROOT}/${m.master}`);if(sha(master)!==m.masterHash)throw new Error('Reference golden changed');
 if(!(await renderExact(DEFAULT_EXACT)).png.equals(master))throw new Error('Default no longer reconstructs reference pixels exactly');
 for(const p of exactPresets())validateExact(p.config,m);
 return{modules:m.cosmetics.length,heads:m.cosmetics.filter(c=>c.slot==='head').length,skins:m.skins.length,eyeColors:EYE_COLORS.length,layerFiles:files.size,referenceRecomposition:'byte-identical'};
}
if(process.argv[1]&&/validateExact\.(ts|js)$/.test(process.argv[1])){
 const summary=await validateExactPack(),m=await exactManifest(),start=Date.now(),sheet=new Raster(1280,2560),samples:ExactConfig[]=[];
 sheet.rect(0,0,sheet.width,sheet.height,[238,240,232,255]);
 for(let i=0;i<5000;i++){
  const c=randomExact(m,24000+i),r=await renderExact(c);checkPng(r.png,'random '+i);
  if(i<200){samples.push(c);const p=decodePng(r.png);for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(p.pixel(x,y)[3])sheet.set((i%10)*128+x,Math.floor(i/10)*128+y,p.pixel(x,y));}
 }
 const folder='artifacts/avatar-exact-v5/qa';await mkdir(folder,{recursive:true});
 await writePng(`${folder}/200_random_avatars.png`,sheet);await writeFile(`${folder}/200_random_avatars.json`,JSON.stringify(samples,null,2));
 const report={...summary,randomRenders:5000,failures:0,visualSample:{count:samples.length,skins:new Set(samples.map(s=>s.skin)).size,eyeColors:new Set(samples.map(s=>s.eyeColor)).size,cosmetics:new Set(samples.flatMap(s=>Object.values(s.equipment).filter(Boolean))).size},seconds:(Date.now()-start)/1000};await writeFile(`${folder}/validation.json`,JSON.stringify(report,null,2));console.log(report);
}
