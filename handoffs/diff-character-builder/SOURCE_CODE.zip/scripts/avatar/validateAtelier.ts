import {readFile,readdir,writeFile,mkdir} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {AtelierManifest,DEFAULT_ATELIER,SLOTS,validateAtelier,AtelierConfig} from '../../src/atelier/model.js';
import {renderAtelier,atelierPresets} from '../../src/atelier/render.js';
const ROOT='assets/avatar/atelier-r2';
export async function validateCollection(){
  const m=JSON.parse(await readFile(`${ROOT}/manifest.json`,'utf8')) as AtelierManifest;
  if(m.version!==2||m.rig!=='front_idle_atelier_v1'||m.size!==128)throw new Error('Unexpected rig version');
  if(new Set(m.cosmetics.map(c=>c.id)).size!==m.cosmetics.length)throw new Error('Duplicate cosmetic ID');
  const entries=[...m.skins.map(s=>s.layer),...m.cosmetics.flatMap(c=>c.layers)],files=new Set<string>();let pixels=0;
  for(const l of entries){
    if(!m.regions[l.region])throw new Error('Unknown region '+l.region);
    const variants=[...new Set([l.file,...Object.values(l.skinVariants??{})])];
    if(l.skinVariants&&m.skins.some(s=>!l.skinVariants?.[s.id]))throw new Error('Missing skin variant '+l.file);
    for(const f of variants){
      if(!/^layers\/[a-z0-9_]+_v2\.png$/.test(f))throw new Error('Invalid filename '+f);files.add(f);
      const bytes=await readFile(`${ROOT}/${f}`),p=PNG.sync.read(bytes),[x,y,w,h]=m.regions[l.region];
      if(p.width!==128||p.height!==128||p.colorType!==6)throw new Error('Not 128×128 RGBA: '+f);
      if(f===l.file&&createHash('sha256').update(bytes).digest('hex')!==l.sha256)throw new Error('Layer checksum mismatch '+f);
      let opaque=0,clear=0;
      for(let yy=0;yy<128;yy++)for(let xx=0;xx<128;xx++){const alpha=p.data[(yy*128+xx)*4+3];if(alpha===0)clear++;else if(alpha===255){opaque++;if(xx<x||xx>=x+w||yy<y||yy>=y+h)throw new Error(`${f}: forbidden pixel at ${xx},${yy}`);}else throw new Error('Partial alpha '+f);}
      if(!opaque||!clear)throw new Error('Empty or opaque canvas '+f);pixels+=opaque;
    }
    for(const target of l.hide??[]){const [region,mask]=target.split(':');if(!m.regions[region]||!m.masks[mask])throw new Error('Unknown occlusion mask '+target);}
    if(!Object.values(m.sources).includes(l.source))throw new Error('Unlisted Imagegen source '+l.source);
  }
  for(const f of await readdir(`${ROOT}/layers`))if(!files.has('layers/'+f))throw new Error('Orphaned asset '+f);
  for(const [path,hash] of Object.entries(m.pictureHashes))if(createHash('sha256').update(await readFile(path)).digest('hex')!==hash)throw new Error('Source image was changed '+path);
  for(const path of Object.values(m.masks)){const p=PNG.sync.read(await readFile(`${ROOT}/${path}`));if(p.width!==128||p.height!==128||p.colorType!==6)throw new Error('Invalid mask');for(let i=3;i<p.data.length;i+=4)if(p.data[i]!==0&&p.data[i]!==255)throw new Error('Partial alpha mask');}
  for(const p of atelierPresets(DEFAULT_ATELIER))validateAtelier(p.config,m);
  return {cosmetics:m.cosmetics.length,skins:m.skins.length,layerFiles:files.size,opaquePixels:pixels,sources:Object.keys(m.sources).length};
}
export function randomConfiguration(m:AtelierManifest,seed:number):AtelierConfig{
  let n=seed>>>0;const random=()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};
  const c=structuredClone(DEFAULT_ATELIER);c.skin=m.skins[Math.floor(random()*m.skins.length)].id as AtelierConfig['skin'];
  for(const slot of SLOTS){const candidates=m.cosmetics.filter(a=>a.slot===slot);c.equipment[slot]=['hat','jacket','earrings','glasses'].includes(slot)&&random()<.45?null:candidates[Math.floor(random()*candidates.length)].id;}
  return c;
}
if(process.argv[1]&&/validateAtelier\.(ts|js)$/.test(process.argv[1])){
  const summary=await validateCollection(),m=JSON.parse(await readFile(`${ROOT}/manifest.json`,'utf8')) as AtelierManifest;
  const start=Date.now();for(let i=0;i<5000;i++){const c=randomConfiguration(m,i+75001);const output=await renderAtelier(c);const png=PNG.sync.read(output.png);if(png.width!==128||png.height!==128)throw new Error('Render size mismatch');for(let k=3;k<png.data.length;k+=4)if(png.data[k]!==0&&png.data[k]!==255)throw new Error('Render alpha corruption');}
  const report={...summary,randomRenders:5000,failures:0,seconds:(Date.now()-start)/1000};await mkdir('artifacts/avatar-atelier/qa',{recursive:true});await writeFile('artifacts/avatar-atelier/qa/validation.json',JSON.stringify(report,null,2));console.log(report);
}
