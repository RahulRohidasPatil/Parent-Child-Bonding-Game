import {appendWardrobeTwo} from '../../src/collection/wardrobeTwoAuthoring.js';
import {applyCatalogNames} from '../../src/collection/catalogNames.js';
import {appendHairLibrary} from '../../src/collection/hairLibraryAuthoring.js';
import {readFile,writeFile,mkdir,copyFile,mkdtemp,cp} from 'node:fs/promises';
import {resolve} from 'node:path';
import {garmentPositionMap,bottomPositionMap,connectPositionFragments,applyPositionMap,armCoverageGaps} from '../../src/collection/garmentPosition.js';
import {registerSuitSleeves} from '../../src/collection/suitSleeves.js';
import {identitySource,compileIdentity,featureSkin,eyeVariant,type IdentityJob} from '../../src/collection/identityAuthoring.js';
import {fit} from '../../src/atelier/pixels.js';
import {garmentSource as suitSource} from '../../src/collection/authoring.js';
import {publishValidatedPack} from './publishPack.js';
import {validateCollectionPack} from './validateCollection.js';
import {createHash} from 'node:crypto';
import {Raster,decodePng,encodePng,writePng} from '../../src/avatar/raster.js';
import {skinVariant} from '../../src/exact/authoring.js';
import {clone,blankHead,garmentSource,compileGarment,expressionParts,shoulderCoverageMask,waistCoverageMask,GARMENT_REGISTRATION} from '../../src/collection/authoring.js';
import {EYE_COLORS} from '../../src/collection/model.js';
import {COLLECTION_SLOTS,type CollectionManifest,type CollectionLayer,type CollectionCosmetic} from '../../src/collection/model.js';
import {type ExactManifest} from '../../src/exact/model.js';
import {hairToneMask,calibratedHairToneMask,wearToneMask} from '../../src/collection/recolor.js';
import {isolateHairSource,compileHairSource,fillBackHeadVolume,type HairSourceJob} from '../../src/collection/hairAuthoring.js';
import {wearAccentMasks,ACCENT_LABELS} from '../../src/collection/accentAuthoring.js';
import {WEAR_PALETTES,WEAR_SLOTS} from '../../src/collection/wearPalettes.js';
import {isolateWearSource,compileWearSource,type WearSourceJob} from '../../src/collection/wearAuthoring.js';
import {HAIR_PALETTES} from '../../src/collection/hairPalettes.js';
const polishJobs=JSON.parse(await readFile('references/avatar-polish/prompts.json','utf8')).jobs as {id:string;out:string}[];
const polishSource=(id:string,fallback:string)=>{const job=polishJobs.find(j=>j.id===id);return job?'references/avatar-polish/'+job.out:fallback;};
const OUTPUT=resolve('assets/avatar/atelier-r6'),OLD='assets/avatar/atelier-r5',REF='references/avatar-revision-v6';
const HAIR_REF='references/avatar-hair-expansion',IDENTITY_REF='references/avatar-identity-expansion';
const identityJobs=JSON.parse(await readFile(`${IDENTITY_REF}/prompts.json`,'utf8')).jobs as IdentityJob[];if(identityJobs.length!==38)throw Error('Expected 38 identity modules');
await mkdir('artifacts/avatar-builds',{recursive:true});
const ROOT=await mkdtemp(resolve('artifacts/avatar-builds/staging_'));
const old=JSON.parse(await readFile(`${OLD}/manifest.json`,'utf8')) as ExactManifest;
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const m:CollectionManifest={...structuredClone(old),version:6,pack:'atelier-r6',cosmetics:[],inherited:{},compiledHashes:{},frozenDefaultHash:old.masterHash};
for(const dir of ['layers','masks','rig'])await mkdir(`${ROOT}/${dir}`,{recursive:true});
const master=decodePng(await readFile(`${OLD}/${old.master}`)),baseHead=decodePng(await readFile(`${OLD}/layers/head_soft_oval_skin_02_v5.png`));
const body=decodePng(await readFile(`${OLD}/layers/body_skin_02_v5.png`));
body.clearRect(45,65,5,5);
const part=async(s:string)=>decodePng(await readFile(`${OLD}/${old.partitionMasks[s]}`));
const parts={top:await part('top'),head:await part('head'),hair:await part('hair'),brows:await part('brows'),eyes:await part('eyes')};
const hairColorMask='masks/hair_textured_tones_v6.png';await writePng(`${ROOT}/${hairColorMask}`,hairToneMask(parts.hair));
m.masks.hair_textured_tones=hairColorMask;
const faceClearance='masks/hair_face_clearance_v6.png',faceGuard=new Raster(128,128);faceGuard.rect(55,18,19,17,[255,255,255,255]);await writePng(`${ROOT}/${faceClearance}`,faceGuard);m.masks.hair_face_clearance=faceClearance;
await mkdir(`${ROOT}/palettes`,{recursive:true});await writeFile(`${ROOT}/palettes/hair.json`,JSON.stringify(HAIR_PALETTES,null,2));
async function source(path:string){m.sources[path.split('/').at(-1)!.replace('.png','')]=path;m.pictureHashes[path]=sha(await readFile(path));}
async function write(id:string,r:Raster,region:string,path:string,z:number):Promise<CollectionLayer>{await source(path);const file=`layers/${id.replace(/[.-]/g,'_').toLowerCase()}_v6.png`;await writePng(`${ROOT}/${file}`,r);return{file,z,region,source:path,sha256:sha(await readFile(`${ROOT}/${file}`))};}
async function skins(id:string,r:Raster,region:string,path:string,z:number){const variants:Record<string,string>={};let base:CollectionLayer|undefined;for(const s of old.skins){const l=await write(id+'_'+s.id,skinVariant(r,s.id),region,path,z);variants[s.id]=l.file;if(s.id==='skin_02')base=l;}return{...base!,skinVariants:variants};}
m.skins=[];for(const s of old.skins)m.skins.push({...s,layer:await write('body_'+s.id,skinVariant(body,s.id),'body','references/avatar-exact-v5/body-support.png',20)});
const reference='references/avatar-exact-v5/body-reference.png',hairShadows=new Raster(128,128),browPatch=new Raster(128,128),eyePatch=new Raster(128,128);
const expressions={friendly:await expressionParts(`${REF}/face-friendly.png`,true),focused:await expressionParts(`${REF}/face-focused.png`,false)};
for(let y=18;y<=22;y++)for(let x=55;x<=72;x++){const p=baseHead.pixel(x,y);if(!p[3]||p[0]>=225)continue;if(x===67&&y===18)browPatch.set(x,y,p);else if(x===67&&y===20)eyePatch.set(x,y,p);else if(!parts.brows.pixel(x,y)[3]&&!parts.eyes.pixel(x,y)[3])hairShadows.set(x,y,p);baseHead.set(x,y,master.pixel(60,24));}
for(const c of old.cosmetics){
 const family=c.id.endsWith('_friendly')?'friendly':c.id.endsWith('_focused')?'focused':null;
 if(family&&['eyes','brows','nose','mouth'].includes(c.slot)){
  const draft=expressions[family],path=`${REF}/face-${family}.png`,r=draft[c.slot as 'eyes'|'brows'|'nose'|'mouth'];
  if(c.slot==='eyes'){
   const variants:Record<string,string>={};let first:CollectionLayer|undefined;
   for(const color of EYE_COLORS){const eye=clone(r);if(color!=='eye.dark_brown'){
    const paletteSource=decodePng(await readFile(`${OLD}/${old.cosmetics.find(a=>a.id==='eyes.reference_neutral')!.layers[0].eyeVariants![color]}`));
    for(const [x,y]of draft.iris)if(eye.pixel(x,y)[3])eye.set(x,y,paletteSource.pixel(60,22));
   }const l=await write(c.id+'_'+color,eye,'eyes',path,50);variants[color]=l.file;if(color==='eye.dark_brown')first=l;}
   m.cosmetics.push({...c,layers:[{...first!,eyeVariants:variants}]});
  }else m.cosmetics.push({...c,layers:[c.slot==='brows'?await write(c.id,r,c.slot,path,52):await skins(c.id,r,c.slot,path,c.slot==='nose'?53:54)]});
  continue;
 }
 if(c.slot==='head'){
  let r=baseHead,path=reference;
  if(c.id!=='head.soft_oval'){
   path=`${REF}/${c.id.replace('.','-').replace('_','-')}.png`;
   const widths:Record<string,number>={'head.round':23,'head.soft_square':22,'head.full_round':24,'head.narrow':21,'head.angular':22};r=await blankHead(path,widths[c.id],master);
   // The approved neck attachment is copied verbatim; generated closed jaw outlines stop above it.
   for(let y=30;y<=33;y++)for(let x=59;x<=69;x++)if(parts.head.pixel(x,y)[3])r.set(x,y,parts.head.pixel(x,y));
  }
  m.cosmetics.push({...c,layers:[await skins(c.id,r,'head',path,21)]});continue;
 }
 if(c.id==='hair.textured'){
  let first:CollectionLayer|undefined;const variants:Record<string,string>={};
  for(const s of old.skins){const r=clone(parts.hair);r.blit(skinVariant(hairShadows,s.id));const l=await write('hair_textured_'+s.id,r,'hair_front',reference,60);variants[s.id]=l.file;if(s.id==='skin_02')first=l;}
  m.cosmetics.push({...c,layers:[{...first!,skinVariants:variants,recolor:{family:'hair',mask:hairColorMask}}]});continue;
 }
 if(c.id==='brows.reference_neutral'){const r=clone(parts.brows);r.blit(browPatch);m.cosmetics.push({...c,layers:[await write(c.id,r,'brows',reference,52)]});continue;}
 if(c.id==='eyes.reference_neutral'){
  const variants:Record<string,string>={};let first:CollectionLayer|undefined;
  for(const [color,file]of Object.entries(c.layers[0].eyeVariants!)){const r=decodePng(await readFile(`${OLD}/${file}`));r.blit(eyePatch);const l=await write(c.id+'_'+color,r,'eyes',reference,50);variants[color]=l.file;if(color==='eye.dark_brown')first=l;}
  m.cosmetics.push({...c,layers:[{...first!,eyeVariants:variants}]});continue;
 }
 m.cosmetics.push(structuredClone(c));
}
const hairJobs=JSON.parse(await readFile(`${HAIR_REF}/prompts.json`,'utf8')).jobs as HairSourceJob[];
if(hairJobs.length!==20||new Set(hairJobs.map(j=>j.id)).size!==20)throw Error('Expected 20 distinct new hairstyle definitions');
for(const job of [...hairJobs,...identityJobs.filter(j=>j.slot==='hair') as HairSourceJob[]]){
 const path=`${identityJobs.some(j=>j.id===job.id)?IDENTITY_REF:HAIR_REF}/${job.source}`,raw=await isolateHairSource(path),compiled=compileHairSource(raw,job),layers:CollectionLayer[]=[];
 if(compiled.back)layers.push(await write(job.id+'_back',compiled.back,'hair_back',path,10));
 layers.push({...await write(job.id+'_front',compiled.front,'hair_front',path,60),clearanceMask:faceClearance});
 m.cosmetics.push({id:job.id,name:job.name,slot:'hair',collection:job.group,color:'Brown',layers,tags:[job.group.toLowerCase()]});
}
for(const item of m.cosmetics.filter(c=>c.slot==='hair')){
 const whole=new Raster(128,128),layerRasters:Raster[]=[];
 for(let index=0;index<item.layers.length;index++){
  const l=item.layers[index],root=l.file.endsWith('_v5.png')?OLD:ROOT;let image=decodePng(await readFile(`${root}/${l.file}`));
  if(l.file.endsWith('_v5.png')&&l.region==='hair_back'&&['Medium','Long'].includes(item.collection)){
   const filled=fillBackHeadVolume(image);
   if(!Buffer.from(filled.data).equals(Buffer.from(image.data))){image=filled;item.layers[index]={...l,...await write(item.id+'_back_registered',image,l.region,l.source,l.z)};}
  }
  layerRasters.push(image);whole.blit(image);
 }
 const colors=[];for(let i=0;i<whole.data.length;i+=4)if(whole.data[i+3])colors.push([...whole.data.subarray(i,i+3)]);
 colors.sort((a,b)=>a.reduce((s,v)=>s+v,0)-b.reduce((s,v)=>s+v,0));const median=colors[Math.floor(colors.length*.6)];
 item.originalColor='#'+median.map(v=>v.toString(16).padStart(2,'0')).join('');
 if(item.id==='hair.textured')continue;
 for(let i=0;i<item.layers.length;i++){
  const file=`masks/${item.id.replace('.','_')}_${i}_tones_v6.png`;
  await writePng(`${ROOT}/${file}`,calibratedHairToneMask(layerRasters[i],whole));
  m.masks[`${item.id}_${i}_tones`]=file;item.layers[i].recolor={family:'hair',mask:file};
 }
}
for(const job of identityJobs.filter(j=>j.slot!=='hair')){
 const path=`${IDENTITY_REF}/${job.source}`,r=compileIdentity(await identitySource(path),job),slot=job.slot as CollectionCosmetic['slot'],layers:CollectionLayer[]=[];
 const regions:Record<string,string>={facialHair:'facial_hair',ageLines:'age_lines',hearingAidLeft:'hearing_aid_left',hearingAidRight:'hearing_aid_right'};
 const region=regions[slot]??slot,z=slot==='eyes'?50:slot==='brows'?52:slot==='nose'?53:slot==='mouth'?54:slot==='facialHair'?62:slot.startsWith('hearing')?58:49;
 if(slot==='eyes'){
  let base:CollectionLayer|undefined;const eyeVariants:Record<string,string>={};for(const color of EYE_COLORS){const l=await write(job.id+'_'+color,eyeVariant(r,color),region,path,z);eyeVariants[color]=l.file;if(color==='eye.dark_brown')base=l;}layers.push({...base!,eyeVariants});
 }else if(['nose','mouth','freckles','birthmark','scar','ageLines'].includes(slot)){
  let base:CollectionLayer|undefined;const skinVariants:Record<string,string>={};for(const skin of old.skins){const l=await write(job.id+'_'+skin.id,featureSkin(r,skin.id,slot),region,path,z);skinVariants[skin.id]=l.file;if(skin.id==='skin_02')base=l;}layers.push({...base!,skinVariants});
 }else{
  const l=await write(job.id,r,region,path,z);if(slot==='facialHair'||slot==='brows'){const file=`masks/${job.id.replace('.','_').toLowerCase()}_tones_v6.png`;await writePng(`${ROOT}/${file}`,calibratedHairToneMask(r,r));m.masks[job.id+'_tones']=file;l.recolor={family:'hair',mask:file};}layers.push(l);
 }
 m.cosmetics.push({id:job.id,name:job.name,slot,collection:slot==='facialHair'?'Facial hair':['eyes','brows','nose','mouth'].includes(slot)?'Face':'Personal',color:slot==='facialHair'||slot==='brows'?'Brown':slot.startsWith('hearing')?'Pearl gray':'Skin matched',layers});
}
const jobs=JSON.parse(await readFile(`${REF}/prompts-clothes.json`,'utf8')).jobs as {id:string;name:string;color:string;collection:string;kind:string;sleeve?:string;closed?:boolean}[];
for(const job of jobs){
 const path=polishSource(job.id,`${REF}/${job.id.replace('.','-')}.png`);await readFile(path);
 const s=await (polishJobs.some(j=>j.id===job.id)?isolateWearSource(path):garmentSource(path)),{front,back}=compileGarment(s,job.kind,body,parts.top,job.sleeve==='short',job.kind!=='jacket'||job.closed===true);
 const slot=job.kind as CollectionCosmetic['slot'],layers:CollectionLayer[]=[];
 if(back.data.some((v,i)=>i%4===3&&v))layers.push(await write(job.id+'_back',back,slot+'_back',path,15));
 layers.push(await write(job.id,front,slot,path,{top:40,jacket:42,bottom:32,shoes:34}[slot as 'top'|'jacket'|'bottom'|'shoes']));
 if(slot==='jacket')layers.at(-1)!.hide=['top:top_sleeves','top_back:top_sleeves'];
 m.cosmetics.push({id:job.id,name:job.name,color:job.color,collection:job.collection,slot,layers,tags:[job.collection.toLowerCase()]});
}
const wearRef='references/avatar-wardrobe-expansion';
const wearJobs=JSON.parse(await readFile(`${wearRef}/prompts.json`,'utf8')).jobs as WearSourceJob[];
if(wearJobs.length!==50||new Set(wearJobs.map(j=>j.id)).size!==50)throw Error('Expected 50 distinct wearable sources');
for(const job of wearJobs){
 const path=polishSource(job.id,`${wearRef}/${job.source}`),raw=await isolateWearSource(path),{front,back}=compileWearSource(raw,job,body,parts.top),layers:CollectionLayer[]=[];
 if(back.data.some((v,i)=>i%4===3&&v))layers.push(await write(job.id+'_back',back,job.kind+'_back',path,15));
 layers.push(await write(job.id,front,job.kind,path,{top:40,jacket:42,bottom:32,shoes:34}[job.kind]));
 if(job.kind==='jacket')layers.at(-1)!.hide=['top:top_sleeves','top_back:top_sleeves'];
 m.cosmetics.push({id:job.id,name:job.name,slot:job.kind,color:job.color,collection:job.collection,layers,tags:[job.collection.toLowerCase()]});
}
// Three Imagegen source modules: fixed shirt/jacket, independent recolorable tie.
const suitRef='references/avatar-suit';
for(const job of [{id:'top.dress_white',name:'White dress shirt',kind:'top',source:'dress_white.png',color:'White',closed:true},{id:'jacket.suit_charcoal',name:'Charcoal suit jacket',kind:'jacket',source:'suit_charcoal.png',color:'Charcoal',closed:false}] as const){
 const path=`${suitRef}/${job.source}`,raw=await isolateWearSource(path),{front,back}=compileWearSource(raw,{...job,collection:'Tailoring'},body,parts.top),layers:CollectionLayer[]=[];
 if(back.data.some((v,i)=>i%4===3&&v))layers.push(await write(job.id+'_back',back,job.kind+'_back',path,15));
 if(job.kind==='top'){
  const collar=new Raster(128,128);
  for(let y=37;y<=42;y++)for(let x=58;x<=70;x++)if(x<=62||x>=66){const p=front.pixel(x,y);if(p[3]){collar.set(x,y,p);front.set(x,y,[0,0,0,0]);}}
  layers.push(await write(job.id,front,'top',path,40));layers.push(await write(job.id+'_collar',collar,'top',path,42));
 }else{
  // Register inner sleeve coverage to the same body/reference mask, using neighboring source pixels.
  for(let y=46;y<70;y++)for(const [lo,hi]of [[43,55],[73,85]]){const occupied=[];for(let x=lo;x<=hi;x++)if(front.pixel(x,y)[3])occupied.push(x);if(!occupied.length)continue;for(let x=lo;x<=hi;x++)if(body.pixel(x,y)[3]&&parts.top.pixel(x,y)[3]&&!front.pixel(x,y)[3]){const nearest=occupied.reduce((a,b)=>Math.abs(b-x)<Math.abs(a-x)?b:a);front.set(x,y,front.pixel(nearest,y));}}
  const l=await write(job.id,registerSuitSleeves(front,body,parts.top),'jacket',path,42);l.hide=['top:top_sleeves','top_back:top_sleeves'];layers.push(l);}
 m.cosmetics.push({id:job.id,name:job.name,slot:job.kind,color:job.color,collection:'Tailoring',layers,fixedColors:true});
}
const tiePath=`${suitRef}/tie_classic.png`,tie=fit(await suitSource(tiePath),[62,38,5,30]);
m.cosmetics.push({id:'tie.classic',name:'Classic tie',slot:'tie',color:'Burgundy',collection:'Tailoring',compatibleTops:['top.dress_white'],layers:[await write('tie_classic',tie,'tie',tiePath,41)]});
await writeFile(`${ROOT}/palettes/wear.json`,JSON.stringify(WEAR_PALETTES,null,2));
for(const c of m.cosmetics.filter(c=>WEAR_SLOTS.includes(c.slot as typeof WEAR_SLOTS[number])&&!c.fixedColors)){
 const whole=new Raster(128,128),rasters:Raster[]=[];
 for(const l of c.layers){const r=decodePng(await readFile(`${l.file.endsWith('_v5.png')?OLD:ROOT}/${l.file}`));rasters.push(r);whole.blit(r);}
 const primary=rasters.map(r=>{if(c.slot!=='tie')return wearToneMask(r,whole,c.slot);const mask=calibratedHairToneMask(r,whole);for(let i=0;i<16384;i++)if(r.data[i*4+3]&&!mask.data[i*4])mask.data.set([1,1,1,255],i*4);return mask;});
 const accents=c.slot==='tie'?rasters.map(()=>new Raster(128,128)):wearAccentMasks(rasters,primary,c.slot as typeof WEAR_SLOTS[number]);
 for(let i=0;i<c.layers.length;i++){
  if(accents[i].data.some((v,k)=>k%4===3&&v)){const file=`masks/${c.id.replace('.','_')}_${i}_accent_v6.png`;await writePng(`${ROOT}/${file}`,accents[i]);m.masks[`${c.id}_${i}_accent`]=file;c.layers[i].accentMask=file;c.accentLabel=ACCENT_LABELS[c.slot as typeof WEAR_SLOTS[number]];}
  const mask=primary[i];if(!mask.data.some((v,i)=>i%4===3&&v))continue;
  const file=`masks/${c.id.replace('.','_')}_${i}_material_v6.png`;await writePng(`${ROOT}/${file}`,mask);m.masks[`${c.id}_${i}_material`]=file;c.layers[i].recolor={family:'wear',mask:file};
 }
 const pixels=[];for(let i=0;i<whole.data.length;i+=4)if(whole.data[i+3])pixels.push([...whole.data.subarray(i,i+3)]);pixels.sort((a,b)=>a.reduce((s,v)=>s+v,0)-b.reduce((s,v)=>s+v,0));const mid=pixels[Math.floor(pixels.length*.6)];c.originalColor='#'+mid.map(v=>v.toString(16).padStart(2,'0')).join('');
}
// Positional QA pass. Only confirmed sleeve gaps are corrected; palettes and source colors stay fixed.
const shortSleeves=new Set(['top.white_tee','top.polo',...jobs.filter(j=>j.sleeve==='short').map(j=>j.id),...wearJobs.filter(j=>j.sleeve==='short').map(j=>j.id)]);
const positionCorrections=[];
for(const item of m.cosmetics.filter(c=>c.slot==='top'||c.slot==='jacket')){
 item.sleeveLength=shortSleeves.has(item.id)?'short':'long';if(item.sleeveLength==='short')continue;
 const front=new Raster(128,128),layers=item.layers.filter(l=>l.z>=20);
 for(const l of layers)front.blit(decodePng(await readFile(`${l.file.endsWith('_v5.png')?OLD:ROOT}/${l.file}`)));
 const gaps=armCoverageGaps(front,body,parts.top);if(!gaps.length)continue;
 const map=garmentPositionMap(front,body,parts.top);
 for(const l of layers){const path=`${l.file.endsWith('_v5.png')?OLD:ROOT}/${l.file}`,r=decodePng(await readFile(path)),adjusted=applyPositionMap(r,map);
  if(Buffer.from(adjusted.data).equals(Buffer.from(r.data)))continue;
  if(l.file.endsWith('_v5.png'))l.file=l.file.replace('_v5.png','_position_v6.png');
  await writePng(`${ROOT}/${l.file}`,adjusted);l.sha256=sha(await readFile(`${ROOT}/${l.file}`));
  for(const maskFile of [l.recolor?.mask,l.accentMask].filter(Boolean) as string[]){const mask=decodePng(await readFile(`${ROOT}/${maskFile}`));await writePng(`${ROOT}/${maskFile}`,applyPositionMap(mask,map));}
 }
 positionCorrections.push({id:item.id,previousArmGaps:gaps.length});
}
const referenceBottom=await part('bottom');
for(const item of m.cosmetics.filter(c=>c.slot==='bottom'||c.slot==='shoes'))for(const l of item.layers){
 const root=l.file.endsWith('_v5.png')?OLD:ROOT,sourceRaster=decodePng(await readFile(`${root}/${l.file}`));
 const map=item.slot==='bottom'?bottomPositionMap(sourceRaster,body,referenceBottom):new Raster(128,128);
 if(item.slot==='shoes')for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(sourceRaster.pixel(x,y)[3])map.set(x,y,[x,y,1,255]);
 connectPositionFragments(map);const adjusted=applyPositionMap(sourceRaster,map);if(Buffer.from(adjusted.data).equals(Buffer.from(sourceRaster.data)))continue;
 if(l.file.endsWith('_v5.png'))l.file=l.file.replace('_v5.png','_position_v6.png');await writePng(`${ROOT}/${l.file}`,adjusted);l.sha256=sha(await readFile(`${ROOT}/${l.file}`));
 for(const file of [l.recolor?.mask,l.accentMask].filter(Boolean) as string[])await writePng(`${ROOT}/${file}`,applyPositionMap(decodePng(await readFile(`${ROOT}/${file}`)),map));
 positionCorrections.push({id:item.id,previousArmGaps:0});
}
await mkdir('artifacts/avatar-position-audit',{recursive:true});await writeFile('artifacts/avatar-position-audit/corrections.json',JSON.stringify(positionCorrections,null,2));
// Inherit only referenced files, keeping the prior collection immutable and avoiding orphaned layers.
for(const l of [...m.skins.map(s=>s.layer),...m.cosmetics.flatMap(c=>c.layers)])for(const f of new Set([l.file,...Object.values(l.skinVariants??{}),...Object.values(l.eyeVariants??{})])){
 if(f.endsWith('_v5.png')){await copyFile(`${OLD}/${f}`,`${ROOT}/${f}`);m.inherited[f]=`${OLD}/${f}`;}
 m.compiledHashes![f]=sha(await readFile(`${ROOT}/${f}`));
}
for(const f of new Set([old.master,...Object.values(old.masks),...Object.values(old.partitionMasks)]))await copyFile(`${OLD}/${f}`,`${ROOT}/${f}`);
await copyFile(`${OLD}/rig/coordinates.json`,`${ROOT}/rig/coordinates.json`);
m.regions={...old.regions,head:[49,3,30,31],hair_front:[38,0,54,70],hair_back:[38,0,54,70],eyes:[55,19,19,5],brows:[54,17,20,3],top:[43,33,43,42],jacket:[43,33,43,44],bottom:[49,72,32,44],top_back:[48,32,32,10],jacket_back:[48,32,32,10],shoes:[46,104,38,20],tie:[61,37,7,33],facial_hair:[54,25,21,14],freckles:[55,23,19,5],birthmark:[68,24,5,5],scar:[56,24,4,6],age_lines:[54,23,21,3],hearing_aid_left:[49,19,6,11],hearing_aid_right:[73,19,6,11]};
m.slotMasks={};for(const [region,b]of Object.entries(m.regions)){const r=new Raster(128,128);r.rect(...b,[255,255,255,255]);const file=`masks/slot_${region}_v6.png`;await writePng(`${ROOT}/${file}`,r);m.slotMasks[region]=file;}
const shoulderMask='masks/required_shoulders_v6.png';await writePng(`${ROOT}/${shoulderMask}`,shoulderCoverageMask(body,parts.top));
m.coverageMasks={shoulders:shoulderMask};
for(const [name,open]of [['waist_full',false],['waist_sides',true]] as const){const file=`masks/required_${name}_v6.png`;await writePng(`${ROOT}/${file}`,waistCoverageMask(body,parts.top,open));m.coverageMasks[name]=file;}
for(const c of m.cosmetics.filter(c=>c.slot==='top'||c.slot==='jacket'))for(const l of c.layers.filter(l=>l.z>20)){
 l.coverage='shoulders';l.waistCoverage=c.slot==='jacket'&&![...jobs,...wearJobs].find(j=>j.id===c.id)?.closed?'waist_sides':'waist_full';
}
await appendHairLibrary(ROOT,m);
m.normalization={...m.normalization,method:'Preserved approved default; Imagegen source geometry with shared shoulder registration',baseFaceFrozen:true,garmentRegistration:GARMENT_REGISTRATION};
await appendWardrobeTwo(ROOT,m);
applyCatalogNames(m);
await writeFile(`${ROOT}/manifest.json`,JSON.stringify(m,null,2));
try{await cp(`${OUTPUT}/previews`,`${ROOT}/previews`,{recursive:true});}catch(error){if((error as NodeJS.ErrnoException).code!=='ENOENT')throw error;}
await publishValidatedPack(ROOT,OUTPUT,resolve('artifacts/avatar-builds/archive'),validateCollectionPack);
console.log(`Validated and published ${m.cosmetics.length} cosmetics; approved default hash ${m.frozenDefaultHash}`);
