import {createServer} from 'node:http';
import {createReadStream} from 'node:fs';
import {readFile,stat} from 'node:fs/promises';
import {resolve,sep,extname} from 'node:path';
import {getStudioManifest,renderStudio} from '../../src/studio/render.js';
import {DEFAULT_STUDIO,PRESETS,StudioConfigSchema} from '../../src/studio/model.js';
import {SKIN_PALETTES} from '../../src/avatar/palettes.js';
import {atelierManifest,renderAtelier,atelierPresets} from '../../src/atelier/render.js';
import {DEFAULT_ATELIER,validateAtelier} from '../../src/atelier/model.js';
import {portraitManifest,renderPortrait} from '../../src/portrait/render.js';
import {DEFAULT_PORTRAIT,portraitPresets,validatePortrait} from '../../src/portrait/model.js';
import {exactManifest,renderExact} from '../../src/exact/render.js';
import {DEFAULT_EXACT,exactPresets,validateExact,EYE_COLOR_INFO} from '../../src/exact/model.js';
import {collectionManifest,renderCollection,renderCollectionLayer} from '../../src/collection/render.js';
import {WEAR_PALETTES} from '../../src/collection/wearPalettes.js';
import {HAIR_PALETTES,HAIR_COLOR_STYLE} from '../../src/collection/hairPalettes.js';
import type {CollectionSlot} from '../../src/collection/model.js';
import {DEFAULT_COLLECTION,collectionPresets,validateCollection} from '../../src/collection/model.js';
const root=resolve(process.cwd());
const mime:Record<string,string>={'.tflite':'application/octet-stream','.wasm':'application/wasm','.task':'application/octet-stream','.mjs':'text/javascript; charset=utf-8','.jpg':'image/jpeg','.png':'image/png','.json':'application/json; charset=utf-8','.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.txt':'text/plain; charset=utf-8'};
export function createStudioServer(options:{collectionRender?:typeof renderCollection}={}){const collectionRender=options.collectionRender??renderCollection,snapshots=new Map<string,Buffer>();return createServer(async(req,res)=>{
  const respond=(status:number,body:string|Buffer,type='application/json; charset=utf-8')=>{res.writeHead(status,{'content-type':type,'cache-control':'no-store','x-content-type-options':'nosniff'});res.end(body);};
  try{
    const url=new URL(req.url??'/','http://127.0.0.1');
    if(!['GET','HEAD','POST'].includes(req.method??'GET'))return respond(405,JSON.stringify({error:'Method not allowed'}));
    if(url.pathname==='/dev/selfie-refinement'){if(process.env.NODE_ENV==='production')return respond(404,'Not found','text/plain');return respond(200,await readFile(resolve(root,'artifacts/selfie/refinement/comparison.html'),'utf8'),'text/html; charset=utf-8');}
    if(url.pathname==='/dev/selfie-new-photo-tests'){if(process.env.NODE_ENV==='production')return respond(404,'Not found','text/plain');return respond(200,await readFile(resolve(root,'artifacts/selfie/new-photo-tests/comparison.html'),'utf8'),'text/html; charset=utf-8');}
    if(url.pathname==='/dev/selfie-comparison'){if(process.env.NODE_ENV==='production')return respond(404,'Not found','text/plain');return respond(200,await readFile(resolve(root,'artifacts/selfie/precision/comparison.html'),'utf8'),'text/html; charset=utf-8');}
    if(['/', '/avatar-studio','/dev/avatar-lab','/dev/selfie-lab'].includes(url.pathname)){
      if(url.pathname.startsWith('/dev/')&&process.env.NODE_ENV==='production')return respond(404,'Not found','text/plain');
      let html=await readFile(resolve(root,'src/studio/index.html'),'utf8');if(url.pathname==='/dev/selfie-lab')html=html.replace('<p>Your photo is analyzed', '<div id="selfie-fixtures"><button data-fixture="portrait">Test portrait</button><button data-fixture="no-face">Test no face</button><button data-fixture="multiple">Test multiple faces</button><button data-fixture="invalid">Test invalid file</button><button data-fixture="michelle">Test michelle</button><button data-fixture="kamala">Test kamala</button><button data-fixture="jill">Test jill</button><button data-fixture="joe">Test joe</button><button data-fixture="donald">Test donald</button><button data-fixture="watkins">Test watkins</button><button data-fixture="williams">Test williams</button><button data-fixture="hadfield">Test hadfield</button><button data-fixture="jemison">Test jemison</button><button data-fixture="ride">Test ride</button><button data-fixture="bluford">Test bluford</button></div><p>Your photo is analyzed');return respond(200,html,'text/html; charset=utf-8');
    }
    if(url.pathname.startsWith('/dev/selfie-fixture/')){if(process.env.NODE_ENV==='production'||req.method!=='GET')return respond(404,'Not found','text/plain');const name=url.pathname.slice('/dev/selfie-fixture/'.length);if(!['portrait','no-face','michelle','kamala','jill','joe','donald','watkins','williams','hadfield','jemison','ride','bluford'].includes(name))return respond(404,'Not found','text/plain');return respond(200,await readFile(resolve(root,'artifacts/selfie/'+(['portrait','no-face'].includes(name)?'':['watkins','williams','hadfield','jemison'].includes(name)?'new-photo-tests/':['ride','bluford'].includes(name)?'refinement/':'precision/')+name+'.jpg')),'image/jpeg');}
    const snapshotMatch=/^\/api\/collection\/snapshot\/([a-f0-9]{24})\.png$/.exec(url.pathname);
    if(snapshotMatch){
      if(req.method!=='GET'&&req.method!=='HEAD')return respond(405,JSON.stringify({error:'Method not allowed'}));
      const png=snapshots.get(snapshotMatch[1]);if(!png)return respond(404,JSON.stringify({error:'Preview expired. Render the avatar again.'}));
      res.writeHead(200,{'content-type':'image/png','cache-control':'private, max-age=31536000, immutable','content-disposition':'attachment; filename="diff-avatar-128.png"','x-content-type-options':'nosniff'});res.end(png);return;
    }
    if(url.pathname==='/api/collection/catalog')return respond(200,JSON.stringify({manifest:await collectionManifest(),defaults:DEFAULT_COLLECTION,presets:collectionPresets(),eyeColors:EYE_COLOR_INFO,wearColors:WEAR_PALETTES.map(({id,name,color})=>({id,name,color})),hairColors:HAIR_PALETTES.map(({id,name,color})=>({id,name,color})),hairColorStyle:HAIR_COLOR_STYLE,hairColorStyles:(await collectionManifest()).cosmetics.filter(c=>c.slot==='hair'&&c.layers.every(l=>l.recolor)).map(c=>c.id),legacySources:{...(await getStudioManifest()).sources,...(await atelierManifest()).sources,...(await portraitManifest()).sources}}));
    if(url.pathname==='/api/collection/layer'){
      if(req.method!=='GET'&&req.method!=='HEAD')return respond(405,JSON.stringify({error:'Method not allowed'}));
      const c=JSON.parse(url.searchParams.get('config')??JSON.stringify(DEFAULT_COLLECTION));
      return respond(200,await renderCollectionLayer(c,url.searchParams.get('slot') as CollectionSlot,Number(url.searchParams.get('index')??'0')),'image/png');
    }
    if(['/api/collection/render','/api/collection/validate'].includes(url.pathname)){
      if(url.searchParams.has('size')&&url.searchParams.get('size')!=='128')return respond(400,JSON.stringify({error:'Only 128 × 128 is supported.'}));
      let raw=url.searchParams.get('config')??JSON.stringify(DEFAULT_COLLECTION);
      if(req.method==='POST'){const chunks:Buffer[]=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>16384)return respond(413,JSON.stringify({error:'Configuration too large'}));chunks.push(Buffer.from(chunk));}raw=Buffer.concat(chunks).toString('utf8');}
      const c=validateCollection(JSON.parse(raw),await collectionManifest());
      if(url.pathname.endsWith('/validate'))return respond(200,JSON.stringify(c));
      const result=await collectionRender(c,(url.searchParams.get('hidden')??'').split(',').filter(Boolean));
      if(!snapshots.has(result.hash)&&snapshots.size>=512)snapshots.delete(snapshots.keys().next().value!);snapshots.set(result.hash,result.png);
      res.writeHead(200,{'content-type':'image/png','cache-control':'no-store','x-avatar-hash':result.hash,'x-avatar-warnings':encodeURIComponent(JSON.stringify(result.warnings)),'x-avatar-layers':String(result.layers.length),'content-disposition':url.searchParams.get('download')==='1'?'attachment; filename="diff-avatar-128.png"':'inline','x-content-type-options':'nosniff'});res.end(result.png);return;
    }
    if(url.pathname==='/api/exact/catalog')return respond(200,JSON.stringify({manifest:await exactManifest(),defaults:DEFAULT_EXACT,presets:exactPresets(),eyeColors:EYE_COLOR_INFO,legacySources:{...(await getStudioManifest()).sources,...(await atelierManifest()).sources,...(await portraitManifest()).sources}}));
    if(['/api/exact/render','/api/exact/validate'].includes(url.pathname)){
      if(url.searchParams.has('size')&&url.searchParams.get('size')!=='128')return respond(400,JSON.stringify({error:'Only 128 × 128 is supported.'}));
      let raw=url.searchParams.get('config')??JSON.stringify(DEFAULT_EXACT);
      if(req.method==='POST'){const chunks:Buffer[]=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>16384)return respond(413,JSON.stringify({error:'Configuration too large'}));chunks.push(Buffer.from(chunk));}raw=Buffer.concat(chunks).toString('utf8');}
      const c=validateExact(JSON.parse(raw),await exactManifest());
      if(url.pathname.endsWith('/validate'))return respond(200,JSON.stringify(c));
      const result=await renderExact(c,(url.searchParams.get('hidden')??'').split(',').filter(Boolean));
      res.writeHead(200,{'content-type':'image/png','cache-control':'no-store','x-avatar-hash':result.hash,'x-avatar-layers':String(result.layers.length),'content-disposition':url.searchParams.get('download')==='1'?'attachment; filename="diff-avatar-128.png"':'inline','x-content-type-options':'nosniff'});res.end(result.png);return;
    }
    if(url.pathname==='/api/portrait/catalog')return respond(200,JSON.stringify({manifest:await portraitManifest(),defaults:DEFAULT_PORTRAIT,presets:portraitPresets(),legacySources:{...(await getStudioManifest()).sources,...(await atelierManifest()).sources}}));
    if(['/api/portrait/render','/api/portrait/validate'].includes(url.pathname)){
      if(url.searchParams.has('size')&&url.searchParams.get('size')!=='128')return respond(400,JSON.stringify({error:'Only 128 × 128 is supported.'}));
      let raw=url.searchParams.get('config')??JSON.stringify(DEFAULT_PORTRAIT);
      if(req.method==='POST'){const chunks:Buffer[]=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>16384)return respond(413,JSON.stringify({error:'Configuration too large'}));chunks.push(Buffer.from(chunk));}raw=Buffer.concat(chunks).toString('utf8');}
      const c=validatePortrait(JSON.parse(raw),await portraitManifest());if(url.pathname.endsWith('/validate'))return respond(200,JSON.stringify(c));
      const result=await renderPortrait(c,(url.searchParams.get('hidden')??'').split(',').filter(Boolean));
      res.writeHead(200,{'content-type':'image/png','cache-control':'no-store','x-avatar-hash':result.hash,'x-avatar-layers':String(result.layers.length),'content-disposition':url.searchParams.get('download')==='1'?'attachment; filename="diff-avatar-128.png"':'inline','x-content-type-options':'nosniff'});res.end(result.png);return;
    }
    if(url.pathname==='/api/atelier/catalog')return respond(200,JSON.stringify({manifest:await atelierManifest(),defaults:DEFAULT_ATELIER,presets:atelierPresets(DEFAULT_ATELIER),legacySources:(await getStudioManifest()).sources}));
    if(['/api/atelier/render','/api/atelier/validate'].includes(url.pathname)){
      if(url.searchParams.has('size')&&url.searchParams.get('size')!=='128')return respond(400,JSON.stringify({error:'Only 128 × 128 is supported.'}));
      let raw=url.searchParams.get('config')??JSON.stringify(DEFAULT_ATELIER);
      if(req.method==='POST'){const chunks:Buffer[]=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>16384)return respond(413,JSON.stringify({error:'Configuration too large'}));chunks.push(Buffer.from(chunk));}raw=Buffer.concat(chunks).toString('utf8');}
      const c=validateAtelier(JSON.parse(raw),await atelierManifest());
      if(url.pathname.endsWith('/validate'))return respond(200,JSON.stringify(c));
      const result=await renderAtelier(c,(url.searchParams.get('hidden')??'').split(',').filter(Boolean));
      res.writeHead(200,{'content-type':'image/png','cache-control':'no-store','x-avatar-hash':result.hash,'x-avatar-layers':String(result.layers.length),'content-disposition':url.searchParams.get('download')==='1'?'attachment; filename="diff-avatar-128.png"':'inline','x-content-type-options':'nosniff'});res.end(result.png);return;
    }
    if(url.pathname==='/api/studio/catalog')return respond(200,JSON.stringify({manifest:await getStudioManifest(),defaults:DEFAULT_STUDIO,presets:PRESETS,skins:Object.entries(SKIN_PALETTES).map(([id,p])=>({id,color:`rgb(${p.base.slice(0,3).join(',')})`}))}));
    if(url.pathname==='/api/studio/render'){
      if(url.searchParams.has('size')&&url.searchParams.get('size')!=='128')return respond(400,JSON.stringify({error:'Only 128 × 128 is supported.'}));
      let payload:unknown;
      if(req.method==='POST'){
        const chunks:Buffer[]=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>16384)return respond(413,JSON.stringify({error:'Configuration too large'}));chunks.push(Buffer.from(chunk));}payload=JSON.parse(Buffer.concat(chunks).toString('utf8'));
      }else payload=JSON.parse(url.searchParams.get('config')??JSON.stringify(DEFAULT_STUDIO));
      const config=StudioConfigSchema.parse(payload);
      const hidden=(url.searchParams.get('hidden')??'').split(',').filter(Boolean);
      const result=await renderStudio(config,hidden);
      res.writeHead(200,{'content-type':'image/png','cache-control':'no-store','x-avatar-hash':result.hash,'x-avatar-layers':String(result.layerIds.length),'content-disposition':url.searchParams.get('download')==='1'?'attachment; filename="diff-avatar-128.png"':'inline','x-content-type-options':'nosniff'});res.end(result.png);return;
    }
    if(url.pathname==='/api/studio/validate'&&req.method==='POST'){
      let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>16384)return respond(413,JSON.stringify({error:'Configuration too large'}));}
      return respond(200,JSON.stringify(StudioConfigSchema.parse(JSON.parse(raw))));
    }
    const allowed=['/assets/selfie/v1/','/dist/src/selfie/','/assets/avatar/','/references/avatar-v1/','/references/avatar-studio/','/references/avatar-atelier/','/references/avatar-faces-v3/','/references/avatar-refinement-v4/','/references/avatar-exact-v5/','/references/avatar-revision-v6/','/references/avatar-hair-expansion/','/references/avatar-hair-library/','/references/avatar-wardrobe-expansion/','/references/avatar-suit/','/references/avatar-identity-expansion/','/references/avatar-polish/','/src/studio/','/dist/src/studio/','/dist/src/atelier/','/dist/src/portrait/','/dist/src/exact/','/dist/src/collection/'];
    const decoded=decodeURIComponent(url.pathname);if(!allowed.some(prefix=>decoded.startsWith(prefix)))return respond(404,'Not found','text/plain');
    const file=resolve(root,'.'+decoded);
    if(!file.startsWith(root+sep)||!['.png','.jpg','.json','.html','.css','.js','.mjs','.wasm','.task','.tflite','.txt'].includes(extname(file)))return respond(404,'Not found','text/plain');
    const info=await stat(file);if(!info.isFile())return respond(404,'Not found','text/plain');
    if(decoded.startsWith('/assets/selfie/v1/')&&req.method!=='GET'&&req.method!=='HEAD')return respond(405,'Method not allowed','text/plain');
    if(decoded==='/dist/src/selfie/worker.js')res.setHeader('Content-Security-Policy',"default-src 'none'; script-src 'self' 'wasm-unsafe-eval'; connect-src 'self';");
    res.writeHead(200,{'content-type':mime[extname(file)],'content-length':info.size,'cache-control':decoded.startsWith('/assets/selfie/v1/')?'public, max-age=31536000, immutable':'no-store','x-content-type-options':'nosniff'});createReadStream(file).on('error',()=>res.destroy()).pipe(res);
  }catch(error){const missing=(error as NodeJS.ErrnoException).code==='ENOENT';respond(missing?404:400,JSON.stringify({error:missing?'Resource not found.':error instanceof Error?error.message:'Invalid request'}));}
});}
if(process.argv[1]&&/previewServer\.(ts|js)$/.test(process.argv[1])){
  const port=Number(process.env.PORT??4312);
  createStudioServer().listen(port,'127.0.0.1',()=>console.log(`DIFF Avatar Studio: http://localhost:${port}/avatar-studio`));
}
