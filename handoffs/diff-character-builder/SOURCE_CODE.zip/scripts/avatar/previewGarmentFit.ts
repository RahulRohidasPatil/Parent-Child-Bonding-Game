import {readFile,mkdir,writeFile} from 'node:fs/promises';
import {Raster,decodePng,writePng,encodePng} from '../../src/avatar/raster.js';
import {collectionLayerFile} from '../../src/collection/assets.js';
import {CollectionManifest,CollectionConfig,CollectionLayer,DEFAULT_COLLECTION,collectionPresets} from '../../src/collection/model.js';
import {uncoveredPixels} from '../../src/collection/coverage.js';
const ROOT='artifacts/avatar-fit-fix',OLD=ROOT+'/before',NEW='assets/avatar/atelier-r6';
await mkdir(ROOT,{recursive:true});
const manifest=async(root:string)=>JSON.parse(await readFile(root+'/manifest.json','utf8')) as CollectionManifest;
const before=await manifest(OLD),after=await manifest(NEW),required=decodePng(await readFile(NEW+'/'+after.coverageMasks!.shoulders));
async function render(root:string,m:CollectionManifest,c:CollectionConfig){
 const layers:CollectionLayer[]=[m.skins.find(s=>s.id===c.skin)!.layer,...m.cosmetics.filter(cos=>Object.values(c.equipment).includes(cos.id)).flatMap(cos=>cos.layers)];layers.sort((a,b)=>a.z-b.z);
 const masks:Record<string,Raster[]>={};
 for(const l of layers)for(const rule of l.hide??[]){const[region,key]=rule.split(':');(masks[region]??=[]).push(decodePng(await readFile(root+'/'+m.masks[key])));}
 const out=new Raster(128,128);for(const l of layers)out.blit(decodePng(await readFile(root+'/'+collectionLayerFile(l,c))),masks[l.region]?(x,y)=>masks[l.region].some(p=>p.pixel(x,y)[3]===255):undefined);return out;
}
const results=[];
const garments=after.cosmetics.filter(c=>c.slot==='top'||c.slot==='jacket');
const sheet=new Raster(6*256,Math.ceil(garments.length/6)*192);sheet.rect(0,0,sheet.width,sheet.height,[238,240,232,255]);
for(let i=0;i<garments.length;i++){
 const c=garments[i],old=before.cosmetics.find(a=>a.id===c.id)!;
 const measure=async(root:string,item:typeof c)=>uncoveredPixels(required,await Promise.all(item.layers.filter(l=>l.z>20).map(async l=>decodePng(await readFile(root+'/'+l.file)))));
 results.push({id:c.id,before:await measure(OLD,old),after:await measure(NEW,c)});
 const config={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,[c.slot]:c.id}};
 const p=await render(NEW,after,config);
 for(let y=0;y<192;y++)for(let x=0;x<256;x++){const color=p.pixel(43+Math.floor(x/6),29+Math.floor(y/6));if(color[3])sheet.set(i%6*256+x,Math.floor(i/6)*192+y,color);}
}
await writePng(ROOT+'/all_shoulders_after.png',sheet);await writeFile(ROOT+'/shoulder-coverage.json',JSON.stringify(results,null,2));
for(const preset of collectionPresets().filter(p=>['oat','terminal'].includes(p.id))){
 const a=await render(OLD,before,preset.config),b=await render(NEW,after,preset.config),out=new Raster(768,768);out.rect(0,0,768,768,[238,240,232,255]);
 for(let y=0;y<768;y++)for(let x=0;x<384;x++)for(let side=0;side<2;side++){const p=(side?b:a).pixel(32+Math.floor(x/6),Math.floor(y/6));if(p[3])out.set(side*384+x,y,p);}
 await writePng(`${ROOT}/${preset.id}_before_after.png`,out);
}
const defaultSame=encodePng(await render(NEW,after,DEFAULT_COLLECTION)).equals(await readFile(NEW+'/'+after.master));
const summary={garments:results.length,previouslyFailing:results.filter(r=>r.before.length).length,previousExposedPixels:results.reduce((s,r)=>s+r.before.length,0),remainingExposedPixels:results.reduce((s,r)=>s+r.after.length,0),defaultUnchanged:defaultSame};
await writeFile(ROOT+'/summary.json',JSON.stringify(summary,null,2));console.log(summary);
