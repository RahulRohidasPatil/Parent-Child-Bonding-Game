import {Raster} from '../avatar/raster.js';
import {bounds,fit,type Box} from '../atelier/pixels.js';
import {rawSource,stripMatte} from '../refined/authoring.js';

export function clone(r:Raster){const p=new Raster(r.width,r.height);p.data.set(r.data);return p;}
export async function garmentSource(path:string){
 const {r,alpha}=await rawSource(path);if(alpha)return r;
 // Matte pixels are removed only by connected flood fill. Enclosed neck openings need their own seed.
 const center=Math.floor(r.width/2),top=Math.floor(r.height*.12),seeds:[number,number][]=[];
 for(let y=top;y<r.height*.33;y++){const p=r.pixel(center,y);if(p[3]&&Math.min(...p.slice(0,3))>218&&Math.max(...p.slice(0,3))-Math.min(...p.slice(0,3))<14)seeds.push([center,y]);}
 stripMatte(r,seeds);
 return r;
}
/** Recover a blank head from the generated mannequin; no ears or dark matte enter the layer. */
export async function blankHead(path:string,width:number,reference:Raster){
 const {r}=await rawSource(path),rows:{y:number;lo:number;hi:number}[]=[];
 for(let y=0;y<r.height*.29;y++){
  let lo=r.width,hi=-1;for(let x=Math.floor(r.width*.16);x<r.width*.85;x++){const p=r.pixel(x,y);if(p[0]>150&&p[0]>p[1]+18&&p[1]>p[2]+15){lo=Math.min(lo,x);hi=Math.max(hi,x);}}
  if(hi>=lo)rows.push({y,lo,hi});
 }
 const top=rows[0].y,max=Math.max(...rows.map(a=>a.hi-a.lo));
 const neck=rows.find(a=>a.y>r.height*.22&&a.hi-a.lo<max*.46)?.y??Math.floor(r.height*.25);
 const centerRows=rows.filter(a=>a.y>top+30&&a.y<neck*.54);
 const center=centerRows.reduce((s,a)=>s+(a.lo+a.hi)/2,0)/centerRows.length;
 const headWidth=Math.max(...centerRows.map(a=>a.hi-a.lo))+Math.round((neck-top)/28)*2;
 const frame:Box=[Math.round(center-headWidth/2),top-Math.round((neck-top)/28),headWidth,neck-top+Math.round((neck-top)/28)];
 const isolated=new Raster(r.width,r.height);
 const outline=Math.round((neck-top)/28);
 for(const row of rows.filter(a=>a.y<neck))for(let x=row.lo-outline;x<=row.hi+outline;x++){const p=r.pixel(x,row.y);if(p[0]>p[1]+6&&p[0]>p[2]+7)isolated.set(x,row.y,[p[0],p[1],p[2],255]);}
 const out=fit(isolated,[Math.round(64-width/2),4,width,28],frame);
 for(let y=19;y<=26;y++)for(let x=0;x<128;x++)if(x<55||x>73)out.set(x,y,[0,0,0,0]);
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){const p=out.pixel(x,y);if(p[3]&&p[0]>150)out.set(x,y,p[1]>208?reference.pixel(63,24):p[1]>165?reference.pixel(60,24):p[1]>115?reference.pixel(60,33):reference.pixel(62,33));}
 return out;
}
export const GARMENT_REGISTRATION=Object.freeze({left:44,top:33,width:40,height:41,neckLeft:59,neckRight:68,neckBackBottom:37,shoulderBottom:45});

/** Pixels that must be covered by every sleeved garment, excluding its central neck opening. */
export function shoulderCoverageMask(body:Raster,referenceTop:Raster){
 const mask=new Raster(128,128);
 for(let y=34;y<=GARMENT_REGISTRATION.shoulderBottom;y++)for(let x=43;x<=85;x++){
  if((x<59||x>69)&&body.pixel(x,y)[3]&&referenceTop.pixel(x,y)[3])mask.set(x,y,[255,255,255,255]);
 }
 return mask;
}

/** Register each shoulder panel to the shared rig without widening the neck opening or moving cuffs. */
export function fitShoulders(garment:Raster,required:Raster){
 const out=clone(garment);
 for(let y=34;y<=GARMENT_REGISTRATION.shoulderBottom;y++)for(const [start,end,left]of [[43,58,true],[70,85,false]] as const){
  const occupied:number[]=[],needed:number[]=[];let sourceY=y;
  for(let x=start;x<=end;x++){if(garment.pixel(x,y)[3])occupied.push(x);if(required.pixel(x,y)[3])needed.push(x);}
  if(!needed.length||needed.every(x=>garment.pixel(x,y)[3]))continue;
  const hasRow=occupied.length>0;
  // Tall collars can precede their shoulder panels; register the first nearby source row to this anchor.
  while(!occupied.length&&sourceY<y+3){sourceY++;for(let x=start;x<=end;x++)if(garment.pixel(x,sourceY)[3])occupied.push(x);}
  if(!occupied.length)throw new Error(`Garment has no nearby shoulder artwork at row ${y}`);
  const lo=hasRow?Math.min(occupied[0],needed[0]):needed[0],hi=hasRow?Math.max(occupied.at(-1)!,needed.at(-1)!):needed.at(-1)!;
  const sourceLo=occupied[0],sourceHi=occupied.at(-1)!;
  for(let x=lo;x<=hi;x++){
   // Preserve the outermost outline pixel, distributing only the interior source pixels.
   const distance=left?x-lo:hi-x,span=hi-lo;
   const step=distance===0?0:Math.min(sourceHi-sourceLo,1+Math.floor((distance-1)*Math.max(1,sourceHi-sourceLo)/Math.max(1,span)));
   const sx=left?sourceLo+step:sourceHi-step;
   out.set(x,y,garment.pixel(sx,sourceY));
  }
 }
 return out;
}

/** The shirt must cover the abdomen at the waistband; hands and open jacket centers are excluded. */
export function waistCoverageMask(body:Raster,referenceTop:Raster,open=false){
 const mask=new Raster(128,128);
 for(let y=70;y<=73;y++)for(let x=55;x<=73;x++){
  if(open&&x>=59&&x<=69)continue;
  if(body.pixel(x,y)[3]&&referenceTop.pixel(x,y)[3])mask.set(x,y,[255,255,255,255]);
 }
 return mask;
}

export function fitHem(garment:Raster,required:Raster){
 const out=clone(garment);
 for(let x=55;x<=73;x++){
  const needed:number[]=[],sourceRows:number[]=[];
  for(let y=68;y<=73;y++){if(required.pixel(x,y)[3])needed.push(y);if(garment.pixel(x,y)[3])sourceRows.push(y);}
  if(!needed.length||needed.every(y=>garment.pixel(x,y)[3]))continue;
  if(!sourceRows.length)throw new Error(`Missing hem artwork at column ${x}`);
  const first=sourceRows[0],last=sourceRows.at(-1)!,end=Math.max(last,needed.at(-1)!);
  for(let y=first;y<=end;y++){
   const sy=y===end?last:first+Math.floor((y-first)*Math.max(1,last-first)/Math.max(1,end-first));
   out.set(x,y,garment.pixel(x,sy));
  }
 }
 return out;
}

/** Register source art at shared shoulders; only the collar behind the neck is a rear layer. */
export function compileGarment(source:Raster,kind:string,body:Raster,referenceTop:Raster,short=false,closed=true){
 const g=GARMENT_REGISTRATION;
 const target:Box=kind==='bottom'?[52,73,25,41]:kind==='shoes'?[47,112,36,11]:[g.left,g.top,g.width,g.height];
 let out=fit(source,target);const back=new Raster(128,128);
 if(kind==='top'||kind==='jacket'){
  out=fitShoulders(out,shoulderCoverageMask(body,referenceTop));
  out=fitHem(out,waistCoverageMask(body,referenceTop,kind==='jacket'&&!closed));
  for(let y=0;y<128;y++)for(let x=0;x<128;x++){
   if(!out.pixel(x,y)[3])continue;
   if(x>=g.neckLeft&&x<=g.neckRight&&y<=g.neckBackBottom){back.set(x,y,out.pixel(x,y));out.set(x,y,[0,0,0,0]);}
   if(y>=70&&body.pixel(x,y)[3]&&body.pixel(x,y)[0]>100&&!referenceTop.pixel(x,y)[3])out.set(x,y,[0,0,0,0]);
  }
  // Short-sleeve sources are compiled as drawn; their open arms show the canonical body.
 }
 return {front:out,back};
}

export async function expressionParts(path:string,friendly:boolean){
 const {r}=await rawSource(path);
 const eyes=new Raster(128,128),brows=new Raster(128,128);
 const eyeFrames:Box[]=friendly?[[284,333,89,45],[446,333,85,45]]:[[290,339,82,28],[448,339,82,28]];
 for(let i=0;i<2;i++)eyes.blit(fit(r,[i?67:57,20,5,friendly?3:2],eyeFrames[i]));
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){const p=eyes.pixel(x,y);if(p[3]&&p[0]>140&&p[0]>p[1]+20)eyes.set(x,y,[0,0,0,0]);}
 const browFrames:Box[]=friendly?[[273,303,82,19],[455,303,82,19]]:[[278,306,92,16],[456,306,81,16]];
 for(let i=0;i<2;i++)brows.blit(fit(r,[i?67:56,18,6,1],browFrames[i]));
 for(let i=0;i<16384;i++)if(brows.data[i*4]>120)brows.data.fill(0,i*4,i*4+4);
 const nose=fit(r,[63,26,3,2],friendly?[383,435,44,24]:[384,423,43,28]);
 const mouth=fit(r,[62,29,5,3],friendly?[355,470,100,41]:[375,462,65,42]);
 if(friendly)for(let y=0;y<3;y++)for(let x=0;x<5;x++)mouth.set(62+x,29+y,r.pixel(365+x*20,[478,484,504][y]));
 // Skin between lip and chin shadow belongs to the head, keeping mouths independently removable.
 for(let y=29;y<=31;y++)for(let x=62;x<=66;x++){const p=mouth.pixel(x,y);if(p[0]>210)mouth.set(x,y,[0,0,0,0]);}
 return {eyes,brows,nose,mouth,iris:[[60,friendly?22:21],[69,friendly?22:21]]};
}
