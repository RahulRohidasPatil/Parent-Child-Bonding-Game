import {Raster} from '../avatar/raster.js';
import {WEAR_PALETTES,type WearColor} from './wearPalettes.js';
import type {Rgba} from '../avatar/types.js';
const tables=new Map<WearColor,Rgba[]>();
export function recolorWear(source:Raster,mask:Raster,color:WearColor){
 if(color==='wear.original')return source;
 let table=tables.get(color);if(!table){const p=WEAR_PALETTES.find(p=>p.id===color);if(!p)throw Error('Invalid wearable palette');const rgb=p.tones.map(hex=>[1,3,5].map(start=>parseInt(hex.slice(start,start+2),16)));table=Array.from({length:256},(_,i)=>{const pos=Math.max(0,i-1)*4/254,k=Math.min(3,Math.floor(pos)),t=pos-k;const c=rgb[k].map((v,ch)=>Math.round(v*(1-t)+rgb[k+1][ch]*t));return [c[0],c[1],c[2],255] as Rgba;});tables.set(color,table);}
 const out=new Raster(128,128);out.data.set(source.data);
 for(let i=0;i<16384;i++)if(mask.data[i*4+3]&&mask.data[i*4]&&source.data[i*4+3]){const p=table[mask.data[i*4]];out.data.set(p,i*4);}
 return out;
}
