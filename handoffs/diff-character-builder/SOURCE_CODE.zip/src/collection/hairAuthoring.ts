import {Raster} from '../avatar/raster.js';
import {fit,bounds} from '../atelier/pixels.js';
import {rawSource,stripMatte} from '../refined/authoring.js';

export interface HairSourceJob {id:string;name:string;group:string;source:string;guide:{width:number;y:number;height:number}}

/** Back hair has volume behind the head; the face cutout belongs to the front component only. */
export function fillBackHeadVolume(source:Raster){
 const out=new Raster(128,128);out.data.set(source.data);
 for(let y=18;y<=38;y++){
  const left:number[]=[],right:number[]=[];
  for(let x=38;x<64;x++)if(source.pixel(x,y)[3])left.push(x);
  for(let x=64;x<92;x++)if(source.pixel(x,y)[3])right.push(x);
  if(left.length<2||right.length<2)continue;
  const lo=left.at(-1)!,hi=right[0];
  for(let x=lo+1;x<hi;x++){
   const sx=x<64?left[Math.max(0,left.length-2-(x-lo-1)%Math.min(3,left.length))]:right[Math.min(right.length-1,1+(hi-x-1)%Math.min(3,right.length))];
   out.set(x,y,source.pixel(sx,y));
  }
 }
 return out;
}

export async function isolateHairSource(path:string){
 const {r,alpha}=await rawSource(path);
 if(!alpha){
  const seeds:[number,number][]=[];const cx=Math.floor(r.width/2);
  for(let y=Math.floor(r.height*.35);y<r.height*.95;y++){const p=r.pixel(cx,y);if(Math.min(...p.slice(0,3))>210&&Math.max(...p.slice(0,3))-Math.min(...p.slice(0,3))<14)seeds.push([cx,y]);}
  stripMatte(r,seeds);
  // Some generated RGB sources contain a painted gray transparency checker. Hair is brown,
  // so these neutral matte cells can be removed without erasing strand highlights.
  for(let i=0;i<r.data.length;i+=4){const rgb=r.data.subarray(i,i+3);if(Math.min(...rgb)>40&&Math.max(...rgb)-Math.min(...rgb)<18)r.data.fill(0,i,i+4);}
 }
 // Brown source art must not carry peach skin pixels from the mannequin into a recolorable layer.
 for(let i=0;i<r.data.length;i+=4)if(r.data[i]>195&&r.data[i+1]>145&&r.data[i+2]>90&&r.data[i]>r.data[i+2]+25)r.data.fill(0,i,i+4);
 return r;
}

export function compileHairSource(source:Raster,job:HairSourceJob){
 const {width,y,height}=job.guide;
 const [sx,sy,sw,sh]=bounds(source),centers:number[]=[];
 // Align the head opening rather than the complete bounding box: side ponytails are asymmetric.
 for(let eyeRow=16;eyeRow<=22;eyeRow++){
  const yy=Math.floor(sy+(eyeRow-y+.5)*sh/height);if(yy<sy||yy>=sy+sh)continue;
  let left=-1,best:[number,number]|undefined;
  for(let x=sx;x<sx+sw;x++){
   if(source.pixel(x,yy)[3]>=192){if(left>=0){const gap:[number,number]=[left,x];if(gap[1]-gap[0]>sw*.2&&gap[0]<source.width*.65&&gap[1]>source.width*.35&&(!best||gap[1]-gap[0]>best[1]-best[0]))best=gap;}left=x;}
  }
  if(best)centers.push((best[0]+best[1])/2);
 }
 centers.sort((a,b)=>a-b);const headCenter=centers.length?centers[Math.floor(centers.length/2)]:source.width/2;
 const left=Math.round(64-(headCenter-sx)*width/sw);
 const raw=fit(source,[left,y,width,height]);
 const front=new Raster(128,128);front.data.set(raw.data);
 // Shared face opening. Eye line, eyebrows, nose, mouth and chin are never redrawn by hair.
 front.clearRect(55,18,19,17);
 if(job.group!=='Short')front.clearRect(56,35,16,38);
 if(job.group==='Short')return {front};
 const back=job.group==='Tied'?new Raster(128,128):fillBackHeadVolume(raw);if(job.group==='Tied')back.data.set(raw.data);
 return {front,back};
}
