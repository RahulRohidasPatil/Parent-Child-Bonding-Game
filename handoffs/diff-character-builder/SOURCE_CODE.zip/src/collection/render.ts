import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {Raster,decodePng,encodePng} from '../avatar/raster.js';
import {validateCollection,COLLECTION_SLOTS,DEFAULT_COLLECTION,type CollectionManifest,type CollectionLayer,type CollectionSlot} from './model.js';
import {collectionLayerFile,canonicalVisualKey} from './assets.js';
import {recolorHair} from './recolor.js';
import {recolorWear} from './wearRecolor.js';
import {WEAR_PALETTES,WEAR_SLOTS,DEFAULT_WEAR_COLORS,type WearSlot} from './wearPalettes.js';
import {DEFAULT_HAIR_COLOR,HAIR_PALETTES} from './hairPalettes.js';
export interface RenderWarning {slot:CollectionSlot;requestedId:string;fallbackId:string|null}
type RendererOptions={loadFile?:(file:string)=>Promise<Buffer>;log?:(message:string)=>void};

/** One immutable pack generation. Failed cosmetic loads fall back by slot and are never cached. */
export function createCollectionRenderer(root=resolve('assets/avatar/atelier-r6'),options:RendererOptions={}){
 const loadFile=options.loadFile??((file:string)=>readFile(resolve(root,file))),log=options.log??console.warn;
 let metadata:Promise<CollectionManifest>|undefined,revision='';
 const images=new Map<string,Promise<Raster>>(),cache=new Map<string,Buffer>(),tinted=new Map<string,Raster>();
 const manifest=():Promise<CollectionManifest>=>{
  if(!metadata){metadata=loadFile('manifest.json').then(bytes=>{revision=createHash('sha256').update(bytes).update(JSON.stringify([HAIR_PALETTES,WEAR_PALETTES])).digest('hex');return JSON.parse(bytes.toString()) as CollectionManifest;});metadata.catch(()=>{metadata=undefined;});}
  return metadata;
 };
 async function image(file:string){
  let p=images.get(file);if(!p){p=loadFile(file).then(bytes=>{const r=decodePng(bytes);if(r.width!==128||r.height!==128||r.partialAlphaPixels())throw new Error('Invalid layer '+file);return r;});images.set(file,p);p.catch(()=>images.delete(file));}return p;
 }
 async function layerImage(l:CollectionLayer,c:ReturnType<typeof validateCollection>,owner?:CollectionSlot){
  const file=collectionLayerFile(l,c),source=await image(file);
  if(!l.recolor&&!l.accentMask)return source;
  const slot=owner as WearSlot;
  const color=l.recolor?.family==='hair'?c.hairColor:l.recolor?c.wearColors[slot]:'wear.original';
  const accent=l.accentMask?c.wearAccentColors[slot]:'wear.original';
  if((color==='hair.original'||color==='wear.original')&&accent==='wear.original')return source;
  const key=file+'|'+l.recolor?.mask+'|'+color+'|'+l.accentMask+'|'+accent,existing=tinted.get(key);if(existing)return existing;
  let result=l.recolor?(l.recolor.family==='hair'?recolorHair(source,await image(l.recolor.mask),c.hairColor):recolorWear(source,await image(l.recolor.mask),c.wearColors[slot])):source;
  if(l.accentMask&&accent!=='wear.original')result=recolorWear(result,await image(l.accentMask),accent);
  if(tinted.size>=128)tinted.delete(tinted.keys().next().value!);tinted.set(key,result);return result;
 }
 async function renderLayer(input:unknown,slot:CollectionSlot,index=0){
  const m=await manifest(),c=validateCollection(input,m);
  if(!COLLECTION_SLOTS.includes(slot)||!Number.isInteger(index)||index<0)throw Error('Invalid layer selection');
  const l=m.cosmetics.find(a=>a.id===c.equipment[slot])?.layers[index];if(!l)throw Error('Layer not equipped');
  return encodePng(await layerImage(l,c,slot));
 }
 async function render(input:unknown,hidden:string[]=[]){
  const m=await manifest(),c=validateCollection(input,m);
  if(hidden.some(s=>s!=='body'&&!COLLECTION_SLOTS.includes(s as CollectionSlot)))throw new Error('Invalid hidden slot');
  const warnings:RenderWarning[]=[],layers:CollectionLayer[]=[],loaded=new Map<string,Raster>();
  const coloredWear=new Set<WearSlot>(),accentWear=new Set<WearSlot>();
  async function prepare(group:CollectionLayer[],slot?:CollectionSlot){
   for(const l of group){const file=collectionLayerFile(l,c);loaded.set(file,await layerImage(l,c,slot));if(l.recolor?.family==='wear')coloredWear.add(slot as WearSlot);if(l.accentMask)accentWear.add(slot as WearSlot);for(const rule of l.hide??[]){const mask=m.masks[rule.split(':')[1]];if(!mask)throw Error('Missing declared mask');loaded.set(mask,await image(mask));}}
   layers.push(...group);
  }
  if(!hidden.includes('body'))await prepare([m.skins.find(s=>s.id===c.skin)!.layer]);
  for(const slot of COLLECTION_SLOTS){
   const id=c.equipment[slot];if(!id||hidden.includes(slot))continue;
   try{await prepare(m.cosmetics.find(a=>a.id===id)!.layers,slot);}
   catch(error){
    const fallback=DEFAULT_COLLECTION.equipment[slot];let fallbackId:string|null=null;
    if(fallback&&fallback!==id){try{await prepare(m.cosmetics.find(a=>a.id===fallback)!.layers,slot);fallbackId=fallback;}catch{/* Leave only this slot empty if its default is unavailable too. */}}
    warnings.push({slot,requestedId:id,fallbackId});log(`Avatar ${slot} ${id} unavailable: ${String(error)}`);
   }
  }
  const wearColors={...DEFAULT_WEAR_COLORS};for(const slot of WEAR_SLOTS)if(coloredWear.has(slot))wearColors[slot]=c.wearColors[slot];
  const wearAccentColors={...DEFAULT_WEAR_COLORS};for(const slot of WEAR_SLOTS)if(accentWear.has(slot))wearAccentColors[slot]=c.wearAccentColors[slot];
  const visualConfig={...c,wearColors,wearAccentColors,hairColor:layers.some(l=>l.recolor?.family==='hair')?c.hairColor:DEFAULT_HAIR_COLOR};
  const key=revision+canonicalVisualKey(visualConfig)+JSON.stringify([...new Set(hidden)].sort()),hash=createHash('sha256').update(key).digest('hex').slice(0,24);
  layers.sort((a,b)=>a.z-b.z);const files=layers.map(l=>collectionLayerFile(l,c));
  const cached=warnings.length?undefined:cache.get(hash);if(cached)return{png:cached,hash,layers:files,warnings};
  const masks:Record<string,Raster[]>={};
  for(const l of layers)for(const target of l.hide??[]){const [region,name]=target.split(':');(masks[region]??=[]).push(loaded.get(m.masks[name])!);}
  const out=new Raster(128,128);
  for(const l of layers){const mask=masks[l.region];out.blit(loaded.get(collectionLayerFile(l,c))!,mask?(x,y)=>mask.some(r=>r.pixel(x,y)[3]===255):undefined);}
  const png=encodePng(out);
  if(!warnings.length){if(cache.size>=512)cache.delete(cache.keys().next().value!);cache.set(hash,png);}
  return{png,hash:warnings.length?createHash('sha256').update(key+JSON.stringify(warnings)).digest('hex').slice(0,24):hash,layers:files,warnings};
 }
 return{manifest,render,renderLayer};
}
const renderer=createCollectionRenderer();
export const collectionManifest=renderer.manifest;
export const renderCollection=renderer.render;
export const renderCollectionLayer=renderer.renderLayer;
