import {Raster} from '../avatar/raster.js';
import type {WearSlot} from './wearPalettes.js';
const light=(r:Raster,x:number,y:number)=>{const p=r.pixel(x,y);return Math.round((p[0]*2126+p[1]*7152+p[2]*722)/10000);};
/** An optional detail override. Auto leaves the previous main-material rendering untouched. */
export function wearAccentMasks(parts:Raster[],primary:Raster[],slot:WearSlot){
 const whole=new Raster(128,128),main=new Raster(128,128);for(const p of parts)whole.blit(p);for(const p of primary)main.blit(p);
 const selected=new Raster(128,128),levels:number[]=[];
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){
  if(!whole.pixel(x,y)[3])continue;const l=light(whole,x,y),edge=[[x-1,y],[x+1,y],[x,y-1],[x,y+1]].some(([xx,yy])=>!whole.pixel(xx,yy)[3]);
  if(l<30||edge&&l<85)continue;
  let detail=!main.pixel(x,y)[3]&&l>=48;
  // Shared material zones select existing artwork, never add pixels or change the silhouette.
  if(slot==='top'||slot==='jacket'){
   const collar=(x>=59&&x<=68&&y===38)||((x>=57&&x<=58||x>=69&&x<=70)&&y>=36&&y<=38);
   const cuff=(x<=54||x>=74)&&y>=46&&y<=71&&!whole.pixel(x,y+2)[3];
   detail ||= (collar||cuff)&&!!main.pixel(x,y)[3];
  }
  if(slot==='bottom')detail ||= y>=73&&y<=75&&!!main.pixel(x,y)[3];
  if(slot==='shoes')detail ||= y>=119;
  if(slot==='glasses'||slot==='earrings')detail ||= l>=110&&!!main.pixel(x,y)[3];
  if(detail){selected.set(x,y,[255,255,255,255]);levels.push(l);}
 }
 if(!levels.length&&(slot==='top'||slot==='jacket'))for(let y=70;y<=72;y++)for(let x=56;x<=72;x++){
  const l=light(whole,x,y);if(l>8&&[[x,y],[x-1,y],[x+1,y],[x,y-1],[x,y+1]].every(([xx,yy])=>whole.pixel(xx,yy)[3])){selected.set(x,y,[255,255,255,255]);levels.push(l);}
 }
 if(!levels.length)return parts.map(()=>new Raster(128,128));levels.sort((a,b)=>a-b);const low=levels[Math.floor(levels.length*.05)],high=levels[Math.floor(levels.length*.95)];
 return parts.map(part=>{const mask=new Raster(128,128);for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(part.pixel(x,y)[3]&&selected.pixel(x,y)[3]){const l=light(part,x,y);const tone=high-low<8?160:Math.max(1,Math.min(255,1+Math.round((l-low)*254/(high-low))));mask.set(x,y,[tone,tone,tone,255]);}return mask;});
}
export const ACCENT_LABELS:Record<WearSlot,string>={top:'Collar, cuffs & trim',jacket:'Collar, cuffs & trim',bottom:'Waistband & details',shoes:'Soles & accents',hat:'Trim',glasses:'Frame details',earrings:'Highlights',tie:'Details'};
