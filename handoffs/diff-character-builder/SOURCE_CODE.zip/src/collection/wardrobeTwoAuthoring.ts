import {readFile,writeFile,stat,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {Raster,decodePng,writePng} from '../avatar/raster.js';
import {isolateWearSource,compileWearSource,type WearSourceJob} from './wearAuthoring.js';
import {garmentPositionMap,bottomPositionMap,connectPositionFragments,applyPositionMap,armCoverageGaps} from './garmentPosition.js';
import {wearToneMask} from './recolor.js';
import {wearAccentMasks,ACCENT_LABELS} from './accentAuthoring.js';
import type {CollectionManifest,CollectionCosmetic,CollectionLayer} from './model.js';
const SOURCE='references/avatar-wardrobe-two';
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
/** Additive offline compiler: source artwork fits the existing rig, never runtime offsets. */
export async function appendWardrobeTwo(root:string,m:CollectionManifest,allowPartial=false){
 const jobs=JSON.parse(await readFile(SOURCE+'/prompts.json','utf8')).jobs as WearSourceJob[];
 if(jobs.length!==20||new Set(jobs.map(j=>j.id)).size!==20)throw Error('Expected 20 distinct clothing sources');
 const body=decodePng(await readFile(root+'/'+m.skins.find(s=>s.id==='skin_02')!.layer.file));
 const reference=decodePng(await readFile(root+'/'+m.partitionMasks.top));
 const legReference=decodePng(await readFile(root+'/'+m.cosmetics.find(c=>c.id==='bottom.denim')!.layers[0].file));
 const included:string[]=[],missing:string[]=[];
 for(const job of jobs){
  const path=SOURCE+'/'+job.source;try{await stat(path);}catch(error){if((error as NodeJS.ErrnoException).code!=='ENOENT')throw error;missing.push(job.id);continue;}
  const previous=m.cosmetics.find(c=>c.id===job.id);
  if(previous){if(previous.layers.some(l=>!l.source.startsWith(SOURCE+'/')))throw Error('Cosmetic ID collision: '+job.id);for(const layer of previous.layers){await rm(root+'/'+layer.file,{force:true});delete m.compiledHashes![layer.file];for(const file of [layer.recolor?.mask,layer.accentMask].filter(Boolean) as string[]){await rm(root+'/'+file,{force:true});for(const [key,value]of Object.entries(m.masks))if(value===file)delete m.masks[key];}}m.cosmetics=m.cosmetics.filter(c=>c.id!==job.id);}
  const raw=await isolateWearSource(path,job.kind==='top'||job.kind==='jacket'),parts=compileWearSource(raw,job,body,reference);
  let front=parts.front;
  if(job.kind==='bottom'){const map=bottomPositionMap(front,body,legReference);connectPositionFragments(map);front=applyPositionMap(front,map);}
  else if(job.sleeve!=='short'&&armCoverageGaps(front,body,reference).length)front=applyPositionMap(front,garmentPositionMap(front,body,reference));
  const rasters=[...(parts.back.data.some((v,i)=>i%4===3&&v)?[{r:parts.back,region:job.kind+'_back',z:15,suffix:'back'}]:[]),{r:front,region:job.kind,z:{top:40,jacket:42,bottom:32,shoes:34}[job.kind],suffix:'front'}];
  const whole=new Raster(128,128);for(const {r}of rasters)whole.blit(r);
  const primary=rasters.map(({r})=>wearToneMask(r,whole,job.kind)),accents=wearAccentMasks(rasters.map(p=>p.r),primary,job.kind);
  const layers:CollectionLayer[]=[];
  for(let i=0;i<rasters.length;i++){
   const {r,region,z,suffix}=rasters[i],stem='wardrobe_two_'+job.id.replace('.','_')+'_'+suffix,file='layers/'+stem+'_v6.png';
   await writePng(root+'/'+file,r);const hash=sha(await readFile(root+'/'+file));m.compiledHashes![file]=hash;
   const layer:CollectionLayer={file,sha256:hash,source:path,region,z};
   if(z>20&&(job.kind==='top'||job.kind==='jacket')){layer.coverage='shoulders';layer.waistCoverage=job.kind==='jacket'&&!job.closed?'waist_sides':'waist_full';}
   if(z>20&&job.kind==='jacket')layer.hide=['top:top_sleeves','top_back:top_sleeves'];
   for(const [mask,type]of [[primary[i],'material'],[accents[i],'accent']] as const)if(mask.data.some((v,j)=>j%4===3&&v)){
    const maskFile='masks/'+stem+'_'+type+'_v6.png';await writePng(root+'/'+maskFile,mask);m.masks[stem+'_'+type]=maskFile;
    if(type==='material')layer.recolor={family:'wear',mask:maskFile};else layer.accentMask=maskFile;
   }
   layers.push(layer);
  }
  const pixels:number[][]=[];for(let i=0;i<whole.data.length;i+=4)if(whole.data[i+3])pixels.push([...whole.data.subarray(i,i+3)]);pixels.sort((a,b)=>a.reduce((s,v)=>s+v,0)-b.reduce((s,v)=>s+v,0));if(!pixels.length)throw Error('Empty garment '+job.id);
  const originalColor='#'+pixels[Math.floor(pixels.length*.6)].map(v=>v.toString(16).padStart(2,'0')).join('');
  const item:CollectionCosmetic={id:job.id,name:job.name,slot:job.kind,color:job.color,collection:job.collection,originalColor,layers,tags:[job.collection.toLowerCase(),'new'],...(job.kind==='top'||job.kind==='jacket'?{sleeveLength:job.sleeve==='short'?'short':'long'}:{})};
  if(layers.some(l=>l.accentMask))item.accentLabel=ACCENT_LABELS[job.kind];
  m.sources['wardrobe_two_'+job.id]=path;m.pictureHashes[path]=sha(await readFile(path));m.cosmetics.push(item);included.push(job.id);
 }
 if(missing.length&&!allowPartial)throw Error('Missing clothing sources: '+missing.join(', '));
 return {included,missing};
}
