import type {CollectionLayer,CollectionConfig} from './model.js';
export function collectionLayerFile(l:CollectionLayer,c:CollectionConfig){return l.headSkinVariants?.[c.equipment.head]?.[c.skin]??l.eyeVariants?.[c.eyeColor]??l.skinVariants?.[c.skin]??l.file;}
export function canonicalVisualKey(config:object){return JSON.stringify(config,(_key,value)=>value&&typeof value==='object'&&!Array.isArray(value)?Object.fromEntries(Object.entries(value).sort(([a],[b])=>a.localeCompare(b))):value);}
