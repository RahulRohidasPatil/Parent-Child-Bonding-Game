export const PERSONAL_SLOTS=['freckles','birthmark','scar','ageLines','hearingAidLeft','hearingAidRight'] as const;
