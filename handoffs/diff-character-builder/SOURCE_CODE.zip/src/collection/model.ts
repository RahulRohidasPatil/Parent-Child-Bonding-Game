import {z} from 'zod';
import type {HairMetrics} from '../selfie/hair.js';
import type {HairDetails} from './hairCatalog.js';
import {ExactConfigSchema,DEFAULT_EXACT,type ExactManifest,type ExactCosmetic,type ExactLayer,EXACT_SLOTS,type ExactSlot} from '../exact/model.js';
import {HAIR_COLOR_IDS,DEFAULT_HAIR_COLOR} from './hairPalettes.js';
import {WEAR_COLOR_IDS,DEFAULT_WEAR_COLORS} from './wearPalettes.js';
const WearColorsSchema=z.object({top:z.enum(WEAR_COLOR_IDS),jacket:z.enum(WEAR_COLOR_IDS),bottom:z.enum(WEAR_COLOR_IDS),shoes:z.enum(WEAR_COLOR_IDS),hat:z.enum(WEAR_COLOR_IDS),glasses:z.enum(WEAR_COLOR_IDS),earrings:z.enum(WEAR_COLOR_IDS),tie:z.enum(WEAR_COLOR_IDS).default('wear.original')}).strict();
export {EYE_COLORS,EYE_COLOR_INFO} from '../exact/model.js';
export type {EyeColor} from '../exact/model.js';
import {PERSONAL_SLOTS} from './identitySlots.js';
export {PERSONAL_SLOTS} from './identitySlots.js';
export const COLLECTION_SLOTS=[...EXACT_SLOTS,'tie','facialHair',...PERSONAL_SLOTS] as const;
export type CollectionSlot=typeof COLLECTION_SLOTS[number];
export const CollectionConfigSchema=ExactConfigSchema.extend({equipment:ExactConfigSchema.shape.equipment.extend({tie:z.string().nullable().default(null),facialHair:z.string().nullable().default(null),freckles:z.string().nullable().default(null),birthmark:z.string().nullable().default(null),scar:z.string().nullable().default(null),ageLines:z.string().nullable().default(null),hearingAidLeft:z.string().nullable().default(null),hearingAidRight:z.string().nullable().default(null)}).strict(),version:z.literal(6),pack:z.literal('atelier-r6'),hairColor:z.enum(HAIR_COLOR_IDS).default(DEFAULT_HAIR_COLOR),wearColors:WearColorsSchema.default(DEFAULT_WEAR_COLORS),wearAccentColors:WearColorsSchema.default(DEFAULT_WEAR_COLORS)}).strict();
export type CollectionConfig=z.infer<typeof CollectionConfigSchema>;
export interface CollectionLayer extends ExactLayer {coverage?:string;waistCoverage?:string;clearanceMask?:string;sourceParts?:string[];accentMask?:string;recolor?:{family:'hair'|'wear';mask:string}}
export interface CollectionCosmetic extends Omit<ExactCosmetic,'layers'|'slot'>{slot:CollectionSlot;hairMatch?:HairMetrics;hairDetails?:HairDetails;fixedColors?:boolean;sleeveLength?:'short'|'long';compatibleTops?:string[];layers:CollectionLayer[];tags?:string[];originalColor?:string;accentLabel?:string}
export interface CollectionManifest extends Omit<ExactManifest,'version'|'pack'|'cosmetics'|'skins'>{version:6;pack:'atelier-r6';cosmetics:CollectionCosmetic[];skins:{id:string;color:string;layer:CollectionLayer}[];coverageMasks?:Record<string,string>;frozenDefaultHash:string}
export const DEFAULT_COLLECTION:CollectionConfig={...DEFAULT_EXACT,equipment:{...DEFAULT_EXACT.equipment,tie:null,facialHair:null,freckles:null,birthmark:null,scar:null,ageLines:null,hearingAidLeft:null,hearingAidRight:null},version:6,pack:'atelier-r6',hairColor:DEFAULT_HAIR_COLOR,wearColors:{...DEFAULT_WEAR_COLORS},wearAccentColors:{...DEFAULT_WEAR_COLORS}};
export function validateCollection(input:unknown,m:CollectionManifest){const c=CollectionConfigSchema.parse(input);for(const [slot,id]of Object.entries(c.equipment))if(id){const item=m.cosmetics.find(a=>a.id===id);if(!item||item.slot!==slot)throw new Error(`Invalid ${slot}: ${id}`);}const tie=m.cosmetics.find(a=>a.id===c.equipment.tie);if(tie?.compatibleTops&&!tie.compatibleTops.includes(c.equipment.top??''))throw Error('Tie requires a compatible shirt');return c;}
export function collectionPresets(){const look=(id:string,name:string,detail:string,equipment:Partial<CollectionConfig['equipment']>,colors:Partial<CollectionConfig['wearColors']>={})=>({id,name,detail,config:{...DEFAULT_COLLECTION,wearColors:{...DEFAULT_COLLECTION.wearColors,...colors},equipment:{...DEFAULT_COLLECTION.equipment,...equipment}}});return[
 look('reference','Crewneck and jeans','The original character.',{}),
 look('oat','Soft layers','Fleece and washed denim.',{top:'top.oat_quarter',bottom:'bottom.washed_jeans',shoes:'shoes.cream_runner'}),
 look('terminal','Graphic T-shirt outfit','Made for building.',{top:'top.terminal_tee',bottom:'bottom.olive_cargo',shoes:'shoes.white'}),
 look('track','Matching tracksuit','A matching set.',{jacket:'jacket.diff_track',bottom:'bottom.diff_track',shoes:'shoes.cream_runner'}),
 look('knit','Weekend knit','Cream, slate and brown.',{top:'top.cable_knit',bottom:'bottom.slate_pleats',shoes:'shoes.brown_boots'}),
 look('street','After hours','Burgundy and black.',{top:'top.burgundy_hoodie',bottom:'bottom.black',jacket:'jacket.studio_bomber'}),
 look('chore','Workshop','Canvas and indigo.',{top:'top.sky_tee',jacket:'jacket.chore',shoes:'shoes.brown_boots'}),
 look('forest','Forest green','The familiar zip hoodie.',{top:'top.forest_hoodie'}),
 look('suited','Suited up','Charcoal, white and burgundy.',{top:'top.dress_white',jacket:'jacket.suit_charcoal',tie:'tie.classic',bottom:'bottom.slate_pleats',shoes:'shoes.derby_lace'},{shoes:'wear.black'})];}
