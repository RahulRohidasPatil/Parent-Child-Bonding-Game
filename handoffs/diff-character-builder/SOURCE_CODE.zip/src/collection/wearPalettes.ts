export const WEAR_SLOTS=['top','jacket','bottom','shoes','hat','glasses','earrings','tie'] as const;
export type WearSlot=typeof WEAR_SLOTS[number];
export const WEAR_COLOR_IDS=['wear.original','wear.black','wear.charcoal','wear.white','wear.cream','wear.tan','wear.brown','wear.navy','wear.blue','wear.sky','wear.forest','wear.olive','wear.burgundy','wear.red','wear.lilac','wear.diff_green','wear.silver','wear.gold'] as const;
export type WearColor=typeof WEAR_COLOR_IDS[number];
const definitions:[WearColor,string,string,string,string,string,string][]=[
 ['wear.original','Original','#182333','#344861','#577496','#8197AC','#BACAD5'],
 ['wear.black','Black','#101117','#191B23','#292C36','#424653','#636A76'],
 ['wear.charcoal','Charcoal','#151922','#2C323D','#48515E','#687482','#909BA8'],
 ['wear.white','White','#626777','#9CA6B2','#D7DDE0','#ECF0ED','#FFFFFF'],
 ['wear.cream','Cream','#645B52','#958B76','#CEC2A6','#EAE0C7','#FFF3DD'],
 ['wear.tan','Tan','#40312B','#795741','#B1865D','#D0AA7F','#ECD1A9'],
 ['wear.brown','Brown','#201A1C','#49322C','#775442','#A87C59','#CEA982'],
 ['wear.navy','Navy','#0B1020','#151F38','#283B61','#405B84','#7189A5'],
 ['wear.blue','Blue','#101B35','#1E396C','#345EAA','#5A86CB','#94B5E4'],
 ['wear.sky','Sky','#263C58','#4D7092','#7FA9C7','#AECBDD','#D6E7EC'],
 ['wear.forest','Forest','#101E1C','#203D32','#38634C','#61866A','#98B092'],
 ['wear.olive','Olive','#22271C','#454D30','#747D4D','#9BA274','#C6C9A3'],
 ['wear.burgundy','Burgundy','#251620','#4F2639','#813C50','#AF6275','#D9979D'],
 ['wear.red','Red','#381923','#772A3A','#B8424F','#DA6B6C','#F2A299'],
 ['wear.lilac','Lilac','#3C314F','#75618E','#A38AB9','#C8B2D7','#E7D8EB'],
 ['wear.diff_green','DIFF green','#123526','#1B7544','#39C969','#39FF7A','#A2FFB8'],
 ['wear.silver','Silver','#303844','#667381','#A9B4BE','#D5DDE0','#F1F4F3'],
 ['wear.gold','Gold','#45311F','#89703D','#C1A35E','#E0C885','#FBE7B0']
];
export const WEAR_PALETTES=definitions.map(([id,name,...tones])=>({id,name,color:tones[2],tones}));
export const DEFAULT_WEAR_COLORS=Object.fromEntries(WEAR_SLOTS.map(s=>[s,'wear.original'])) as Record<WearSlot,WearColor>;
