import {fitSparseFeature} from './sparseFeature.js';
import {Raster} from '../avatar/raster.js';import {fit,bounds} from '../atelier/pixels.js';import {isolateWearSource} from './wearAuthoring.js';import {SKIN_PALETTES} from '../avatar/palettes.js';import type {EyeColor} from './model.js';import {EYE_COLOR_INFO} from './model.js';
export interface IdentityJob {id:string;name:string;slot:string;source:string;sourceFrame?:[number,number,number,number];width?:number;height?:number;group?:string;guide?:{width:number;y:number;height:number}}
export async function identitySource(path:string){return isolateWearSource(path);}
function pair(source:Raster,left:[number,number,number,number],right:[number,number,number,number],sparse=false){const a=new Raster(source.width,source.height),b=new Raster(source.width,source.height);const [x,y,w,h]=bounds(source),mid=x+Math.floor(w/2);for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)(xx<mid?a:b).set(xx,yy,source.pixel(xx,yy));const resize=sparse?fitSparseFeature:fit;const out=resize(a,left);out.blit(resize(b,right));return out;}
export function compileIdentity(source:Raster,j:IdentityJob){const w=j.width!,h=j.height!;
 if(j.sourceFrame){const isolated=new Raster(source.width,source.height),[sx,sy,sw,sh]=j.sourceFrame;for(let y=sy;y<sy+sh;y++)for(let x=sx;x<sx+sw;x++){const p=source.pixel(x,y);if(p[3]&&p[0]<238&&p[1]>60)isolated.set(x,y,p);}source=isolated;}

 if(j.slot==='eyes')return pair(source,[57,20,w,h],[67,20,w,h]);
 if(j.slot==='brows')return pair(source,[56,19-h,w,h],[67,19-h,w,h],true);
 if(j.slot==='nose')return fit(source,[64-Math.floor(w/2),28-h,w,h]);
 if(j.slot==='mouth')return fit(source,[64-Math.floor(w/2),29,w,h]);
 if(j.slot==='facialHair'){const mustache=j.id.endsWith('.mustache'),out=(j.id==='facialHair.stubble'?fitSparseFeature:fit)(source,[64-Math.floor(w/2),mustache?28:25,w,h]);out.clearRect(61,29,7,3);if(!mustache)out.clearRect(61,25,7,3);return out;}
 if(j.slot==='freckles'){const out=pair(source,[57,24,5,h],[68,24,5,h]);return out;}
 if(j.slot==='birthmark')return fit(source,[69,25,w,h]);
 if(j.slot==='scar')return fit(source,[57,25,w,h]);
 if(j.slot==='ageLines')return pair(source,[55,23,4,h],[70,23,4,h]);
 if(j.slot==='hearingAidLeft')return fit(source,[51,21,w,h]);
 if(j.slot==='hearingAidRight')return fit(source,[75,21,w,h]);
 throw Error('Unknown identity source kind '+j.slot);
}
export function featureSkin(source:Raster,skin:string,slot:string){const p=SKIN_PALETTES[skin],out=new Raster(128,128);for(let i=0;i<16384;i++){const k=i*4;if(!source.data[k+3])continue;const l=(source.data[k]+source.data[k+1]+source.data[k+2])/3;const color=slot==='scar'?(l>150?p.highlight:p.shadow):slot==='nose'&&l>195?p.highlight:l>145?p.shadow:p.outlineShadow;out.data.set(color,k);}return out;}
export function eyeVariant(source:Raster,color:EyeColor){const out=new Raster(128,128);out.data.set(source.data);if(color==='eye.dark_brown')return out;const hex=EYE_COLOR_INFO.find(c=>c.id===color)!.color,rgba:[number,number,number,number]=[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16),255];for(const center of [59,69]){let best:[number,number]|undefined,score=-Infinity;for(let y=20;y<=22;y++)for(let x=center-1;x<=center+1;x++){const p=source.pixel(x,y);if(!p[3]||Math.max(...p.slice(0,3))>185)continue;const s=(y-20)*3-Math.abs(x-center)*2+(p[0]-p[2])/50;if(s>score){score=s;best=[x,y];}}if(best)out.set(...best,rgba);}return out;}
