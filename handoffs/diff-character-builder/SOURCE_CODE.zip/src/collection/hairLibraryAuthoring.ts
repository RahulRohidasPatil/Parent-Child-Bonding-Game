import {readFile,writeFile,stat,rm} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {Raster,encodePng,writePng} from '../avatar/raster.js';
import {isolateHairSource,compileHairSource,type HairSourceJob} from './hairAuthoring.js';
import {libraryHairTraits} from '../selfie/hairLibraryTraits.js';
import {hairDetails,type HairDetails} from './hairCatalog.js';
import {calibratedHairToneMask} from './recolor.js';
import type {CollectionManifest,CollectionLayer} from './model.js';
export async function appendHairLibrary(staging:string,m:CollectionManifest,allowPartial=false){
 const SOURCE='references/avatar-hair-library';
 const jobs=JSON.parse(await readFile(SOURCE+'/prompts.json','utf8')).jobs as (HairSourceJob&{texture:string;fringe:string})[];
 if(jobs.length!==65||new Set(jobs.map(j=>j.id)).size!==65)throw Error('Expected 65 distinct hairstyle jobs');
const faceClearance=m.cosmetics.find(c=>c.id==='hair.buzz')!.layers.find(l=>l.region==='hair_front')!.clearanceMask!;
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');
const included:string[]=[],missing:string[]=[];
for(const job of jobs){
 const source=SOURCE+'/'+job.source;try{await stat(source);}catch{missing.push(job.id);continue;}
 const old=m.cosmetics.find(c=>c.id===job.id);
 if(old){if(!old.layers.every(l=>l.source.startsWith(SOURCE+'/')))throw Error('Cosmetic ID collision '+job.id);for(const layer of old.layers){await rm(staging+'/'+layer.file,{force:true});delete m.compiledHashes![layer.file];if(layer.recolor){await rm(staging+'/'+layer.recolor.mask,{force:true});for(const [key,value] of Object.entries(m.masks))if(value===layer.recolor.mask)delete m.masks[key];}}m.cosmetics=m.cosmetics.filter(c=>c.id!==job.id);}

 const isolated=await isolateHairSource(source),parts=compileHairSource(isolated,job),whole=new Raster(128,128);
 const componentList=[...(parts.back?[{image:parts.back,region:'hair_back',z:10}]:[]),{image:parts.front,region:'hair_front',z:60}];
 componentList.forEach(c=>whole.blit(c.image));
 const colors:number[][]=[];for(let i=0;i<whole.data.length;i+=4)if(whole.data[i+3])colors.push(Array.from(whole.data.subarray(i,i+3)));
 colors.sort((a,b)=>a.reduce((s,v)=>s+v,0)-b.reduce((s,v)=>s+v,0));if(!colors.length)throw Error('Empty compiled hairstyle '+job.id);
 const base=colors[Math.floor(colors.length*.6)],layers:CollectionLayer[]=[];
 for(const part of componentList){
  const file='layers/library_'+job.id.replace('.','_')+'_'+part.region+'_v6.png',bytes=encodePng(part.image),mask='masks/library_'+job.id.replace('.','_')+'_'+part.region+'_tones_v6.png';
  await writeFile(staging+'/'+file,bytes);await writePng(staging+'/'+mask,calibratedHairToneMask(part.image,whole));
  m.compiledHashes![file]=sha(bytes);m.masks['library_'+job.id+'_'+part.region]=mask;
  layers.push({file,region:part.region,z:part.z,source,sha256:sha(bytes),recolor:{family:'hair',mask},...(part.region==='hair_front'?{clearanceMask:faceClearance}:{})});
 }
 m.cosmetics.push({id:job.id,name:job.name,slot:'hair',collection:job.group,color:'Brown',originalColor:'#'+base.map(v=>v.toString(16).padStart(2,'0')).join(''),layers,hairDetails:{length:job.group as HairDetails['length'],texture:job.texture as HairDetails['texture'],fringe:job.fringe as HairDetails['fringe']},tags:[job.group.toLowerCase(),job.texture,job.fringe]});
 m.cosmetics.at(-1)!.hairMatch=libraryHairTraits(job.id,m.cosmetics.at(-1)!.hairDetails!);
 m.sources['Hair library · '+job.name]=source;m.pictureHashes[source]=sha(await readFile(source));included.push(job.id);
}
if(missing.length&&!allowPartial)throw Error('Missing Imagegen sources: '+missing.join(', '));

for(const item of m.cosmetics.filter(c=>c.slot==='hair'))item.hairDetails=hairDetails(item);
return {included,missing,jobs};
}
