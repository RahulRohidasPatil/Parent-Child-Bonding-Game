import type {Raster} from '../avatar/raster.js';

/** A resource-valid garment can still fit badly. Check required opaque coverage in front of the body. */
export function uncoveredPixels(required:Raster,fronts:Raster[]){
 const missing:[number,number][]=[];
 for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(required.pixel(x,y)[3]&&!fronts.some(p=>p.pixel(x,y)[3]===255))missing.push([x,y]);
 return missing;
}
