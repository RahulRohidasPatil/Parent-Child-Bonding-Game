import {Raster} from '../avatar/raster.js';
import {DEFAULT_HAIR_COLOR,HAIR_PALETTES,type HairColor} from './hairPalettes.js';
import type {Rgba} from '../avatar/types.js';

/** Mask alpha selects actual hair only. Zero intensity protects the original dark outline. */
export function hairToneMask(hair:Raster){
 const mask=new Raster(128,128);
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){
  const p=hair.pixel(x,y);if(!p[3])continue;
  const luminance=Math.round((p[0]*2126+p[1]*7152+p[2]*722)/10000);
  const shade=luminance<=24?0:Math.max(1,Math.min(255,Math.round((luminance-25)*254/75)+1));
  mask.set(x,y,[shade,shade,shade,255]);
 }
 return mask;
}

/** Shared calibration for all components of a style, including very dark curls and braids. */
export function calibratedHairToneMask(part:Raster,whole:Raster){
 const levels:number[]=[];
 const light=(p:Rgba)=>Math.round((p[0]*2126+p[1]*7152+p[2]*722)/10000);
 for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(whole.pixel(x,y)[3])levels.push(light(whole.pixel(x,y)));
 if(!levels.length)throw Error('Empty hairstyle');levels.sort((a,b)=>a-b);
 const low=levels[Math.floor(levels.length*.1)],high=levels[Math.floor(levels.length*.97)],edgeLimit=levels[Math.floor(levels.length*.2)]+2;
 const mask=new Raster(128,128);
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){
  const p=part.pixel(x,y);if(!p[3])continue;const l=light(p);
  const edge=[[x-1,y],[x+1,y],[x,y-1],[x,y+1]].some(([xx,yy])=>!whole.pixel(xx,yy)[3]);
  const tone=edge&&l<=edgeLimit?0:high-low<8?128:Math.max(1,Math.min(255,1+Math.round((l-low)*254/(high-low))));
  mask.set(x,y,[tone,tone,tone,255]);
 }
 return mask;
}
const rgb=(hex:string):Rgba=>[parseInt(hex.slice(1,3),16),parseInt(hex.slice(3,5),16),parseInt(hex.slice(5,7),16),255];
const tables=new Map<HairColor,Rgba[]>();
function paletteTable(id:HairColor){
 let table=tables.get(id);if(table)return table;
 const palette=HAIR_PALETTES.find(p=>p.id===id);if(!palette)throw Error('Unknown hair palette');
 const tones=palette.tones.map(rgb);table=Array.from({length:256},(_,i)=>{
  const position=Math.max(0,i-1)*4/254,index=Math.min(3,Math.floor(position)),weight=position-index;
  const channel=(ch:number)=>Math.round(tones[index][ch]*(1-weight)+tones[index+1][ch]*weight);
  return [channel(0),channel(1),channel(2),255] as Rgba;
 });tables.set(id,table);return table;
}
export function recolorHair(source:Raster,mask:Raster,id:HairColor){
 if(id===DEFAULT_HAIR_COLOR)return source;
 const out=new Raster(source.width,source.height);out.data.set(source.data);const table=paletteTable(id);
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){
  const role=mask.pixel(x,y);if(role[3]&&role[0]&&source.pixel(x,y)[3])out.set(x,y,table[role[0]]);
 }
 return out;
}

/** Dominant material tint, preserving contrasting trim, logos, hardware and outsole pixels. */
export function wearToneMask(part:Raster,whole:Raster,slot:string){
 const info=(p:Rgba)=>{const max=Math.max(p[0],p[1],p[2]),min=Math.min(p[0],p[1],p[2]),d=max-min;let hue=0;if(d){hue=max===p[0]?((p[1]-p[2])/d+6)%6:max===p[1]?(p[2]-p[0])/d+2:(p[0]-p[1])/d+4;}return{l:Math.round((p[0]*2126+p[1]*7152+p[2]*722)/10000),sat:max?d/max:0,hue:hue*60};};
 const samples:{l:number;sat:number;hue:number}[]=[];
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){const p=whole.pixel(x,y);if(p[3]&&!(slot==='shoes'&&y>=120)){const a=info(p);samples.push(a);}}
 if(!samples.length)for(let i=0;i<whole.data.length;i+=4)if(whole.data[i+3])samples.push(info([whole.data[i],whole.data[i+1],whole.data[i+2],whole.data[i+3]]));
 const bins=Array.from({length:12},()=>0);for(const s of samples)if(s.sat>.2&&s.l>8)bins[Math.floor(s.hue/30)%12]++;
 const dominant=bins.indexOf(Math.max(...bins)),chromatic=bins[dominant]>samples.length*.22;
 const selected=(a:{sat:number;hue:number})=>!chromatic?a.sat<.32:Math.min(Math.abs(a.hue-(dominant*30+15)),360-Math.abs(a.hue-(dominant*30+15)))<48&&a.sat>.13;
 const levels=samples.filter(selected).map(a=>a.l).sort((a,b)=>a-b);if(!levels.length)throw Error('No recolorable material '+slot);
 const low=levels[Math.floor(levels.length*.07)],high=levels[Math.floor(levels.length*.95)],mask=new Raster(128,128);
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){
  const p=part.pixel(x,y);if(!p[3]||slot==='shoes'&&y>=120)continue;const a=info(p);if(!selected(a))continue;
  const edge=[[x-1,y],[x+1,y],[x,y-1],[x,y+1]].some(([xx,yy])=>!whole.pixel(xx,yy)[3]);
  // Very dark frames/jewelry must still recolor; larger items preserve their outer outline.
  if(edge&&a.l<Math.max(22,low)&&!['glasses','earrings'].includes(slot))continue;
  const tone=high-low<8?128:Math.max(1,Math.min(255,1+Math.round((a.l-low)*254/(high-low))));mask.set(x,y,[tone,tone,tone,255]);
 }
 return mask;
}
