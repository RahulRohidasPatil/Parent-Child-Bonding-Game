export const HAIR_TEXTURES={straight:'Straight',wavy:'Wavy',curly:'Curly',coily:'Coily',braided:'Braided',locs:'Locs'} as const;
export const HAIR_FRINGES={open:'Open forehead',middle:'Middle part',side:'Side part',blunt:'Blunt fringe',textured:'Textured fringe'} as const;
export interface HairDetails {length:'Short'|'Medium'|'Long'|'Tied';texture:keyof typeof HAIR_TEXTURES;fringe:keyof typeof HAIR_FRINGES}
interface HairItem {id:string;collection:string;hairDetails?:HairDetails}
/** Legacy assets keep their IDs; every future hairstyle can supply these catalog fields directly. */
export function hairDetails(item:HairItem):HairDetails {
 if(item.hairDetails)return item.hairDetails;
 const id=item.id.replace('hair.','');
 const textures:Record<string,HairDetails['texture']>={textured:'wavy',fluffy:'wavy',curls:'curly',long:'wavy',braids:'braided',short_waves:'wavy',afro:'coily',coils:'coily',tapered_curls:'curly',shag:'wavy',wolf_cut:'wavy',mullet:'wavy',locs:'locs',twists:'coily',receding_waves:'wavy',flat_top:'coily',short_twists:'coily',cornrows:'braided',afro_puffs:'coily'};
 const fringes:Record<string,HairDetails['fringe']>={textured:'side',fluffy:'middle',crop:'blunt',curls:'textured',long:'middle',bob:'middle',braids:'middle',french_crop:'blunt',side_part:'side',quiff:'side',curtains:'middle',shag:'textured',wolf_cut:'textured',mullet:'textured',straight_shoulder:'middle',locs:'middle',twists:'middle',side_bob:'side'};
 return {length:(['Short','Medium','Long','Tied'].includes(item.collection)?item.collection:'Short') as HairDetails['length'],texture:textures[id]??'straight',fringe:fringes[id]??'open'};
}
