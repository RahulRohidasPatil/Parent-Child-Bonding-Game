import {Raster} from '../avatar/raster.js';import {bounds,type Box} from '../atelier/pixels.js';
/** Preserve sparse source hair clusters that a single center sample would otherwise miss. */
export function fitSparseFeature(source:Raster,target:Box){const [sx,sy,sw,sh]=bounds(source),[tx,ty,tw,th]=target,out=new Raster(128,128);
 for(let y=0;y<th;y++)for(let x=0;x<tw;x++){const x0=Math.floor(sx+x*sw/tw),x1=Math.ceil(sx+(x+1)*sw/tw),y0=Math.floor(sy+y*sh/th),y1=Math.ceil(sy+(y+1)*sh/th),cx=(x0+x1)/2,cy=(y0+y1)/2;let count=0,best=Infinity,color:ReturnType<Raster['pixel']>|undefined;
  for(let yy=y0;yy<y1;yy++)for(let xx=x0;xx<x1;xx++){const p=source.pixel(xx,yy);if(p[3]<192)continue;count++;const d=(xx-cx)**2+(yy-cy)**2;if(d<best){best=d;color=p;}}
  if(color&&count/((x1-x0)*(y1-y0))>=.12)out.set(tx+x,ty+y,[color[0],color[1],color[2],255]);
 }return out;}
