import {Raster} from '../avatar/raster.js';
import {registerSuitSleeves} from './suitSleeves.js';
/** A source-coordinate map lets geometry and existing color masks move together, without recoloring. */
export function garmentPositionMap(source:Raster,body:Raster,referenceTop:Raster){
 let map=new Raster(128,128);for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(source.pixel(x,y)[3])map.set(x,y,[x,y,1,255]);
 const fill=(out:Raster)=>{for(let y=46;y<=70;y++)for(const[lo,hi]of [[43,54],[74,85]])for(let x=lo;x<=hi;x++){
  if(!body.pixel(x,y)[3]||!referenceTop.pixel(x,y)[3]||out.pixel(x,y)[3])continue;
  let best:ReturnType<Raster['pixel']>|undefined,distance=Infinity;
  for(let yy=Math.max(46,y-6);yy<=Math.min(71,y+2);yy++)for(let xx=lo;xx<=hi;xx++){const p=out.pixel(xx,yy);if(!p[3])continue;const d=Math.abs(xx-x)+Math.abs(yy-y)*3;if(d<distance){distance=d;best=p;}}
  if(!best)throw Error(`Missing sleeve source near ${x},${y}`);out.set(x,y,best);
 }};
 fill(map);map=registerSuitSleeves(map,body,referenceTop);fill(map);map.clearRect(43,72,8,2);map.clearRect(78,72,8,2);return map;
}
export function applyPositionMap(source:Raster,map:Raster){const out=new Raster(128,128);for(let y=0;y<128;y++)for(let x=0;x<128;x++){const p=map.pixel(x,y);if(p[3])out.set(x,y,source.pixel(p[0],p[1]));}return out;}
export function armCoverageGaps(source:Raster,body:Raster,referenceTop:Raster){const gaps:[number,number][]=[];for(let y=46;y<=70;y++)for(const[lo,hi]of [[43,54],[74,85]])for(let x=lo;x<=hi;x++)if(body.pixel(x,y)[3]&&referenceTop.pixel(x,y)[3]&&!source.pixel(x,y)[3])gaps.push([x,y]);return gaps;}
/** Complete the existing trouser coverage at fixed hip/leg anchors. */
export function bottomPositionMap(source:Raster,body:Raster,reference:Raster){
 const map=new Raster(128,128);for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(source.pixel(x,y)[3])map.set(x,y,[x,y,1,255]);
 for(let y=77;y<=113;y++)for(const[lo,hi]of [[49,63],[64,80]])for(let x=lo;x<=hi;x++)if(body.pixel(x,y)[3]&&reference.pixel(x,y)[3]&&!map.pixel(x,y)[3]){
  let best=-1,d=Infinity;for(let xx=lo;xx<=hi;xx++)if(source.pixel(xx,y)[3]&&Math.abs(xx-x)<d){best=xx;d=Math.abs(xx-x);}if(best<0)throw Error('No trouser source row');map.set(x,y,[best,y,1,255]);
 }return map;
}
/** Join tiny detached outsole/cord fragments to their nearest same-item component. */
export function connectPositionFragments(map:Raster){
 const seen=new Set<number>(),components:number[][]=[];
 for(let i=0;i<16384;i++){if(seen.has(i)||!map.data[i*4+3])continue;const q=[i];seen.add(i);for(let n=0;n<q.length;n++){const x=q[n]%128,y=Math.floor(q[n]/128);for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const xx=x+dx,yy=y+dy,j=yy*128+xx;if(xx<0||xx>=128||yy<0||yy>=128||seen.has(j)||!map.data[j*4+3])continue;seen.add(j);q.push(j);}}components.push(q);}
 const major=components.filter(c=>c.length>=4).flat();for(const fragment of components.filter(c=>c.length<4)){
  let pair:[number,number]|undefined,best=Infinity;for(const a of fragment)for(const b of major){const d=Math.abs(a%128-b%128)+Math.abs(Math.floor(a/128)-Math.floor(b/128));if(d<best){best=d;pair=[a,b];}}
  if(!pair||best>4)continue;let x=pair[0]%128,y=Math.floor(pair[0]/128);const xx=pair[1]%128,yy=Math.floor(pair[1]/128),pixel=map.pixel(x,y);
  while(Math.max(Math.abs(x-xx),Math.abs(y-yy))>1){if(y!==yy)y+=Math.sign(yy-y);else x+=Math.sign(xx-x);if(!map.pixel(x,y)[3])map.set(x,y,pixel);}
 }return map;
}
