import {Raster} from '../avatar/raster.js';
/** Offline sleeve registration: keep shoulders and torso, bring cuffs toward the fixed wrists. */
export function registerSuitSleeves(source:Raster,body:Raster,referenceTop:Raster){
 const out=new Raster(128,128);out.data.set(source.data);
 for(let y=46;y<=71;y++)for(const [lo,hi,direction]of [[43,54,1],[74,85,-1]] as const){
  const pixels:number[]=[],required:number[]=[];
  for(let x=lo;x<=hi;x++){if(source.pixel(x,y)[3])pixels.push(x);if(body.pixel(x,y)[3]&&referenceTop.pixel(x,y)[3])required.push(x);}
  if(!pixels.length)continue;
  const desired=Math.min(5,Math.floor((y-46)*5/22));
  const clearance=required.length?(direction===1?required[0]-pixels[0]:pixels.at(-1)!-required.at(-1)!):desired;
  const shift=Math.max(0,Math.min(desired,clearance));
  out.clearRect(lo,y,hi-lo+1,1);
  for(const x of pixels){const target=x+direction*shift;
   // Preserve torso/lapel artwork where the inward sleeve overlaps it.
   if(target>=55&&target<=73&&source.pixel(target,y)[3])continue;
   const skin=body.pixel(target,y);if(y>=70&&skin[3]&&skin[0]>100&&!referenceTop.pixel(target,y)[3])continue;
   out.set(target,y,source.pixel(x,y));
  }
 }
 return out;
}
