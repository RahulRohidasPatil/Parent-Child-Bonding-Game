import {Raster} from '../avatar/raster.js';
import {fit,bounds} from '../atelier/pixels.js';
import {rawSource} from '../refined/authoring.js';
import {garmentSource,compileGarment} from './authoring.js';
export interface WearSourceJob {id:string;name:string;collection:string;color:string;source:string;kind:'top'|'jacket'|'bottom'|'shoes';width?:number;height?:number;sleeve?:string;closed?:boolean}
/** Generated slate material is chromatic; remove only neutral background connected to canvas edges. */
export async function isolateWearSource(path:string,neckOpenings=false){
 const {r,alpha}=await rawSource(path);if(alpha&&r.data.some((v,i)=>i%4===3&&v<192))return r;
 const seen=new Uint8Array(r.width*r.height),queue=new Int32Array(seen.length);let first=0,last=0;
 const visit=(x:number,y:number)=>{if(x<0||y<0||x>=r.width||y>=r.height)return;const i=y*r.width+x;if(seen[i])return;seen[i]=1;const p=r.pixel(x,y);if(Math.min(p[0],p[1],p[2])>65&&Math.max(p[0],p[1],p[2])-Math.min(p[0],p[1],p[2])<22)queue[last++]=i;};
 for(let x=0;x<r.width;x++){visit(x,0);visit(x,r.height-1);}for(let y=0;y<r.height;y++){visit(0,y);visit(r.width-1,y);}
 if(neckOpenings)for(let y=Math.floor(r.height*.12);y<r.height*.28;y++)visit(Math.floor(r.width/2),y);
 while(first<last){const i=queue[first++],x=i%r.width,y=Math.floor(i/r.width);r.set(x,y,[0,0,0,0]);visit(x-1,y);visit(x+1,y);visit(x,y-1);visit(x,y+1);}
 return r;
}
export function compileWearSource(source:Raster,job:WearSourceJob,body:Raster,referenceTop:Raster){
 if(job.kind==='bottom')return{front:fit(source,[Math.round(64-(job.width??28)/2),73,job.width??28,41]),back:new Raster(128,128)};
 if(job.kind==='shoes'){
  const [x,y,w,h]=bounds(source),middle=x+Math.floor(w/2),left=new Raster(source.width,source.height),right=new Raster(source.width,source.height);
  for(let yy=y;yy<y+h;yy++)for(let xx=x;xx<x+w;xx++)(xx<middle?left:right).set(xx,yy,source.pixel(xx,yy));
  const height=job.height??11,out=new Raster(128,128);
  out.blit(fit(left,[47,123-height,17,height]));out.blit(fit(right,[66,123-height,17,height]));
  return{front:out,back:new Raster(128,128)};
 }
 const result=compileGarment(source,job.kind,body,referenceTop,job.sleeve==='short',job.kind!=='jacket'||job.closed===true);
 // Shared opening removes generated inner lining from open outerwear so the equipped top remains visible.
 if(job.kind==='jacket'&&!job.closed)result.front.clearRect(61,43,7,31);
 return result;
}
