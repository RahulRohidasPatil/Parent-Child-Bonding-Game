import {z} from 'zod';
import {PortraitConfigSchema,DEFAULT_PORTRAIT,type PortraitManifest,type PortraitCosmetic,type ImageLayer} from '../portrait/model.js';
export {PORTRAIT_SLOTS as REFINED_SLOTS} from '../portrait/model.js';
export type {PortraitSlot as RefinedSlot} from '../portrait/model.js';
export const EYE_COLORS=['eye.dark_brown','eye.brown','eye.hazel','eye.green','eye.blue','eye.gray'] as const;
export type EyeColor=typeof EYE_COLORS[number];
export const EYE_COLOR_INFO=[{id:'eye.dark_brown',name:'Dark brown',color:'#503122'},{id:'eye.brown',name:'Brown',color:'#895a2e'},{id:'eye.hazel',name:'Hazel',color:'#8d8751'},{id:'eye.green',name:'Green',color:'#497a54'},{id:'eye.blue',name:'Blue',color:'#557ca5'},{id:'eye.gray',name:'Gray',color:'#8a969d'}];
export const RefinedConfigSchema=PortraitConfigSchema.extend({version:z.literal(4),pack:z.literal('atelier-r4'),rig:z.literal('front_idle_atelier_v2'),eyeColor:z.enum(EYE_COLORS).default('eye.dark_brown')}).strict();
export type RefinedConfig=z.infer<typeof RefinedConfigSchema>;
export interface RefinedLayer extends ImageLayer {eyeVariants?:Record<string,string>;headSkinVariants?:Record<string,Record<string,string>>}
export interface RefinedCosmetic extends Omit<PortraitCosmetic,'layers'>{layers:RefinedLayer[]}
export interface RefinedManifest extends Omit<PortraitManifest,'version'|'rig'|'pack'|'cosmetics'|'skins'>{version:4;rig:'front_idle_atelier_v2';pack:'atelier-r4';cosmetics:RefinedCosmetic[];skins:{id:string;color:string;layer:RefinedLayer}[];eyeColorSources:Record<string,string>;normalization:Record<string,unknown>}
export const DEFAULT_REFINED:RefinedConfig={...DEFAULT_PORTRAIT,version:4,pack:'atelier-r4',rig:'front_idle_atelier_v2',skin:'skin_02',eyeColor:'eye.dark_brown'};
export function validateRefined(input:unknown,m:RefinedManifest){const c=RefinedConfigSchema.parse(input);for(const [slot,id]of Object.entries(c.equipment)){if(id){const item=m.cosmetics.find(a=>a.id===id);if(!item||item.slot!==slot)throw new Error(`Invalid ${slot}: ${id}`);}}return c;}
export function refinedPresets(){return [{id:'navy',name:'Night shift',detail:'Deep navy. Clear focus.',config:DEFAULT_REFINED},{id:'quarter',name:'Clean quarter zip',detail:'A softer everyday.',config:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,top:'top.quarter'}}},{id:'hoodie',name:'Build night',detail:'Black hoodie. One more idea.',config:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,top:'top.hoodie',bottom:'bottom.black'}}},{id:'sport',name:'Off duty',detail:'Forest green, easy fit.',config:{...DEFAULT_REFINED,equipment:{...DEFAULT_REFINED.equipment,top:'top.forest_hoodie',bottom:'bottom.track'}}}];}
