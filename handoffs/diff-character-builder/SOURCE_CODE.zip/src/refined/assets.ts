import type {RefinedConfig,RefinedLayer} from './model.js';
export function refinedLayerFile(l:RefinedLayer,c:RefinedConfig){return l.headSkinVariants?.[c.equipment.head]?.[c.skin]??l.eyeVariants?.[c.eyeColor]??l.skinVariants?.[c.skin]??l.file;}
export function layerFiles(l:RefinedLayer){return [...new Set([l.file,...Object.values(l.skinVariants??{}),...Object.values(l.eyeVariants??{}),...Object.values(l.headSkinVariants??{}).flatMap(v=>Object.values(v))])];}
