import type {StudioConfig} from './model.js';

export class StudioHistory {
  private entries:StudioConfig[];
  private cursor=0;
  constructor(initial:StudioConfig){this.entries=[structuredClone(initial)];}
  get current(){return structuredClone(this.entries[this.cursor]);}
  get canUndo(){return this.cursor>0;}
  get canRedo(){return this.cursor<this.entries.length-1;}
  commit(config:StudioConfig){if(JSON.stringify(config)===JSON.stringify(this.current))return false;this.entries=this.entries.slice(0,this.cursor+1);this.entries.push(structuredClone(config));if(this.entries.length>100)this.entries.shift();this.cursor=this.entries.length-1;return true;}
  undo(){if(this.canUndo)this.cursor--;return this.current;}
  redo(){if(this.canRedo)this.cursor++;return this.current;}
}
