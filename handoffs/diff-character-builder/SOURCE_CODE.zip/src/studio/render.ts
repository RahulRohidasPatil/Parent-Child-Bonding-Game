import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { Raster, readPng, encodePng } from '../avatar/raster.js';
import { StudioConfigSchema, activeAssetIds, type StudioManifest } from './model.js';

const ROOT=resolve('assets/avatar/studio-r1');
let manifestPromise:Promise<StudioManifest>|undefined;
const layers=new Map<string,Promise<Raster>>();
const composites=new Map<string,Buffer>();
export function getStudioManifest():Promise<StudioManifest>{return manifestPromise??=(readFile(resolve(ROOT,'manifest.json'),'utf8').then(raw=>JSON.parse(raw) as StudioManifest));}
export async function renderStudio(input:unknown, hidden:string[]=[]):Promise<{png:Buffer;hash:string;layerIds:string[]}>{
  const config=StudioConfigSchema.parse(input);
  const manifest=await getStudioManifest();
  if(hidden.some(slot=>!manifest.assets.some(a=>a.slot===slot)))throw new Error('Unknown layer visibility slot');
  const key=JSON.stringify({...config,hidden:[...new Set(hidden)].sort()});
  const hash=createHash('sha256').update(key).digest('hex').slice(0,24);
  const enabled=new Set(activeAssetIds(config));
  const selected=manifest.assets.filter(a=>enabled.has(a.id)&&!hidden.includes(a.slot)).sort((a,b)=>a.z-b.z);
  const hit=composites.get(hash);if(hit)return {png:hit,hash,layerIds:selected.map(a=>a.id)};
  const output=new Raster(128,128);
  for(const asset of selected){
    let image=layers.get(asset.file);
    if(!image){image=readPng(resolve(ROOT,asset.file)).catch(err=>{layers.delete(asset.file);throw err;});layers.set(asset.file,image);}
    const raster=await image;
    if(raster.width!==128||raster.height!==128||raster.partialAlphaPixels())throw new Error(`Invalid layer: ${asset.id}`);
    // Shared headwear occlusion; source coordinates are never changed.
    const crown=config.hat&&!hidden.includes('headwear')&&(asset.slot==='hair_front'||asset.slot==='hair_back') ? (_x:number,y:number)=>y<(config.hat==='beanie'?16:15) : undefined;
    output.blit(raster,crown);
  }
  const png=encodePng(output);
  if(composites.size>=256)composites.delete(composites.keys().next().value!);
  composites.set(hash,png);
  return {png,hash,layerIds:selected.map(a=>a.id)};
}
