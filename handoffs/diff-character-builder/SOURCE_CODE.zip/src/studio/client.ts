import {StudioHistory} from './history.js';
import type {StudioConfig,StudioManifest,StudioAsset} from './model.js';
type Catalog={manifest:StudioManifest;defaults:StudioConfig;presets:{id:string;name:string;detail:string;config:StudioConfig}[];skins:{id:StudioConfig['skin'];color:string}[]};
type Tab='Looks'|'Hair'|'Face'|'Clothes'|'Extras';
const $=<T extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as T;
const esc=(text:string)=>text.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const paths:Record<string,string>={
  looks:'M12 3 14.7 9.3 21 12l-6.3 2.7L12 21l-2.7-6.3L3 12l6.3-2.7Z',
  hair:'M5 19V9a7 7 0 0 1 14 0v10M5 12c3 0 6-3 7-7 1 4 4 7 7 7M8 17v3m8-3v3',
  face:'M20 11c0 6-4 10-8 10S4 17 4 11 7 3 12 3s8 3 8 8ZM8 10h1m6 0h1m-7 5q3 2 6 0',
  clothes:'m8 3-6 4 3 5 3-2v11h8V10l3 2 3-5-6-4q-4 4-8 0Z',
  extras:'M3 9h7v6H3Zm11 0h7v6h-7Zm-4 2h4M3 9 1 7m20 2 2-2',
  image:'M3 3h18v18H3Zm0 14 6-6 5 5 3-3 4 4M16 7h.01',
  undo:'m9 5-6 6 6 6M3 11h11a6 6 0 0 1 6 6',
  redo:'m15 5 6 6-6 6m6-6H10a6 6 0 0 0-6 6',
  reset:'M4 9a8 8 0 1 1-1 7M4 3v6h6',
  shuffle:'M3 6h3c4 0 8 12 12 12h3M3 18h3c2 0 4-3 6-6s4-6 6-6h3m-3-3 3 3-3 3m0 6 3 3-3 3',
  download:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',
  layers:'m12 3 10 5-10 5L2 8Zm-9 10 9 5 9-5M3 18l9 5 9-5',
  chevron:'m8 5 7 7-7 7',check:'m5 12 4 4L19 6',close:'m6 6 12 12M6 18 18 6',none:'M20 12a8 8 0 1 1-16 0 8 8 0 0 1 16 0ZM6 6l12 12',eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7Zm13 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0',
};
const icon=(key:string)=>`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[key]??paths.layers}"/></svg>`;
document.querySelectorAll<HTMLElement>('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon!));
let catalog:Catalog,history:StudioHistory;
let currentTab:Tab='Looks',sub='Tops',lastSaved='',hidden=new Set<string>();
let renderSequence=0,controller:AbortController|undefined,previewUrl:string|undefined;
let toastTimer:ReturnType<typeof setTimeout>;
const STORAGE='diff-avatar-studio-r1';
const tabs:Tab[]=['Looks','Hair','Face','Clothes','Extras'];
const same=(a:unknown,b:unknown)=>JSON.stringify(a)===JSON.stringify(b);
const preview=(config:StudioConfig)=>'/api/studio/render?'+new URLSearchParams({config:JSON.stringify(config)});
function toast(message:string){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,3500);}
function commit(changes:Partial<StudioConfig>|StudioConfig){history.commit({...history.current,...changes});hidden.clear();paint();void updatePreview();}
function pickedAssets(config:StudioConfig):StudioAsset[]{
  const ids=[`body.${config.skin}`,config.hair==='long_wavy'?'hair.long_wavy.back':'',config.hair?`hair.${config.hair}.front`:'',config.eyes?'eyes.neutral':'',config.brows?'brows.straight':'',config.mouth?'mouth.smile':'',config.top?'top.cream':'',config.jacket?'jacket.track':'',config.bottom?`bottom.${config.bottom}`:'',config.shoes?'shoes.white':'',config.hat?`hat.${config.hat}`:'',config.glasses?'glasses.round':''];
  return catalog.manifest.assets.filter(a=>ids.includes(a.id)).sort((a,b)=>a.z-b.z);
}
function paint(){
  const c=history.current;
  $<HTMLButtonElement>('undo').disabled=!history.canUndo;$<HTMLButtonElement>('redo').disabled=!history.canRedo;
  $('save-state').textContent=JSON.stringify(c)===lastSaved?'Saved on this device':'Unsaved changes';
  $('look-name').textContent=catalog.presets.find(p=>same(p.config,c))?.name??'Your own thing';
  document.querySelector('.category-tabs')!.innerHTML=tabs.map(t=>`<button class="category-tab" role="tab" id="tab-${t.toLowerCase()}" aria-controls="selection-grid" aria-selected="${t===currentTab}" tabindex="${t===currentTab?0:-1}" data-tab="${t}">${icon(t.toLowerCase())}<span>${t}</span></button>`).join('');
  $('selection-grid').setAttribute('aria-labelledby',`tab-${currentTab.toLowerCase()}`);
  const content={Looks:['Find your starting point','A few looks to make your own.'],Hair:['Good hair, every day.','Pick a silhouette. Keep your own style.'],Face:['The little details.','One base. Your tone and expression.'],Clothes:['Dress for your kind of day.','Layer up, keep it casual, make it you.'],Extras:['The finishing touches.','A little something that feels like you.']}[currentTab];
  $('category-title').textContent=content[0];$('category-subtitle').textContent=content[1];
  const subs=currentTab==='Clothes'?['Tops','Jackets','Bottoms','Shoes']:currentTab==='Extras'?['Hats','Glasses']:[];
  if(subs.length&&!subs.includes(sub))sub=subs[0];
  $('subcategories').innerHTML=subs.map(s=>`<button class="subcategory" data-sub="${s}" aria-pressed="${sub===s}">${s}</button>`).join('');
  type Card={key:string;name:string;detail:string;selected:boolean;patch:Partial<StudioConfig>;none?:boolean};
  let cards:Card[]=[];
  if(currentTab==='Looks')cards=catalog.presets.map(p=>({key:p.id,name:p.name,detail:p.detail,selected:same(c,p.config),patch:p.config}));
  if(currentTab==='Hair')cards=[{key:'fluffy',name:'Fluffy middle part',detail:'Dark brown · Short',selected:c.hair==='fluffy',patch:{hair:'fluffy'}},{key:'long-wavy',name:'Long wavy',detail:'Dark brown · Long',selected:c.hair==='long_wavy',patch:{hair:'long_wavy'}},{key:'no-hair',name:'No hair',detail:'Keep it minimal.',selected:c.hair===null,patch:{hair:null},none:true}];
  if(currentTab==='Clothes'){
    if(sub==='Tops')cards=[{key:'quarter',name:'Fleece quarter zip',detail:'Cream · Soft essentials',selected:c.top,patch:{top:true}},{key:'no-top',name:'No top',detail:'Base layer only',selected:!c.top,patch:{top:false},none:true}];
    if(sub==='Jackets')cards=[{key:'track-jacket',name:'Track jacket',detail:'Black · Green piping',selected:c.jacket,patch:{jacket:true}},{key:'no-jacket',name:'No jacket',detail:'Keep things light.',selected:!c.jacket,patch:{jacket:false},none:true}];
    if(sub==='Bottoms')cards=[{key:'straight',name:'Straight trousers',detail:'Black · Everyday fit',selected:c.bottom==='straight',patch:{bottom:'straight'}},{key:'track',name:'Track pants',detail:'Black · Tapered fit',selected:c.bottom==='track',patch:{bottom:'track'}},{key:'no-bottom',name:'No bottoms',detail:'Neutral underwear',selected:c.bottom===null,patch:{bottom:null},none:true}];
    if(sub==='Shoes')cards=[{key:'low-sneakers',name:'Low sneakers',detail:'White · Simple classics',selected:c.shoes,patch:{shoes:true}},{key:'no-shoes',name:'No shoes',detail:'Bare feet',selected:!c.shoes,patch:{shoes:false},none:true}];
  }
  if(currentTab==='Extras'){
    if(sub==='Hats')cards=[{key:'cap',name:'Classic cap',detail:'Black · Off-duty',selected:c.hat==='cap',patch:{hat:'cap'}},{key:'beanie',name:'Folded beanie',detail:'Black · Late-night staple',selected:c.hat==='beanie',patch:{hat:'beanie'}},{key:'no-hat',name:'No hat',detail:'Let your hair do its thing.',selected:!c.hat,patch:{hat:null},none:true}];
    if(sub==='Glasses')cards=[{key:'round',name:'Round glasses',detail:'Graphite · Thin frames',selected:c.glasses,patch:{glasses:true}},{key:'no-glasses',name:'No glasses',detail:'Nothing extra.',selected:!c.glasses,patch:{glasses:false},none:true}];
  }
  $('selection-grid').innerHTML=currentTab==='Face'?`<div class="skin-grid" aria-label="Skin tone">${catalog.skins.map(s=>`<button class="skin-swatch" style="background:${s.color}" data-skin="${s.id}" aria-label="Skin tone ${Number(s.id.slice(-2))}" aria-pressed="${c.skin===s.id}"></button>`).join('')}</div><div class="face-toggles">${(['eyes','brows','mouth'] as const).map((key,i)=>`<button class="face-toggle" data-face="${key}" aria-pressed="${c[key]}"><span>${['Neutral eyes','Straight brows','Small smile'][i]}</span><span class="toggle-track" aria-hidden="true"></span></button>`).join('')}</div>`:cards.map(card=>`<button class="selection-card" data-choice="${card.key}" aria-pressed="${card.selected}" aria-label="${esc(card.name)}"><span class="card-image">${card.none?`<span class="none-symbol">${icon('none')}</span>`:`<img src="${esc(preview({...c,...card.patch}))}" width="128" height="128" alt="" loading="eager">`}<span class="selected-tick">${icon('check')}</span></span><span class="card-label"><span><strong>${esc(card.name)}</strong><small>${esc(card.detail)}</small></span><span aria-hidden="true">↗</span></span></button>`).join('');
  const itemCount=cards.filter(card=>!card.none).length;
  $('item-count').textContent=currentTab==='Face'?'12 tones':`${itemCount} ${currentTab==='Looks'?'looks':itemCount===1?'style':'styles'}`;
  $('category-note').innerHTML=icon('check')+(currentTab==='Looks'?'A starting point, never a box to fit into.':currentTab==='Face'?'Every skin tone uses the same body.':'Starter collection · Built from your original artwork.');
  $('equipped').innerHTML=pickedAssets(c).filter(a=>!['body','eyes','brows','mouth','hair_back'].includes(a.slot)).map(a=>`<span class="equipped-chip">${esc(a.name.replace(' · front',''))}</span>`).join('');
  paintInspector();
  document.querySelectorAll<HTMLButtonElement>('[data-tab]').forEach(b=>{b.onclick=()=>{currentTab=b.dataset.tab as Tab;paint();document.getElementById(`tab-${currentTab.toLowerCase()}`)?.focus();};b.onkeydown=e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const i=tabs.indexOf(currentTab);currentTab=e.key==='Home'?tabs[0]:e.key==='End'?tabs[4]:tabs[(i+(e.key==='ArrowRight'?1:4))%5];paint();document.getElementById(`tab-${currentTab.toLowerCase()}`)?.focus();};});
  document.querySelectorAll<HTMLButtonElement>('[data-sub]').forEach(b=>b.onclick=()=>{sub=b.dataset.sub!;paint();});
  document.querySelectorAll<HTMLButtonElement>('[data-choice]').forEach(b=>b.onclick=()=>{const card=cards.find(o=>o.key===b.dataset.choice)!;commit(card.patch);document.querySelector<HTMLButtonElement>(`[data-choice="${card.key}"]`)?.focus();});
  document.querySelectorAll<HTMLButtonElement>('[data-skin]').forEach(b=>b.onclick=()=>{commit({skin:b.dataset.skin as StudioConfig['skin']});document.querySelector<HTMLButtonElement>(`[data-skin="${b.dataset.skin}"]`)?.focus();});
  document.querySelectorAll<HTMLButtonElement>('[data-face]').forEach(b=>b.onclick=()=>{const key=b.dataset.face as 'eyes'|'brows'|'mouth';commit({[key]:!history.current[key]});document.querySelector<HTMLButtonElement>(`[data-face="${key}"]`)?.focus();});
}
function paintInspector(){
  $('config-json').textContent=JSON.stringify(history.current,null,2);
  $('layer-list').innerHTML=pickedAssets(history.current).map(a=>`<button class="layer-toggle" data-layer="${a.slot}" aria-pressed="${!hidden.has(a.slot)}" aria-label="Show ${esc(a.name)}"><img src="/assets/avatar/studio-r1/${esc(a.file)}" alt="" width="128" height="128"><span>${esc(a.name)}</span>${icon('eye')}</button>`).join('');
  document.querySelectorAll<HTMLButtonElement>('[data-layer]').forEach(b=>b.onclick=()=>{const slot=b.dataset.layer!;hidden.has(slot)?hidden.delete(slot):hidden.add(slot);paintInspector();void updatePreview();});
}
async function updatePreview(){
  const sequence=++renderSequence;controller?.abort();controller=new AbortController();
  $('export').setAttribute('aria-disabled','true');$('render-loading').hidden=false;$('render-loading').textContent='Updating…';
  try{
    const response=await fetch('/api/studio/render?'+new URLSearchParams({hidden:[...hidden].join(',')}),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(history.current),signal:controller.signal});
    if(!response.ok)throw new Error('The avatar could not be rendered. Please try again.');
    const blob=await response.blob();if(sequence!==renderSequence)return;
    const next=URL.createObjectURL(blob);const img=$<HTMLImageElement>('avatar');
    img.src=next;await img.decode();if(sequence!==renderSequence){URL.revokeObjectURL(next);return;}
    if(previewUrl)URL.revokeObjectURL(previewUrl);previewUrl=next;
    img.hidden=false;img.dataset.hash=response.headers.get('x-avatar-hash')??'';
    $('load-error').hidden=true;$('render-loading').hidden=true;$('export').setAttribute('aria-disabled','false');$<HTMLAnchorElement>('export').href=preview(history.current)+'&download=1';$<HTMLButtonElement>('save').disabled=false;
  }catch(error){if((error as Error).name==='AbortError')return;$('load-error').textContent=(error as Error).message;$('load-error').hidden=false;$('render-loading').hidden=true;}
}
function download(blob:Blob,name:string){const a=document.createElement('a');const url=URL.createObjectURL(blob);a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);}
async function save(){const b=$<HTMLButtonElement>('save');b.disabled=true;try{
  const snapshot=history.current;const response=await fetch('/api/studio/validate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(snapshot)});if(!response.ok)throw new Error('This configuration could not be saved.');
  const validated=await response.json();localStorage.setItem(STORAGE,JSON.stringify(validated));lastSaved=JSON.stringify(validated);paint();toast('Avatar saved on this device.');
}catch(error){toast(error instanceof Error?error.message:'Saving is unavailable in this browser.');}finally{b.disabled=false;}}
async function boot(){
  try{
    const response=await fetch('/api/studio/catalog');if(!response.ok)throw new Error('The wardrobe is unavailable. Please reload this page.');catalog=await response.json();
    let initial=catalog.defaults;
    try{const saved=localStorage.getItem(STORAGE);if(saved){const check=await fetch('/api/studio/validate',{method:'POST',headers:{'content-type':'application/json'},body:saved});if(check.ok){initial=await check.json();lastSaved=JSON.stringify(initial);}else toast('Your saved avatar could not be loaded. Your original save has been kept.');}}catch{toast('Local storage is unavailable. You can still export your avatar.');}
    history=new StudioHistory(initial);paint();await updatePreview();
    $('undo').onclick=()=>{history.undo();hidden.clear();paint();void updatePreview();};$('redo').onclick=()=>{history.redo();hidden.clear();paint();void updatePreview();};
    $('reset').onclick=()=>{commit(catalog.defaults);toast('Back to the original look. Undo is available.');};
    $('randomize').onclick=()=>{const pick=<T>(items:T[])=>items[Math.floor(Math.random()*items.length)];const next:StudioConfig={...catalog.defaults,skin:pick(catalog.skins).id,hair:pick(['fluffy','long_wavy']),jacket:Math.random()<.5,bottom:pick(['straight','track']),hat:pick([null,null,'cap','beanie']),glasses:Math.random()<.4};if(same(next,history.current))next.glasses=!next.glasses;commit(next);};
    $('save').onclick=()=>void save();
    $('export').onclick=e=>{if($('export').getAttribute('aria-disabled')==='true')e.preventDefault();};
    $('export-config').onclick=()=>download(new Blob([JSON.stringify(history.current,null,2)],{type:'application/json'}),'diff-avatar-config.json');
    $('inspect').onclick=()=>{const panel=$('inspector');panel.hidden=!panel.hidden;$('inspect').setAttribute('aria-expanded',String(!panel.hidden));if(panel.hidden){hidden.clear();$<HTMLInputElement>('show-grid').checked=false;$('grid-overlay').hidden=true;paintInspector();void updatePreview();}};
    $('restore-layers').onclick=()=>{hidden.clear();paintInspector();void updatePreview();};
    $<HTMLInputElement>('show-grid').onchange=e=>$('grid-overlay').hidden=!(e.target as HTMLInputElement).checked;
    document.querySelectorAll<HTMLButtonElement>('[data-bg]').forEach(b=>b.onclick=()=>{$('stage').dataset.background=b.dataset.bg;document.querySelectorAll('[data-bg]').forEach(el=>el.setAttribute('aria-pressed',String(el===b)));});
    const dialog=$<HTMLDialogElement>('art-dialog');
    $('originals').onclick=()=>{const names:Record<string,string>={body:'Blank base body',base:'Quarter zip',cap:'Classic cap',beanie:'Folded beanie',trackJacket:'Track jacket',longWavy:'Long wavy',glasses:'Round glasses',trackPants:'Track pants'};
      $('art-grid').innerHTML=Object.entries(catalog.manifest.sources).map(([key,path])=>`<figure class="art-card"><img src="/${esc(path)}" alt="${esc(names[key]??key)} original artwork"><figcaption>${esc(names[key]??key)}</figcaption><a href="/${esc(path)}" target="_blank" rel="noopener">Open original ↗</a></figure>`).join('');dialog.showModal();};
    $('close-dialog').onclick=()=>dialog.close();dialog.addEventListener('click',e=>{if(e.target===dialog){const box=dialog.getBoundingClientRect();if(e.clientX<box.left||e.clientX>box.right||e.clientY<box.top||e.clientY>box.bottom)dialog.close();}});
    document.addEventListener('keydown',e=>{if(!(e.metaKey||e.ctrlKey)||e.key.toLowerCase()!=='z'||(e.target as HTMLElement).matches('input,textarea'))return;e.preventDefault();e.shiftKey?history.redo():history.undo();hidden.clear();paint();void updatePreview();});
  }catch(error){$('load-error').textContent=(error as Error).message;$('load-error').hidden=false;$('render-loading').hidden=true;}
}
void boot();
