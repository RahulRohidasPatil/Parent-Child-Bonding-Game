import { z } from 'zod';

export const StudioConfigSchema = z.object({
  version: z.literal(1), pack: z.literal('studio-r1'),
  skin: z.enum(['skin_01','skin_02','skin_03','skin_04','skin_05','skin_06','skin_07','skin_08','skin_09','skin_10','skin_11','skin_12']),
  hair: z.enum(['fluffy','long_wavy']).nullable(),
  eyes: z.boolean(), brows: z.boolean(), mouth: z.boolean(),
  top: z.boolean(), jacket: z.boolean(),
  bottom: z.enum(['straight','track']).nullable(), shoes: z.boolean(),
  hat: z.enum(['cap','beanie']).nullable(), glasses: z.boolean(),
}).strict();
export type StudioConfig = z.infer<typeof StudioConfigSchema>;
export const DEFAULT_STUDIO: StudioConfig = {version:1,pack:'studio-r1',skin:'skin_04',hair:'fluffy',eyes:true,brows:true,mouth:true,top:true,jacket:false,bottom:'straight',shoes:true,hat:null,glasses:false};
export const PRESETS = [
  {id:'everyday',name:'Everyday',detail:'Keep it simple.',config:DEFAULT_STUDIO},
  {id:'after-hours',name:'After hours',detail:'One more commit.',config:{...DEFAULT_STUDIO,hat:'beanie' as const}},
  {id:'long-wavy',name:'Long wavy',detail:'A different flow.',config:{...DEFAULT_STUDIO,hair:'long_wavy' as const}},
  {id:'track-day',name:'Track day',detail:'Ready when you are.',config:{...DEFAULT_STUDIO,jacket:true,bottom:'track' as const}},
];
export interface StudioAsset {id:string; name:string; file:string; slot:string; z:number; source:string; bounds:[number,number,number,number]}
export interface StudioManifest {version:1; pack:'studio-r1'; size:128; assets:StudioAsset[]; sources:Record<string,string>; sourceHashes:Record<string,string>}

export function activeAssetIds(c: StudioConfig): string[] {
  return [c.hair==='long_wavy'?'hair.long_wavy.back':null,`body.${c.skin}`,c.bottom?`bottom.${c.bottom}`:null,c.shoes?'shoes.white':null,c.top?'top.cream':null,c.jacket?'jacket.track':null,c.eyes?'eyes.neutral':null,c.brows?'brows.straight':null,c.mouth?'mouth.smile':null,c.hair?`hair.${c.hair}.front`:null,c.glasses?'glasses.round':null,c.hat?`hat.${c.hat}`:null].filter((v):v is string=>v!==null);
}
