import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {Raster,decodePng,encodePng} from '../avatar/raster.js';
import {validateAtelier,AtelierManifest,SLOTS,AtelierConfig,ImageLayer} from './model.js';
const ROOT=resolve('assets/avatar/atelier-r2');
let meta:Promise<AtelierManifest>|undefined;
const loaded=new Map<string,Promise<Raster>>(),composites=new Map<string,Buffer>();
export function atelierManifest():Promise<AtelierManifest>{return meta??=readFile(resolve(ROOT,'manifest.json'),'utf8').then(raw=>JSON.parse(raw) as AtelierManifest);}
async function image(path:string):Promise<Raster>{let promise=loaded.get(path);if(!promise){promise=readFile(resolve(ROOT,path)).then(bytes=>{const r=decodePng(bytes);if(r.width!==128||r.height!==128||r.partialAlphaPixels())throw new Error('Invalid 128-pixel layer '+path);return r;}).catch(e=>{loaded.delete(path);throw e;});loaded.set(path,promise);}return promise;}
export async function renderAtelier(input:unknown,hidden:string[]=[]):Promise<{png:Buffer;hash:string;layers:string[]}>{
  const manifest=await atelierManifest(),config=validateAtelier(input,manifest);
  if(hidden.some(s=>s!=='body'&&!SLOTS.includes(s as typeof SLOTS[number])))throw new Error('Unknown hidden slot');
  const artworkRevision=createHash('sha256').update(JSON.stringify(manifest)).digest('hex');
  const key=JSON.stringify({artworkRevision,config,hidden:[...new Set(hidden)].sort()}),hash=createHash('sha256').update(key).digest('hex').slice(0,24);
  const renderLayers:{layer:ImageLayer;slot:string}[]=[];
  if(!hidden.includes('body'))renderLayers.push({layer:manifest.skins.find(s=>s.id===config.skin)!.layer,slot:'body'});
  for(const slot of SLOTS){const id=config.equipment[slot];if(!id||hidden.includes(slot))continue;const cosmetic=manifest.cosmetics.find(c=>c.id===id)!;for(const layer of cosmetic.layers)renderLayers.push({layer,slot});}
  renderLayers.sort((a,b)=>a.layer.z-b.layer.z);
  const keys=renderLayers.map(r=>r.layer.skinVariants?.[config.skin]??r.layer.file),cached=composites.get(hash);if(cached)return {png:cached,hash,layers:keys};
  const output=new Raster(128,128),masks:Record<string,Raster[]>={};
  for(const {layer} of renderLayers)for(const target of layer.hide??[]){const [region,maskId]=target.split(':');if(!manifest.masks[maskId])throw new Error('Missing mask '+maskId);(masks[region]??=[]).push(await image(manifest.masks[maskId]));}
  for(const {layer} of renderLayers){const r=await image(layer.skinVariants?.[config.skin]??layer.file),occlusion=masks[layer.region];output.blit(r,occlusion?(x,y)=>occlusion.some(mask=>mask.pixel(x,y)[3]===255):undefined);}
  const png=encodePng(output);if(composites.size>=512)composites.delete(composites.keys().next().value!);composites.set(hash,png);return {png,hash,layers:keys};
}
export function atelierPresets(config:AtelierConfig){return [
  {id:'navy',name:'Night shift',detail:'Deep navy. Clear focus.',config},
  {id:'quarter',name:'Clean quarter zip',detail:'A softer everyday.',config:{...config,equipment:{...config.equipment,top:'top.quarter'}}},
  {id:'hoodie',name:'Build night',detail:'Black hoodie. One more idea.',config:{...config,equipment:{...config.equipment,top:'top.hoodie',bottom:'bottom.black'}}},
  {id:'sport',name:'Off duty',detail:'Forest green, easy fit.',config:{...config,equipment:{...config.equipment,top:'top.forest_hoodie',bottom:'bottom.track'}}}
];}
