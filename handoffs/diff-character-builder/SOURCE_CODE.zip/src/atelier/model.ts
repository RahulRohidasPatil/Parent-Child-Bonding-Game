import {z} from 'zod';
export const SLOTS=['hair','eyes','brows','nose','mouth','ears','top','jacket','bottom','shoes','hat','glasses','earrings'] as const;
export type Slot=typeof SLOTS[number];
const item=z.string().regex(/^[a-z][a-z0-9_.-]+$/).nullable();
export const AtelierConfigSchema=z.object({version:z.literal(2),rig:z.literal('front_idle_atelier_v1'),pack:z.literal('atelier-r2'),skin:z.enum(['skin_01','skin_02','skin_03','skin_04','skin_05','skin_06','skin_07','skin_08','skin_09','skin_10','skin_11','skin_12']),equipment:z.object({hair:item,eyes:item,brows:item,nose:item.default(null),mouth:item,ears:item,top:item,jacket:item,bottom:item,shoes:item,hat:item,glasses:item,earrings:item}).strict()}).strict();
export type AtelierConfig=z.infer<typeof AtelierConfigSchema>;
export interface ImageLayer {file:string;z:number;region:string;source:string;sha256:string;hide?:string[];skinVariants?:Record<string,string>}
export interface Cosmetic {id:string;name:string;slot:Slot;collection:string;color:string;layers:ImageLayer[];note?:string}
export interface AtelierManifest {version:2;rig:'front_idle_atelier_v1';pack:'atelier-r2';size:128;cosmetics:Cosmetic[];skins:{id:string;color:string;layer:ImageLayer}[];regions:Record<string,[number,number,number,number]>;masks:Record<string,string>;sources:Record<string,string>;pictureHashes:Record<string,string>}
export const DEFAULT_ATELIER:AtelierConfig={version:2,rig:'front_idle_atelier_v1',pack:'atelier-r2',skin:'skin_04',equipment:{hair:'hair.textured',eyes:'eyes.neutral',brows:'brows.straight',nose:'nose.subtle',mouth:'mouth.neutral',ears:'ears.classic',top:'top.navy',jacket:null,bottom:'bottom.denim',shoes:'shoes.white',hat:null,glasses:null,earrings:null}};
export function validateAtelier(input:unknown,manifest:AtelierManifest):AtelierConfig{const c=AtelierConfigSchema.parse(input);for(const slot of SLOTS){const id=c.equipment[slot];if(id){const item=manifest.cosmetics.find(a=>a.id===id);if(!item||item.slot!==slot)throw new Error(`Invalid ${slot} selection: ${id}`);}}return c;}
