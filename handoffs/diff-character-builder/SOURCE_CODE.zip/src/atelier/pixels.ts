import {PNG} from 'pngjs';
import {readFile} from 'node:fs/promises';
import {Raster} from '../avatar/raster.js';
export type Box=[number,number,number,number];

export async function sourcePng(path:string):Promise<Raster>{
  const bytes=await readFile(path);const p=PNG.sync.read(bytes);const r=new Raster(p.width,p.height);r.data.set(p.data);
  if(!p.alpha)throw new Error(`Source has no real alpha: ${path}`);
  return r;
}
export function bounds(r:Raster):Box{
  let l=r.width,t=r.height,rr=-1,b=-1;
  for(let y=0;y<r.height;y++)for(let x=0;x<r.width;x++)if(r.data[(y*r.width+x)*4+3]>=192){l=Math.min(l,x);rr=Math.max(rr,x);t=Math.min(t,y);b=Math.max(b,y);}
  if(rr<0)throw new Error('Empty source layer');return [l,t,rr-l+1,b-t+1];
}
/** Pure offline image resampling. Copies original RGB; no vector drawing or recolor filters. */
export function fit(source:Raster,target:Box,clip:Box=bounds(source)):Raster{
  const output=new Raster(128,128);const [tx,ty,tw,th]=target,[sx,sy,sw,sh]=clip;
  for(let y=0;y<th;y++)for(let x=0;x<tw;x++){
    const p=source.pixel(Math.min(source.width-1,Math.floor(sx+(x+.5)*sw/tw)),Math.min(source.height-1,Math.floor(sy+(y+.5)*sh/th)));
    if(p[3]>=192)output.set(tx+x,ty+y,[p[0],p[1],p[2],255]);
  }return output;
}
