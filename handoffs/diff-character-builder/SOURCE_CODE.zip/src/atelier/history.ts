import type {AtelierConfig} from './model.js';
import {canonicalVisualKey} from '../collection/assets.js';
export class AtelierHistory<T extends object=AtelierConfig>{
  private entries:T[];private cursor=0;
  constructor(initial:T){this.entries=[structuredClone(initial)];}
  get current(){return structuredClone(this.entries[this.cursor]);}
  get canUndo(){return this.cursor>0;}
  get canRedo(){return this.cursor<this.entries.length-1;}
  commit(config:T){if(canonicalVisualKey(config)===canonicalVisualKey(this.current))return false;this.entries=this.entries.slice(0,this.cursor+1);this.entries.push(structuredClone(config));if(this.entries.length>100)this.entries.shift();this.cursor=this.entries.length-1;return true;}
  undo(){if(this.canUndo)this.cursor--;}
  redo(){if(this.canRedo)this.cursor++;}
}
