import {hairDetails,HAIR_TEXTURES,HAIR_FRINGES} from '../collection/hairCatalog.js';
import {initSelfie} from '../selfie/client.js';
import {AtelierHistory} from './history.js';
import {EditorAsyncState,withDeadline} from './asyncState.js';
import type {CollectionConfig as AtelierConfig,CollectionManifest as AtelierManifest,CollectionSlot as Slot,CollectionCosmetic as Cosmetic} from '../collection/model.js';
import {collectionLayerFile as exactLayerFile,canonicalVisualKey} from '../collection/assets.js';
import {PERSONAL_SLOTS} from '../collection/identitySlots.js';
import {WEAR_SLOTS,type WearSlot,type WearColor} from '../collection/wearPalettes.js';
type Catalog={wearColors:{id:WearColor;name:string;color:string}[];hairColors:{id:AtelierConfig['hairColor'];name:string;color:string}[];hairColorStyle:string;eyeColors:{id:AtelierConfig['eyeColor'];name:string;color:string}[];manifest:AtelierManifest;defaults:AtelierConfig;presets:{id:string;name:string;detail:string;config:AtelierConfig}[];legacySources:Record<string,string>};
type Tab='Looks'|'Hair'|'Face'|'Clothes'|'Extras';
const $=<T extends HTMLElement=HTMLElement>(id:string)=>document.getElementById(id) as T;
const esc=(s:string)=>s.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]!));
const paths:Record<string,string>={looks:'m12 3 3 6 6 3-6 3-3 6-3-6-6-3 6-3Z',hair:'M5 20V10a7 7 0 0 1 14 0v10M5 12c4 0 7-5 7-7 0 4 3 7 7 7',face:'M20 11c0 6-4 10-8 10S4 17 4 11 7 3 12 3s8 3 8 8ZM8 10h1m6 0h1m-7 5q3 2 6 0',clothes:'m8 3-6 4 3 5 3-2v11h8V10l3 2 3-5-6-4q-4 4-8 0Z',extras:'M3 9h7v6H3Zm11 0h7v6h-7Zm-4 2h4',image:'M3 3h18v18H3Zm0 14 6-6 5 5 3-3 4 4M16 7h.01',undo:'m9 5-6 6 6 6M3 11h11a6 6 0 0 1 6 6',redo:'m15 5 6 6-6 6m6-6H10a6 6 0 0 0-6 6',reset:'M4 9a8 8 0 1 1-1 7M4 3v6h6',shuffle:'M3 6h3c4 0 8 12 12 12h3M3 18h3c4 0 8-12 12-12h3m-3-3 3 3-3 3m0 6 3 3-3 3',download:'M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5',layers:'m12 3 10 5-10 5L2 8Zm-9 10 9 5 9-5M3 18l9 5 9-5',chevron:'m8 5 7 7-7 7',check:'m5 12 4 4L19 6',close:'m6 6 12 12M6 18 18 6',none:'M20 12a8 8 0 1 1-16 0 8 8 0 0 1 16 0ZM6 6l12 12',eye:'M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7Zm13 0a3 3 0 1 1-6 0 3 3 0 0 1 6 0'};
const icon=(name:string)=>`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[name]??paths.layers}"/></svg>`;
document.querySelectorAll<HTMLElement>('[data-icon]').forEach(el=>el.innerHTML=icon(el.dataset.icon!));
const STORAGE='diff-avatar-collection-r6',DRAFT_STORAGE='diff-avatar-collection-r6-draft',tabs:Tab[]=['Looks','Hair','Face','Clothes','Extras'];
const slotNames:Record<Slot,string>={head:'Head',hair:'Hair',eyes:'Eyes',brows:'Brows',nose:'Nose',mouth:'Mouth',ears:'Ears',top:'Tops',jacket:'Jackets',bottom:'Bottoms',shoes:'Shoes',hat:'Hats',glasses:'Glasses',earrings:'Earrings',tie:'Ties',facialHair:'Facial hair',freckles:'Freckles',birthmark:'Birthmark',scar:'Scar',ageLines:'Age lines',hearingAidLeft:'Left hearing aid',hearingAidRight:'Right hearing aid'};
let catalog:Catalog,history:AtelierHistory<AtelierConfig>,currentTab:Tab='Looks',sub='Tops',lastSaved='',hidden=new Set<string>();
const requests=new EditorAsyncState(),subByTab:Record<Tab,string>={Looks:'',Hair:'Styles',Face:'Head',Clothes:'Tops',Extras:'Glasses'};
let controller:AbortController|undefined,blobUrl:string|undefined,toastTimer:ReturnType<typeof setTimeout>;
const same=(a:object,b:object)=>canonicalVisualKey(a)===canonicalVisualKey(b);
const preview=(c:AtelierConfig)=>'/api/collection/render?'+new URLSearchParams({config:JSON.stringify(c)});
function toast(message:string){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,4000);}
function rememberDraft(){try{sessionStorage.setItem(DRAFT_STORAGE,JSON.stringify(history.current));}catch{}}
function syncControls(){$<HTMLButtonElement>('save').disabled=!requests.canSave;$('export').setAttribute('aria-disabled',String(!requests.canExport));}
function withoutHeadwear(c:AtelierConfig):AtelierConfig{return {...c,equipment:{...c.equipment,hat:null},wearColors:{...c.wearColors,hat:'wear.original'},wearAccentColors:{...c.wearAccentColors,hat:'wear.original'}};}
function commit(c:AtelierConfig){c=withoutHeadwear(c);const changed=history.commit(c);if(!changed&&!hidden.size)return;hidden.clear();rememberDraft();paint();void updatePreview();}
function switchTab(tab:Tab){subByTab[currentTab]=sub;currentTab=tab;sub=subByTab[tab];$<HTMLInputElement>('wardrobe-search').value='';$<HTMLSelectElement>('collection-filter').value='all';$('selection-grid').scrollTop=0;paint();$(`tab-${tab.toLowerCase()}`).focus({preventScroll:true});}
function equip(c:AtelierConfig,slot:Slot,id:string|null){const next={...c,equipment:{...c.equipment,[slot]:id}};const tie=catalog.manifest.cosmetics.find(a=>a.id===next.equipment.tie);if(tie?.compatibleTops&&!tie.compatibleTops.includes(next.equipment.top??'')){if(slot==='tie')next.equipment.top=tie.compatibleTops[0];else next.equipment.tie=null;}return next;}
function selected(c:AtelierConfig){return catalog.manifest.cosmetics.filter(a=>Object.values(c.equipment).includes(a.id));}
function paint(){
  const selectionScroll=$('selection-grid').scrollTop;
  const c=history.current;
  $<HTMLButtonElement>('undo').disabled=!history.canUndo;$<HTMLButtonElement>('redo').disabled=!history.canRedo;
  $('save-state').textContent=canonicalVisualKey(c)===lastSaved?'Saved on this device':'Unsaved changes';
  $('look-name').textContent=catalog.presets.find(p=>same(p.config,c))?.name??'Your own thing';
  document.querySelector('.category-tabs')!.innerHTML=tabs.map(t=>`<button class="category-tab" role="tab" id="tab-${t.toLowerCase()}" aria-controls="selection-grid" aria-selected="${t===currentTab}" tabindex="${t===currentTab?0:-1}" data-tab="${t}">${icon(t.toLowerCase())}<span>${t}</span></button>`).join('');
  $('selection-grid').setAttribute('aria-labelledby',`tab-${currentTab.toLowerCase()}`);
  const titles={Looks:['Find your starting point','Nine looks. A larger wardrobe to make your own.'],Hair:['Good hair, every day.','Texture, shape, and a little personality.'],Face:['The little details.','Your tone. Your expression. Your own character.'],Clothes:['Dress for your kind of day.','Soft knits, everyday layers, late-night staples.'],Extras:['The finishing touches.','The details that make it feel like you.']}[currentTab];
  $('category-title').textContent=titles[0];$('category-subtitle').textContent=titles[1];
  const subs=currentTab==='Hair'?['Styles','Color']:currentTab==='Clothes'?['Tops','Jackets','Bottoms','Shoes']:currentTab==='Extras'?['Glasses','Earrings','Ties']:currentTab==='Face'?['Head','Skin','Eyes','Eye color','Brows','Nose','Mouth','Ears','Facial hair','Details']:[];
  if(subs.length&&!subs.includes(sub))sub=subs[0];
  $('subcategories').innerHTML=subs.map(s=>`<button class="subcategory" data-sub="${s}" aria-pressed="${s===sub}">${s}</button>`).join('');
  $('subcategories').dataset.category=currentTab.toLowerCase();
  const slot=currentTab==='Hair'?'hair':(Object.entries(slotNames).find(([,n])=>n===sub)?.[0] as Slot);
  const isDetails=currentTab==='Face'&&sub==='Details';
  const isSkin=currentTab==='Face'&&sub==='Skin',isEyeColor=currentTab==='Face'&&sub==='Eye color',isHairColor=currentTab==='Hair'&&sub==='Color';
  type Card={id:string;name:string;detail:string;config:AtelierConfig;selected:boolean;none?:boolean;asset?:Cosmetic};
  const collectionSelect=$<HTMLSelectElement>('collection-filter'),previousFilter=collectionSelect.value,collections=[...new Set(catalog.manifest.cosmetics.filter(a=>a.slot===slot).map(a=>a.collection))].sort();
  collectionSelect.innerHTML='<option value="all">'+(currentTab==='Hair'?'All lengths':'All collections')+'</option>'+collections.map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');collectionSelect.value=collections.includes(previousFilter)?previousFilter:'all';
  $('hair-filters').hidden=!(currentTab==='Hair'&&sub==='Styles');
  collectionSelect.setAttribute('aria-label',currentTab==='Hair'?'Hair length':'Collection filter');
  const hairTexture=$<HTMLSelectElement>('hair-texture-filter').value,hairFringe=$<HTMLSelectElement>('hair-fringe-filter').value;
  const query=$<HTMLInputElement>('wardrobe-search').value.trim().toLowerCase(),filter=$<HTMLSelectElement>('collection-filter').value;
  $('catalog-tools').hidden=!(currentTab==='Clothes'||currentTab==='Extras'||currentTab==='Hair'&&sub==='Styles');
  const activeWear=(currentTab==='Clothes'||currentTab==='Extras')&&WEAR_SLOTS.includes(slot as WearSlot)?slot as WearSlot:null;
  const worn=activeWear?catalog.manifest.cosmetics.find(a=>a.id===c.equipment[activeWear]):undefined;
  $('wear-color-panel').hidden=!activeWear;
  $('wear-color-panel').innerHTML=activeWear?(worn?.fixedColors?`<p class="skin-note">${esc(worn.name)} · ${esc(worn.color)}. Fixed color.</p>`:worn?`<div class="wear-color-heading"><strong>${esc(worn.name)} · Main color</strong><span>${esc(catalog.wearColors.find(p=>p.id===c.wearColors[activeWear])?.name??'Original')}</span></div><div class="wear-swatches" aria-label="${slotNames[activeWear]} color">${catalog.wearColors.map(p=>`<button class="wear-swatch" data-wear-color="${p.id}" title="${esc(p.name)}" aria-label="${slotNames[activeWear]} color: ${esc(p.name)}" aria-pressed="${c.wearColors[activeWear!]===p.id}"><span style="background:${p.id==='wear.original'?worn.originalColor??p.color:p.color}"></span></button>`).join('')}</div>`:`<p class="skin-note">Choose an item to select its color.</p>`):'';
  if(activeWear&&worn?.layers.some(l=>l.accentMask)){
   $('wear-color-panel').innerHTML+=`<div class="wear-accent-section"><div class="wear-color-heading"><strong>${esc(worn.accentLabel??'Details')}</strong><span>${c.wearAccentColors[activeWear]==='wear.original'?'Auto':esc(catalog.wearColors.find(p=>p.id===c.wearAccentColors[activeWear])?.name??'Auto')}</span></div><div class="wear-swatches" aria-label="${slotNames[activeWear]} detail color">${catalog.wearColors.map(p=>`<button class="wear-swatch" data-accent-color="${p.id}" title="${p.id==='wear.original'?'Auto':esc(p.name)}" aria-label="${slotNames[activeWear]} detail color: ${p.id==='wear.original'?'Auto':esc(p.name)}" aria-pressed="${c.wearAccentColors[activeWear!]===p.id}">${p.id==='wear.original'?'<span class="auto-color">A</span>':`<span style="background:${p.color}"></span>`}</button>`).join('')}</div></div>`;
  }
  document.querySelectorAll<HTMLButtonElement>('[data-accent-color]').forEach(b=>b.onclick=()=>{commit({...c,wearAccentColors:{...c.wearAccentColors,[activeWear!]:b.dataset.accentColor as WearColor}});document.querySelector<HTMLButtonElement>(`[data-accent-color="${b.dataset.accentColor}"]`)?.focus({preventScroll:true});});
  document.querySelectorAll<HTMLButtonElement>('[data-wear-color]').forEach(b=>b.onclick=()=>{commit({...c,wearColors:{...c.wearColors,[activeWear!]:b.dataset.wearColor as WearColor}});document.querySelector<HTMLButtonElement>(`[data-wear-color="${b.dataset.wearColor}"]`)?.focus({preventScroll:true});});
  const displayedColor=(a:Cosmetic)=>a.fixedColors?a.color:WEAR_SLOTS.includes(a.slot as WearSlot)&&c.wearColors[a.slot as WearSlot]!=='wear.original'?(catalog.wearColors.find(p=>p.id===c.wearColors[a.slot as WearSlot])?.name??a.color):['hair','facialHair','brows'].includes(a.slot)&&c.hairColor!=='hair.original'?(catalog.hairColors.find(p=>p.id===c.hairColor)?.name??a.color):a.color;
  const matches=(a:Cosmetic)=>$('catalog-tools').hidden||((!query||[a.name,displayedColor(a),a.collection,...(a.tags??[])].join(' ').toLowerCase().includes(query))&&(filter==='all'||a.collection===filter)&&(currentTab!=='Hair'||(hairTexture==='all'||hairDetails(a).texture===hairTexture)&&(hairFringe==='all'||hairDetails(a).fringe===hairFringe)));
  const cards:Card[]=currentTab==='Looks'?catalog.presets.map(p=>({...p,selected:same(p.config,c)})):isSkin||isEyeColor||isHairColor?[]:catalog.manifest.cosmetics.filter(a=>(isDetails?PERSONAL_SLOTS.includes(a.slot as typeof PERSONAL_SLOTS[number]):a.slot===slot)&&matches(a)).map(a=>({id:a.id,name:a.name,detail:`${displayedColor(a)} · ${a.collection}`,selected:c.equipment[a.slot]===a.id,config:equip(c,a.slot,a.id),asset:a}));
  if(currentTab!=='Looks'&&!isDetails&&!isSkin&&!isEyeColor&&!isHairColor&&slot!=='head'&&($('catalog-tools').hidden||(!query&&filter==='all')))cards.push({id:'none',name:'None',detail:slot==='bottom'?'Neutral underwear':'Keep it simple.',config:equip(c,slot,null),selected:c.equipment[slot]===null,none:true});
  const covered=currentTab==='Clothes'&&sub==='Tops'&&c.equipment.jacket?'jacket':currentTab==='Hair'&&c.equipment.hat?'hat':null;
  $('coverage-note').hidden=!covered;$('coverage-note').innerHTML=covered?`Your ${covered} covers part of this selection. <button id="remove-cover">Remove ${covered}</button>`:'';
  if(covered)$('remove-cover').onclick=()=>commit(equip(c,covered,null));
  $('selection-grid').dataset.kind=isSkin||isEyeColor||isHairColor?'skin':currentTab==='Looks'?'looks':'items';
  $('selection-grid').dataset.zone=currentTab==='Face'?'face':currentTab==='Hair'?'hair':activeWear==='shoes'?'shoes':activeWear==='bottom'?'bottom':activeWear==='top'||activeWear==='jacket'||activeWear==='tie'?'torso':'full';
  const selectedHair=catalog.manifest.cosmetics.find(a=>a.slot==='hair'&&a.id===c.equipment.hair)??catalog.manifest.cosmetics.find(a=>a.slot==='facialHair'&&a.id===c.equipment.facialHair),canColor=!!selectedHair?.layers.some(l=>l.recolor);
  const hairControls=canColor?`<div class="eye-color-grid" aria-label="Hair color">${catalog.hairColors.map(p=>`<button class="eye-color-choice" data-hair-color="${p.id}" aria-label="Hair color: ${esc(p.name)}" aria-pressed="${c.hairColor===p.id}"><span style="background:${p.id==='hair.original'?selectedHair?.originalColor??p.color:p.color}"></span>${esc(p.name)}</button>`).join('')}</div><p class="skin-note">${esc(selectedHair?.name??'Hair')} · 12 colors, one hairstyle.</p>`:`<p class="skin-note">Choose a hairstyle to select its color.</p><button id="use-color-hair" class="button subtle">Choose hairstyle</button>`;
  const previewConfig=(card:Card)=>{let config=card.config;if(isDetails&&card.asset){const equipment={...config.equipment};for(const s of PERSONAL_SLOTS)equipment[s]=s===card.asset.slot?card.asset.id:null;config={...config,equipment};}return card.asset?.slot==='top'?equip(config,'jacket',null):card.asset?.slot==='hair'?equip(config,'hat',null):config;};
  $('selection-grid').innerHTML=isHairColor?hairControls:isEyeColor?`<div class="eye-color-grid" aria-label="Eye color">${catalog.eyeColors.map(e=>`<button class="eye-color-choice" data-eye-color="${e.id}" aria-label="${e.name} eyes" aria-pressed="${c.eyeColor===e.id}"><span style="background:${e.color}"></span>${e.name}</button>`).join('')}</div><p class="skin-note">A subtle iris detail. The same eyes, in six natural colors.</p>`:isSkin?`<div class="skin-grid" aria-label="Skin tone">${catalog.manifest.skins.map(s=>`<button class="skin-swatch" style="background:${s.color}" data-skin="${s.id}" aria-label="Skin tone ${Number(s.id.slice(-2))}" aria-pressed="${s.id===c.skin}"></button>`).join('')}</div><p class="skin-note">12 tones. One shared silhouette.</p>`:cards.map(card=>`<button class="selection-card" data-choice="${card.id}" aria-label="${esc(card.name)}" aria-pressed="${card.selected}"><span class="card-image">${card.none?`<span class="none-symbol">${icon('none')}</span>`:`<img src="${esc(preview(previewConfig(card)))}" width="128" height="128" alt="" loading="lazy">`}<span class="selected-tick">${icon('check')}</span></span><span class="card-label"><span><strong>${esc(card.name)}</strong><small>${esc(card.detail)}</small></span><span aria-hidden="true">↗</span></span></button>`).join('');
  if(!isSkin&&!isEyeColor&&!isHairColor&&!cards.some(c=>!c.none))$('selection-grid').innerHTML='<p class="empty-results">No items match. Try another search or collection.</p>'+$('selection-grid').innerHTML;
  $('item-count').textContent=isHairColor?'12 colors':isEyeColor?'6 colors':isSkin?'12 tones':`${cards.filter(c=>!c.none).length} ${currentTab==='Looks'?'looks':cards.filter(c=>!c.none).length===1?'style':'styles'}`;
  $('category-note').innerHTML=icon('check')+(isDetails?'Personal details can be combined. Tap a selected detail to remove it.':slot==='facialHair'?'Facial hair follows your hair color.':slot==='tie'?'Selecting a tie also equips the white dress shirt.':isSkin?'Skin and ears share the same palette.':'Reference & Imagegen artwork · Separate layers.');
  $('equipped').innerHTML=selected(c).filter(a=>!['eyes','brows','nose','mouth','ears'].includes(a.slot)).map(a=>`<span class="equipped-chip">${esc(a.name)}</span>`).join('');
  if(isHairColor&&!canColor)$('use-color-hair').onclick=()=>{sub='Styles';subByTab.Hair=sub;paint();};
  document.querySelectorAll<HTMLButtonElement>('[data-hair-color]').forEach(b=>b.onclick=()=>{commit({...c,hairColor:b.dataset.hairColor as AtelierConfig['hairColor']});document.querySelector<HTMLButtonElement>(`[data-hair-color="${b.dataset.hairColor}"]`)?.focus({preventScroll:true});});
  $('selection-grid').scrollTop=selectionScroll;
  paintInspector();
  document.querySelectorAll<HTMLButtonElement>('[data-tab]').forEach(b=>{b.onclick=()=>switchTab(b.dataset.tab as Tab);b.onkeydown=e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const i=tabs.indexOf(currentTab);switchTab(e.key==='Home'?tabs[0]:e.key==='End'?tabs[4]:tabs[(i+(e.key==='ArrowRight'?1:4))%5]);};});
  document.querySelectorAll<HTMLButtonElement>('[data-sub]').forEach(b=>b.onclick=()=>{sub=b.dataset.sub!;subByTab[currentTab]=sub;$<HTMLInputElement>('wardrobe-search').value='';$<HTMLSelectElement>('collection-filter').value='all';paint();document.querySelector<HTMLButtonElement>(`[data-sub="${sub}"]`)?.focus({preventScroll:true});});
  document.querySelectorAll<HTMLButtonElement>('[data-choice]').forEach(b=>b.onclick=()=>{const card=cards.find(c=>c.id===b.dataset.choice)!;commit(isDetails&&card.selected&&card.asset?equip(c,card.asset.slot,null):card.config);document.querySelector<HTMLButtonElement>(`[data-choice="${card.id}"]`)?.focus({preventScroll:true});});
  document.querySelectorAll<HTMLButtonElement>('[data-eye-color]').forEach(b=>b.onclick=()=>{commit({...c,eyeColor:b.dataset.eyeColor as AtelierConfig['eyeColor']});document.querySelector<HTMLButtonElement>(`[data-eye-color="${b.dataset.eyeColor}"]`)?.focus({preventScroll:true});});
  document.querySelectorAll<HTMLButtonElement>('[data-skin]').forEach(b=>b.onclick=()=>{commit({...c,skin:b.dataset.skin as AtelierConfig['skin']});document.querySelector<HTMLButtonElement>(`[data-skin="${b.dataset.skin}"]`)?.focus({preventScroll:true});});
}
function paintInspector(){
  const c=history.current,skin=catalog.manifest.skins.find(s=>s.id===c.skin)!;
  $('config-json').textContent=JSON.stringify(c,null,2);
  const items=[{slot:'body',name:'Base silhouette',layers:[skin.layer]},...selected(c)];
  $('layer-list').innerHTML=items.map(a=>`<div class="layer-record"><button class="layer-toggle" data-layer="${a.slot}" aria-pressed="${!hidden.has(a.slot)}" aria-label="Show ${esc(a.name)}"><span>${esc(a.name)}</span>${icon('eye')}</button>${a.layers.map((l,i)=>`<div class="layer-part"><img src="${esc((l.recolor||l.accentMask)?'/api/collection/layer?'+new URLSearchParams({config:JSON.stringify(c),slot:a.slot,index:String(i)}):'/assets/avatar/atelier-r6/'+exactLayerFile(l,c))}" alt="${esc(a.name)} ${esc(l.region.replaceAll('_',' '))}" width="128" height="128" loading="lazy"><span>${esc(l.region.replaceAll('_',' '))}</span><a class="source-link" href="${esc((l.recolor||l.accentMask)?'/api/collection/layer?'+new URLSearchParams({config:JSON.stringify(c),slot:a.slot,index:String(i)}):'/assets/avatar/atelier-r6/'+exactLayerFile(l,c))}" target="_blank" rel="noopener">Open ${esc(l.region.replaceAll('_',' '))} PNG ↗</a><a class="source-link" href="/${esc(l.source)}" target="_blank" rel="noopener">View source artwork ↗</a></div>`).join('')}</div>`).join('');
  document.querySelectorAll<HTMLButtonElement>('[data-layer]').forEach(b=>b.onclick=()=>{const slot=b.dataset.layer!;hidden.has(slot)?hidden.delete(slot):hidden.add(slot);paintInspector();void updatePreview();});
}
async function updatePreview(){
  const ticket=requests.beginRender(),config=history.current,inspected=[...hidden];controller?.abort();controller=new AbortController();
  syncControls();$('render-loading').hidden=false;$('render-loading').textContent='Updating…';$('retry-preview').hidden=true;
  let pendingUrl:string|undefined;
  try{
    const result=await withDeadline(async signal=>{
      const response=await fetch('/api/collection/render?'+new URLSearchParams({hidden:inspected.join(',')}),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(config),signal});
      if(!response.ok)throw new Error(blobUrl?'This avatar could not be rendered. Your last preview is still shown.':'This avatar could not be rendered. Please retry.');
      return{blob:await response.blob(),hash:response.headers.get('x-avatar-hash')??'',warnings:JSON.parse(decodeURIComponent(response.headers.get('x-avatar-warnings')??'%5B%5D')) as {slot:string;requestedId:string;fallbackId:string|null}[]};
    },controller.signal);
    if(!requests.isCurrent(ticket))return;
    pendingUrl=URL.createObjectURL(result.blob);const probe=new Image();probe.src=pendingUrl;await probe.decode();
    if(!requests.isCurrent(ticket))return;
    const image=$<HTMLImageElement>('avatar');image.src=pendingUrl;image.hidden=false;image.dataset.hash=result.hash;
    if(blobUrl)URL.revokeObjectURL(blobUrl);blobUrl=pendingUrl;pendingUrl=undefined;
    $<HTMLAnchorElement>('export').href='/api/collection/snapshot/'+result.hash+'.png';
    $('load-error').hidden=true;$('render-loading').hidden=true;
    $('asset-warning').hidden=!result.warnings.length;
    $('asset-warning').textContent=result.warnings.map(w=>{const name=catalog.manifest.cosmetics.find(c=>c.id===w.requestedId)?.name??w.slot;const fallback=catalog.manifest.cosmetics.find(c=>c.id===w.fallbackId)?.name;return `${name} could not load. ${fallback?'Showing '+fallback+'.':'Temporarily hidden.'}`;}).join(' ');
    $('retry-preview').hidden=!result.warnings.length;
    requests.finishRender(ticket,true);syncControls();
  }catch(e){
    if(!requests.isCurrent(ticket))return;
    requests.finishRender(ticket,false);syncControls();$('load-error').textContent=(e as Error).message;$('load-error').hidden=false;$('render-loading').hidden=true;$('retry-preview').hidden=false;
  }finally{if(pendingUrl)URL.revokeObjectURL(pendingUrl);}
}
function download(blob:Blob,name:string){const a=document.createElement('a'),url=URL.createObjectURL(blob);a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);}
async function save(){
  if(!requests.beginSave())return;syncControls();const snapshot=history.current;
  try{
    const c=await withDeadline(async signal=>{const r=await fetch('/api/collection/validate',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(snapshot),signal});if(!r.ok)throw new Error('This avatar could not be saved.');return await r.json() as AtelierConfig;});
    localStorage.setItem(STORAGE,JSON.stringify(c));lastSaved=canonicalVisualKey(c);paint();
    toast(same(c,history.current)?'Avatar saved on this device.':'Previous selection saved. Your latest changes are still in the draft.');
  }catch(e){toast((e as Error).message);}finally{requests.finishSave();syncControls();}
}
function randomize(scope='all'){
  const pick=<T>(items:T[])=>items[Math.floor(Math.random()*items.length)],c=history.current;
  let next=structuredClone(c);
  for(const slot of Object.keys(c.equipment) as Slot[]){if(slot==='hat'||PERSONAL_SLOTS.includes(slot as typeof PERSONAL_SLOTS[number]))continue;if(scope==='colors'||scope==='hair'&&slot!=='hair'||scope==='outfit'&&!['top','jacket','bottom','shoes','hat','glasses','earrings','tie'].includes(slot))continue;const items=catalog.manifest.cosmetics.filter(a=>a.slot===slot&&(!a.compatibleTops||a.compatibleTops.includes(next.equipment.top??'')));if(!items.length){next=equip(next,slot,null);continue;}next=equip(next,slot,['hat','glasses','jacket','earrings','tie','facialHair'].includes(slot)&&Math.random()<.55?null:pick(items).id);}
  if((scope==='all'||scope==='colors')&&next.equipment.hair!==null)next.hairColor=pick(catalog.hairColors).id;
  if(scope==='all'||scope==='colors'||scope==='outfit')for(const slot of WEAR_SLOTS)if(next.equipment[slot]){next.wearColors[slot]=pick(catalog.wearColors).id;next.wearAccentColors[slot]=catalog.manifest.cosmetics.find(c=>c.id===next.equipment[slot])?.layers.some(l=>l.accentMask)?pick(catalog.wearColors).id:'wear.original';}
  if(scope==='all'||scope==='colors'){next.skin=pick(catalog.manifest.skins).id as AtelierConfig['skin'];next.eyeColor=pick(catalog.eyeColors).id;}commit(next);
}
async function boot(){try{
  const r=await withDeadline(signal=>fetch('/api/collection/catalog',{signal}));if(!r.ok)throw new Error('The wardrobe is unavailable. Please reload.');catalog=await r.json();let initial=catalog.defaults;
  try{const saved=localStorage.getItem(STORAGE);if(saved){const check=await withDeadline(signal=>fetch('/api/collection/validate',{method:'POST',headers:{'content-type':'application/json'},body:saved,signal}));if(check.ok){initial=await check.json();lastSaved=canonicalVisualKey(initial);}else toast('Your old save has been preserved. This collection starts with a fresh look.');}else if(localStorage.getItem('diff-avatar-exact-r5')||localStorage.getItem('diff-avatar-atelier-r3')||localStorage.getItem('diff-avatar-atelier-r2')||localStorage.getItem('diff-avatar-studio-r1'))toast('New artwork collection loaded. Your previous avatar save is still preserved.');}catch{toast('Local storage is unavailable. PNG export still works.');}
  $('collection-filter').innerHTML='<option value="all">All collections</option>'+[...new Set(catalog.manifest.cosmetics.map(a=>a.collection))].sort().map(v=>`<option value="${esc(v)}">${esc(v)}</option>`).join('');
  $('hair-texture-filter').innerHTML='<option value="all">All textures</option>'+Object.entries(HAIR_TEXTURES).map(([id,name])=>`<option value="${id}">${name}</option>`).join('');$('hair-fringe-filter').innerHTML='<option value="all">All fringes / parts</option>'+Object.entries(HAIR_FRINGES).map(([id,name])=>`<option value="${id}">${name}</option>`).join('');$('hair-texture-filter').onchange=()=>paint();$('hair-fringe-filter').onchange=()=>paint();
  $('wardrobe-search').oninput=()=>paint();$('collection-filter').onchange=()=>paint();
  try{const draft=sessionStorage.getItem(DRAFT_STORAGE);if(draft){const r=await withDeadline(signal=>fetch('/api/collection/validate',{method:'POST',body:draft,signal}));if(r.ok)initial=await r.json();}}catch{}
  history=new AtelierHistory(withoutHeadwear(initial));const selfie=initSelfie(()=>history.current,catalog.manifest,c=>{commit(c);switchTab('Face');toast('Face applied. Undo is available.');});if(location.pathname==='/dev/selfie-lab')void import('../selfie/lab.js').then(m=>m.bindSelfieLab(selfie));paint();await updatePreview();
  $('undo').onclick=()=>{history.undo();hidden.clear();rememberDraft();paint();void updatePreview();};$('redo').onclick=()=>{history.redo();hidden.clear();rememberDraft();paint();void updatePreview();};$('reset').onclick=()=>{commit(catalog.defaults);toast('Original look restored. Undo is available.');};$('randomize').onclick=()=>randomize($<HTMLSelectElement>('random-scope').value);
  $('retry-preview').onclick=()=>{paint();void updatePreview();};
  $('save').onclick=()=>void save();$('export').onclick=e=>{if($('export').getAttribute('aria-disabled')==='true')e.preventDefault();};$('export-config').onclick=()=>download(new Blob([JSON.stringify(history.current,null,2)],{type:'application/json'}),'diff-avatar-atelier-config.json');
  $('inspect').onclick=()=>{const panel=$('inspector');panel.hidden=!panel.hidden;$('inspect').setAttribute('aria-expanded',String(!panel.hidden));if(panel.hidden){hidden.clear();$<HTMLInputElement>('show-grid').checked=false;$('grid-overlay').hidden=true;paintInspector();void updatePreview();}};
  $('restore-layers').onclick=()=>{hidden.clear();paintInspector();void updatePreview();};$<HTMLInputElement>('show-grid').onchange=e=>$('grid-overlay').hidden=!(e.target as HTMLInputElement).checked;
  document.querySelectorAll<HTMLButtonElement>('[data-bg]').forEach(b=>b.onclick=()=>{$('stage').dataset.background=b.dataset.bg;document.querySelectorAll('[data-bg]').forEach(el=>el.setAttribute('aria-pressed',String(el===b)));});
  const dialog=$<HTMLDialogElement>('art-dialog');$('originals').onclick=()=>{const sources={...catalog.manifest.sources,...Object.fromEntries(Object.entries(catalog.legacySources).map(([k,v])=>['Previous · '+k,v]))};$('art-grid').innerHTML=Object.entries(sources).map(([k,p])=>`<figure class="art-card"><img src="/${esc(p)}" alt="${esc(k)} original artwork" loading="lazy"><figcaption>${esc(k.replace(/-/g,' '))}</figcaption><a href="/${esc(p)}" target="_blank" rel="noopener">Open original ↗</a></figure>`).join('');dialog.showModal();};$('close-dialog').onclick=()=>dialog.close();dialog.addEventListener('click',e=>{if(e.target===dialog){const b=dialog.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)dialog.close();}});
  document.addEventListener('keydown',e=>{if(!(e.metaKey||e.ctrlKey)||e.key.toLowerCase()!=='z'||(e.target as HTMLElement).matches('input,textarea,select'))return;e.preventDefault();e.shiftKey?history.redo():history.undo();hidden.clear();rememberDraft();paint();void updatePreview();});
}catch(e){$('load-error').textContent=(e as Error).message;$('load-error').hidden=false;$('render-loading').hidden=true;$('retry-preview').hidden=false;$('retry-preview').onclick=()=>location.reload();}}
void boot();
