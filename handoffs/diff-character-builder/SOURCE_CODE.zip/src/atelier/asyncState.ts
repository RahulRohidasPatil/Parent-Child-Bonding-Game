/** Shared control state: an old Save completion cannot unlock a newer, unfinished render. */
export class EditorAsyncState {
 private ticket=0;
 private renderState:'idle'|'loading'|'ready'|'failed'='idle';
 private saving=false;
 beginRender(){this.renderState='loading';return ++this.ticket;}
 isCurrent(ticket:number){return ticket===this.ticket;}
 finishRender(ticket:number,ok:boolean){if(!this.isCurrent(ticket))return false;this.renderState=ok?'ready':'failed';return true;}
 beginSave(){if(!this.canSave)return false;this.saving=true;return true;}
 finishSave(){this.saving=false;}
 get canExport(){return this.renderState==='ready';}
 get canSave(){return this.canExport&&!this.saving;}
}

export async function withDeadline<T>(operation:(signal:AbortSignal)=>Promise<T>,parent?:AbortSignal,timeoutMs=15000){
 const controller=new AbortController();let timedOut=false;
 const abort=()=>controller.abort();if(parent?.aborted)abort();else parent?.addEventListener('abort',abort,{once:true});
 const timer=setTimeout(()=>{timedOut=true;abort();},timeoutMs);
 try{return await operation(controller.signal);}catch(error){if(timedOut)throw new Error('The preview server took too long. Please retry.');throw error;}
 finally{clearTimeout(timer);parent?.removeEventListener('abort',abort);}
}
