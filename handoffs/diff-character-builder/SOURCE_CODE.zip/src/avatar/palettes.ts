import type { Rgba } from './types.js';

export interface SkinPalette {
  highlight: Rgba;
  base: Rgba;
  shadow: Rgba;
  outlineShadow: Rgba;
}

const rgba = (hex: string): Rgba => [Number.parseInt(hex.slice(1, 3), 16), Number.parseInt(hex.slice(3, 5), 16), Number.parseInt(hex.slice(5, 7), 16), 255];
const skin = (highlight: string, base: string, shadow: string, outlineShadow: string): SkinPalette => ({ highlight: rgba(highlight), base: rgba(base), shadow: rgba(shadow), outlineShadow: rgba(outlineShadow) });

export const SKIN_PALETTES: Readonly<Record<string, SkinPalette>> = Object.freeze({
  skin_01: skin('#FFE7D7', '#F4D1BB', '#D9A78C', '#9A6654'),
  skin_02: skin('#FADCC8', '#EBC2A7', '#CB9477', '#8E5C49'),
  skin_03: skin('#F0CBAF', '#DCAE8E', '#B77E61', '#784B3B'),
  skin_04: skin('#E7B996', '#C99572', '#A46A4F', '#6D4032'),
  skin_05: skin('#D6A47E', '#B77F5B', '#915A40', '#5D3529'),
  skin_06: skin('#C38A64', '#A56949', '#7D4633', '#4E2A21'),
  skin_07: skin('#AC7252', '#8E573D', '#683724', '#402219'),
  skin_08: skin('#945E44', '#774630', '#552B20', '#341A14'),
  skin_09: skin('#7B4B38', '#603729', '#432118', '#29130F'),
  skin_10: skin('#623A2C', '#4C2B21', '#351A15', '#200F0C'),
  skin_11: skin('#4D3024', '#3A221A', '#271510', '#170C09'),
  skin_12: skin('#3A251D', '#2A1914', '#1C0F0C', '#100806'),
});

export interface MaterialPalette { outline: Rgba; shadow: Rgba; base: Rgba; highlight: Rgba; accent?: Rgba; }
const material = (outline: string, shadow: string, base: string, highlight: string, accent?: string): MaterialPalette => ({ outline: rgba(outline), shadow: rgba(shadow), base: rgba(base), highlight: rgba(highlight), accent: accent ? rgba(accent) : undefined });

export const MATERIALS: Readonly<Record<string, MaterialPalette>> = Object.freeze({
  dark_brown: material('#17100D', '#2C1C16', '#493127', '#6B4B3C'),
  black: material('#0D1112', '#171C1E', '#252B2E', '#41494D'),
  graphite: material('#1B2225', '#303A3E', '#566267', '#89969A'),
  cream: material('#514B3F', '#B9AA8D', '#E9DCC0', '#FFF5DE'),
  white: material('#363E40', '#AEB9BC', '#E9EEEE', '#FFFFFF'),
  neutral_underwear: material('#4A5052', '#9DA7AA', '#C9D0D2', '#E7ECEC'),
  diff_track: material('#0D1112', '#171C1E', '#252B2E', '#41494D', '#39FF7A'),
  glasses_graphite: material('#1A2023', '#303A3E', '#566267', '#879397'),
  eye_dark: material('#151312', '#211B18', '#342620', '#FFFFFF'),
  mouth: material('#4B2726', '#713936', '#985451', '#C97970'),
});

export function skinPalette(id: string): SkinPalette { const value = SKIN_PALETTES[id]; if (!value) throw new Error(`Unknown skin palette ${id}`); return value; }
export function materialPalette(id: string): MaterialPalette { const value = MATERIALS[id]; if (!value) throw new Error(`Unknown material palette ${id}`); return value; }
