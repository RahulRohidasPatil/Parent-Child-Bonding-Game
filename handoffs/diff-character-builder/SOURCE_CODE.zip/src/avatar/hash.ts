import { createHash } from 'node:crypto';
import type { AvatarConfig } from './types.js';
import { validateAvatarConfig } from './schema.js';

function stable(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(stable).join(',')}]`;
  if (value && typeof value === 'object') { const object = value as Record<string, unknown>; return `{${Object.keys(object).sort().map((key) => `${JSON.stringify(key)}:${stable(object[key])}`).join(',')}}`; }
  return JSON.stringify(value);
}

export function canonicalConfig(config: AvatarConfig): string { return stable(validateAvatarConfig(config)); }
export function avatarHash(config: AvatarConfig): string { return createHash('sha256').update(canonicalConfig(config)).digest('hex').slice(0, 16); }
