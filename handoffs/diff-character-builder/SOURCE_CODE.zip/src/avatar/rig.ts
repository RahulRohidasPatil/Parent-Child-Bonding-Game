import type { LayerSlot } from './types.js';

export const RIG_ID = 'front_idle_v1' as const;
export const CANVAS = 128 as const;
export const LOGICAL_CANVAS = 64 as const;
export const SCALE = 2 as const;

export const LANDMARKS = Object.freeze({
  centerX: 64,
  headTop: 4,
  hairSafeTop: 2,
  headBottom: 38,
  browY: 24,
  eyeY: 30,
  mouthY: 39,
  neckTop: 36,
  neckBottom: 42,
  shoulderY: 40,
  chestY: 54,
  waistY: 73,
  hipY: 77,
  kneeY: 100,
  ankleY: 115,
  footBaseline: 124,
});

export const LAYER_ORDER: Readonly<Record<LayerSlot, number>> = Object.freeze({
  hair_back: 10,
  body_skin: 20,
  bottoms: 30,
  shoes: 40,
  top: 50,
  outerwear: 55,
  eyes: 60,
  brows: 62,
  mouth: 64,
  hair_front: 70,
  facial_hair: 75,
  earrings: 80,
  glasses: 82,
  face_accessory: 84,
  headwear: 90,
  neck_accessory: 100,
  wrist_accessory: 105,
  body_accessory: 110,
});

export interface SlotMask {
  id: string;
  slot: LayerSlot;
  containsLogical(x: number, y: number): boolean;
}

const rect = (left: number, top: number, right: number, bottom: number) => (x: number, y: number) => x >= left && x <= right && y >= top && y <= bottom;
const union = (...parts: Array<(x: number, y: number) => boolean>) => (x: number, y: number) => parts.some((part) => part(x, y));

export const SLOT_MASKS: Readonly<Record<LayerSlot, SlotMask>> = Object.freeze({
  hair_back: { id: 'mask_hair_back_v1', slot: 'hair_back', containsLogical: rect(19, 1, 45, 42) },
  body_skin: { id: 'mask_body_skin_v1', slot: 'body_skin', containsLogical: rect(19, 1, 45, 62) },
  bottoms: { id: 'mask_bottoms_v1', slot: 'bottoms', containsLogical: rect(22, 35, 42, 59) },
  shoes: { id: 'mask_shoes_v1', slot: 'shoes', containsLogical: rect(21, 55, 43, 63) },
  top: { id: 'mask_top_v1', slot: 'top', containsLogical: rect(19, 17, 45, 41) },
  outerwear: { id: 'mask_outerwear_v1', slot: 'outerwear', containsLogical: rect(18, 17, 46, 43) },
  eyes: { id: 'mask_eyes_v1', slot: 'eyes', containsLogical: rect(25, 11, 39, 18) },
  brows: { id: 'mask_brows_v1', slot: 'brows', containsLogical: rect(22, 10, 42, 15) },
  mouth: { id: 'mask_mouth_v1', slot: 'mouth', containsLogical: rect(27, 17, 37, 22) },
  hair_front: { id: 'mask_hair_front_v1', slot: 'hair_front', containsLogical: rect(19, 1, 45, 42) },
  facial_hair: { id: 'mask_facial_hair_v1', slot: 'facial_hair', containsLogical: rect(23, 16, 41, 25) },
  earrings: { id: 'mask_earrings_v1', slot: 'earrings', containsLogical: union(rect(18, 14, 23, 22), rect(41, 14, 46, 22)) },
  glasses: { id: 'mask_glasses_v1', slot: 'glasses', containsLogical: rect(24, 10, 40, 21) },
  face_accessory: { id: 'mask_face_accessory_v1', slot: 'face_accessory', containsLogical: rect(21, 14, 43, 23) },
  headwear: { id: 'mask_headwear_v1', slot: 'headwear', containsLogical: rect(19, 0, 45, 16) },
  neck_accessory: { id: 'mask_neck_accessory_v1', slot: 'neck_accessory', containsLogical: rect(23, 22, 41, 34) },
  wrist_accessory: { id: 'mask_wrist_accessory_v1', slot: 'wrist_accessory', containsLogical: union(rect(15, 37, 23, 47), rect(41, 37, 49, 47)) },
  body_accessory: { id: 'mask_body_accessory_v1', slot: 'body_accessory', containsLogical: rect(17, 23, 47, 50) },
});

export const HAIR_VISIBILITY_MASKS = Object.freeze({
  hair_mask_cap_v1: (x: number, y: number) => y <= 13 && x >= 21 && x <= 43,
  hair_mask_beanie_v1: (x: number, y: number) => y <= 15 && x >= 20 && x <= 44,
});
