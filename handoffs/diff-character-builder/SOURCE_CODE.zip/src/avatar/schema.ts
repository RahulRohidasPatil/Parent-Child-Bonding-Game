import { z } from 'zod';
import type { AvatarConfig } from './types.js';
import { HAIR_STYLES, assetById } from './manifest.js';
import { SKIN_PALETTES } from './palettes.js';

const selection = z.object({ id: z.string(), color: z.string() }).strict();

export const AvatarConfigSchema = z.object({
  version: z.literal(1),
  rig: z.literal('front_idle_v1'),
  skin: z.string(),
  eyes: z.literal('eyes.neutral'),
  brows: z.literal('brows.straight'),
  mouth: z.literal('mouth.small_smile'),
  hair: z.enum(['hair.fluffy_middle', 'hair.long_wavy']),
  hairColor: z.literal('dark_brown'),
  facialHair: z.null(),
  top: selection,
  outerwear: selection.nullable(),
  bottom: selection,
  shoes: selection,
  headwear: selection.nullable(),
  glasses: selection.nullable(),
  accessories: z.array(z.string()).length(0),
}).strict();

function validateSelection(value: { id: string; color: string }, slot: string): void {
  const asset = assetById(value.id);
  if (asset.slot !== slot) throw new Error(`${value.id} belongs to ${asset.slot}, not ${slot}`);
  if (!asset.colors.includes(value.color)) throw new Error(`${value.id} does not support ${value.color}`);
}

export function validateAvatarConfig(input: unknown): AvatarConfig {
  const value = AvatarConfigSchema.parse(input) as AvatarConfig;
  if (!SKIN_PALETTES[value.skin]) throw new Error(`Unknown skin ${value.skin}`);
  if (!HAIR_STYLES[value.hair as keyof typeof HAIR_STYLES]) throw new Error(`Unknown hair ${value.hair}`);
  validateSelection(value.top, 'top');
  if (value.outerwear) validateSelection(value.outerwear, 'outerwear');
  validateSelection(value.bottom, 'bottoms');
  validateSelection(value.shoes, 'shoes');
  if (value.headwear) validateSelection(value.headwear, 'headwear');
  if (value.glasses) validateSelection(value.glasses, 'glasses');
  return value;
}

export const CHECKPOINT_BASE: AvatarConfig = Object.freeze({
  version: 1,
  rig: 'front_idle_v1',
  skin: 'skin_04',
  eyes: 'eyes.neutral',
  brows: 'brows.straight',
  mouth: 'mouth.small_smile',
  hair: 'hair.fluffy_middle',
  hairColor: 'dark_brown',
  facialHair: null,
  top: { id: 'top.quarter_zip_fleece', color: 'cream' },
  outerwear: null,
  bottom: { id: 'bottom.straight_trousers', color: 'black' },
  shoes: { id: 'shoe.minimal_low', color: 'white' },
  headwear: null,
  glasses: null,
  accessories: [],
});

export const CHECKPOINT_VARIANTS: Readonly<Record<string, AvatarConfig>> = Object.freeze({
  base: CHECKPOINT_BASE,
  variant_a_cap: validateAvatarConfig({ ...CHECKPOINT_BASE, headwear: { id: 'headwear.cap_forward', color: 'black' } }),
  variant_b_beanie: validateAvatarConfig({ ...CHECKPOINT_BASE, headwear: { id: 'headwear.beanie_folded', color: 'black' } }),
  variant_c_track_jacket: validateAvatarConfig({ ...CHECKPOINT_BASE, outerwear: { id: 'outer.track_classic', color: 'diff_track' } }),
  variant_d_long_wavy: validateAvatarConfig({ ...CHECKPOINT_BASE, hair: 'hair.long_wavy' }),
  variant_e_glasses: validateAvatarConfig({ ...CHECKPOINT_BASE, glasses: { id: 'glasses.round', color: 'glasses_graphite' } }),
  variant_f_track_pants: validateAvatarConfig({ ...CHECKPOINT_BASE, bottom: { id: 'bottom.track_tapered', color: 'black' } }),
});
