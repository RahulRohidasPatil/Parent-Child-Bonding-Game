import type { AssetDefinition, AvatarConfig, RenderOptions } from './types.js';
import { assetById, assetFile, HAIR_STYLES } from './manifest.js';
import { HAIR_VISIBILITY_MASKS } from './rig.js';
import { Raster, readPng } from './raster.js';
import { validateAvatarConfig } from './schema.js';
import { avatarHash } from './hash.js';

interface LayerRequest { asset: AssetDefinition; color: string; }
const cache = new Map<string, Promise<Raster>>();

function request(id: string, color: string): LayerRequest { return { asset: assetById(id), color }; }

function layers(config: AvatarConfig): LayerRequest[] {
  const hair = HAIR_STYLES[config.hair as keyof typeof HAIR_STYLES];
  const list: LayerRequest[] = [
    request('body.skin', config.skin),
    request(config.bottom.id, config.bottom.color),
    request(config.shoes.id, config.shoes.color),
    request(config.top.id, config.top.color),
  ];
  if (hair.back) list.unshift(request(hair.back, config.hairColor));
  if (config.outerwear) list.push(request(config.outerwear.id, config.outerwear.color));
  list.push(request(config.eyes, 'fixed'), request(config.brows, 'fixed'), request(config.mouth, 'fixed'), request(hair.front, config.hairColor));
  if (config.glasses) list.push(request(config.glasses.id, config.glasses.color));
  if (config.headwear) list.push(request(config.headwear.id, config.headwear.color));
  return list.sort((a, b) => a.asset.z - b.asset.z);
}

async function load(layer: LayerRequest): Promise<Raster> {
  const path = assetFile(layer.asset, layer.color);
  let image = cache.get(path);
  if (!image) { image = readPng(path); cache.set(path, image); }
  return image;
}

function applyGrid(output: Raster): void {
  const color: [number, number, number, number] = [57, 255, 122, 255];
  for (let x = 0; x < output.width; x += 8) output.line(x, 0, x, output.height - 1, color);
  for (let y = 0; y < output.height; y += 8) output.line(0, y, output.width - 1, y, color);
}

export async function renderAvatar(input: AvatarConfig, options: RenderOptions = {}): Promise<{ raster: Raster; hash: string }> {
  const config = validateAvatarConfig(input);
  const output = new Raster(128, 128);
  const headwear = config.headwear ? assetById(config.headwear.id) : null;
  const hairMask = headwear?.hairMask ? HAIR_VISIBILITY_MASKS[headwear.hairMask] : undefined;
  for (const layer of layers(config)) {
    const image = await load(layer);
    const hide = layer.asset.slot === 'hair_front' && hairMask ? (x: number, y: number) => hairMask(Math.floor(x / 2), Math.floor(y / 2)) : undefined;
    output.blit(image, hide);
  }
  if (options.grid) applyGrid(output);
  return { raster: output, hash: avatarHash(config) };
}

export function clearRendererCache(): void { cache.clear(); }
