import { resolve } from 'node:path';
import { readPng, Raster } from './raster.js';
import { SKIN_PALETTES } from './palettes.js';

export const IMAGEGEN_SOURCES = Object.freeze({
  body: 'references/avatar-v1/master-body-imagegen.png',
  base: 'references/avatar-v1/checkpoint-imagegen/01_checkpoint_base.png',
  cap: 'references/avatar-v1/checkpoint-imagegen/02_variant_a_cap.png',
  beanie: 'references/avatar-v1/checkpoint-imagegen/03_variant_b_beanie.png',
  trackJacket: 'references/avatar-v1/checkpoint-imagegen/04_variant_c_track_jacket.png',
  longWavy: 'references/avatar-v1/checkpoint-imagegen/05_variant_d_long_wavy.png',
  glasses: 'references/avatar-v1/checkpoint-imagegen/06_variant_e_glasses.png',
  trackPants: 'references/avatar-v1/checkpoint-imagegen/07_variant_f_track_pants.png',
});

function alphaBounds(source: Raster): { left: number; top: number; right: number; bottom: number; width: number; height: number } {
  let left = source.width; let top = source.height; let right = 0; let bottom = 0;
  for (let y = 0; y < source.height; y += 1) for (let x = 0; x < source.width; x += 1) if (source.pixel(x, y)[3] >= 32) {
    left = Math.min(left, x); top = Math.min(top, y); right = Math.max(right, x); bottom = Math.max(bottom, y);
  }
  return { left, top, right, bottom, width: right - left + 1, height: bottom - top + 1 };
}

function sampleBinary(source: Raster, x: number, y: number) {
  const pixel = source.pixel(Math.max(0, Math.min(source.width - 1, Math.round(x))), Math.max(0, Math.min(source.height - 1, Math.round(y))));
  return pixel[3] >= 128 ? [pixel[0], pixel[1], pixel[2], 255] as const : [0, 0, 0, 0] as const;
}

/**
 * Normalizes the actual Imagegen canvas into the locked 128×128 coordinate system.
 * Checkpoint edits share the base image's proportional frame; the body source is
 * fitted once to that same target box. No sprite geometry is redrawn.
 */
export async function normalizeImagegenSource(sourceName: keyof typeof IMAGEGEN_SOURCES): Promise<Raster> {
  const source = await readPng(resolve(process.cwd(), IMAGEGEN_SOURCES[sourceName]));
  const output = new Raster(128, 128);
  const targetTop = 4;
  const targetHeight = 120;
  let sourceCenterX: number;
  let sourceTop: number;
  let sourceHeight: number;
  if (sourceName === 'body') {
    const bounds = alphaBounds(source);
    sourceCenterX = (bounds.left + bounds.right) / 2;
    sourceTop = bounds.top;
    sourceHeight = bounds.height;
  } else {
    sourceCenterX = source.width * (489.5 / 981);
    sourceTop = source.height * (202 / 1602);
    sourceHeight = source.height * (1176 / 1602);
  }
  const scale = targetHeight / sourceHeight;
  for (let y = 0; y < 128; y += 1) for (let x = 0; x < 128; x += 1) {
    const sx = sourceCenterX + (x - 64) / scale;
    const sy = sourceTop + (y - targetTop) / scale;
    output.set(x, y, sampleBinary(source, sx, sy));
  }
  return output;
}

export function isSkinLike([r, g, b, a]: readonly number[]): boolean {
  return a > 0 && r > 85 && r > g * 1.08 && g > b * 1.04;
}

export function isBrownHair([r, g, b, a]: readonly number[]): boolean {
  if (!a) return false;
  return r >= g * 1.05 && g >= b * 1.02 && r < 150 && b < 105;
}

export function isNeutralDark([r, g, b, a]: readonly number[]): boolean {
  return a > 0 && Math.max(r, g, b) - Math.min(r, g, b) < 28 && (r + g + b) / 3 < 115;
}

const within = (x: number, y: number, left: number, top: number, right: number, bottom: number) => x >= left && x <= right && y >= top && y <= bottom;
const differs = (a: readonly number[], b: readonly number[]) => Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]) + Math.abs(a[2] - b[2]) + Math.abs(a[3] - b[3]) > 42;
const isGreen = ([r, g, b, a]: readonly number[]) => a > 0 && g > r * 1.08 && g > b * 1.08;

function select(source: Raster, predicate: (pixel: readonly number[], x: number, y: number) => boolean): Raster {
  const output = new Raster(128, 128);
  for (let y = 0; y < 128; y += 1) for (let x = 0; x < 128; x += 1) { const pixel = source.pixel(x, y); if (predicate(pixel, x, y)) output.set(x, y, pixel); }
  return output;
}

function recolorBody(source: Raster, skinId: string): Raster {
  const palette = SKIN_PALETTES[skinId];
  if (!palette) throw new Error(`Unknown skin palette ${skinId}`);
  const output = new Raster(128, 128);
  for (let y = 0; y < 128; y += 1) for (let x = 0; x < 128; x += 1) {
    const pixel = source.pixel(x, y);
    if (!isSkinLike(pixel)) { output.set(x, y, pixel); continue; }
    const lightness = (pixel[0] + pixel[1] + pixel[2]) / 3;
    output.set(x, y, lightness > 205 ? palette.highlight : lightness > 170 ? palette.base : lightness > 125 ? palette.shadow : palette.outlineShadow);
  }
  return output;
}

async function differenceOverlay(sourceName: keyof typeof IMAGEGEN_SOURCES, region: (x: number, y: number) => boolean, filter?: (pixel: readonly number[], x: number, y: number) => boolean): Promise<Raster> {
  const [variant, base] = await Promise.all([normalizeImagegenSource(sourceName), normalizeImagegenSource('base')]);
  return select(variant, (pixel, x, y) => pixel[3] > 0 && region(x, y) && differs(pixel, base.pixel(x, y)) && (!filter || filter(pixel, x, y)));
}

/** Creates a production layer using only pixels sampled from Imagegen source PNGs. */
export async function createImagegenAsset(id: string, color: string): Promise<Raster> {
  if (id === 'body.skin') return recolorBody(await normalizeImagegenSource('body'), color);
  const base = await normalizeImagegenSource('base');
  if (id === 'eyes.neutral') return select(base, (pixel, x, y) => within(x, y, 53, 25, 75, 34) && !isSkinLike(pixel));
  if (id === 'brows.straight') return select(base, (pixel, x, y) => within(x, y, 52, 21, 76, 27) && isBrownHair(pixel));
  if (id === 'mouth.small_smile') return select(base, (pixel, x, y) => within(x, y, 58, 35, 70, 42) && !isSkinLike(pixel));
  if (id === 'hair.fluffy_middle.front') return select(base, (pixel, x, y) => isBrownHair(pixel) && y <= 39 && (y <= 22 || x <= 52 || x >= 76));
  if (id === 'top.quarter_zip_fleece') return select(base, (pixel, x, y) => within(x, y, 41, 37, 87, 80) && !isSkinLike(pixel));
  if (id === 'bottom.straight_trousers') return select(base, (pixel, x, y) => within(x, y, 47, 71, 81, 116) && pixel[3] > 0 && !isSkinLike(pixel));
  if (id === 'shoe.minimal_low') return select(base, (pixel, x, y) => within(x, y, 44, 112, 84, 125) && pixel[3] > 0 && !isSkinLike(pixel));
  if (id === 'headwear.cap_forward') return differenceOverlay('cap', (x, y) => within(x, y, 42, 1, 86, 30), (pixel) => isNeutralDark(pixel));
  if (id === 'headwear.beanie_folded') return differenceOverlay('beanie', (x, y) => within(x, y, 41, 0, 87, 31), (pixel) => isNeutralDark(pixel));
  if (id === 'outer.track_classic') return differenceOverlay('trackJacket', (x, y) => within(x, y, 39, 36, 89, 83), (pixel) => isNeutralDark(pixel) || isGreen(pixel));
  if (id === 'glasses.round') return differenceOverlay('glasses', (x, y) => within(x, y, 49, 21, 79, 40), (pixel) => isNeutralDark(pixel));
  if (id === 'bottom.track_tapered') {
    const source = await normalizeImagegenSource('trackPants');
    return select(source, (pixel, x, y) => within(x, y, 47, 70, 81, 117) && pixel[3] > 0 && !isSkinLike(pixel));
  }
  if (id === 'hair.long_wavy.back' || id === 'hair.long_wavy.front') {
    const source = await normalizeImagegenSource('longWavy');
    const back = id.endsWith('.back');
    return select(source, (pixel, x, y) => {
      if (!isBrownHair(pixel) || y > 82) return false;
      const isBackRegion = y >= 24 && (x <= 49 || x >= 79);
      return back ? isBackRegion : !isBackRegion;
    });
  }
  throw new Error(`No Imagegen source extraction for ${id}`);
}
