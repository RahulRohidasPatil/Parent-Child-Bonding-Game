import { PNG } from 'pngjs';
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { dirname } from 'node:path';
import type { Rgba } from './types.js';

export class Raster {
  readonly data: Uint8Array;
  constructor(readonly width: number, readonly height: number) { this.data = new Uint8Array(width * height * 4); }
  index(x: number, y: number): number { return (y * this.width + x) * 4; }
  inside(x: number, y: number): boolean { return x >= 0 && y >= 0 && x < this.width && y < this.height; }
  pixel(x: number, y: number): Rgba { if (!this.inside(x, y)) return [0, 0, 0, 0]; const i = this.index(x, y); return [this.data[i], this.data[i + 1], this.data[i + 2], this.data[i + 3]]; }
  set(x: number, y: number, color: Rgba): void { if (this.inside(x, y)) this.data.set(color, this.index(x, y)); }
  rect(x: number, y: number, width: number, height: number, color: Rgba): void { for (let yy = y; yy < y + height; yy += 1) for (let xx = x; xx < x + width; xx += 1) this.set(xx, yy, color); }
  clearRect(x: number, y: number, width: number, height: number): void { this.rect(x, y, width, height, [0, 0, 0, 0]); }
  line(x0: number, y0: number, x1: number, y1: number, color: Rgba): void { let x = x0; let y = y0; const dx = Math.abs(x1 - x0); const sx = x0 < x1 ? 1 : -1; const dy = -Math.abs(y1 - y0); const sy = y0 < y1 ? 1 : -1; let error = dx + dy; while (true) { this.set(x, y, color); if (x === x1 && y === y1) break; const e2 = error * 2; if (e2 >= dy) { error += dy; x += sx; } if (e2 <= dx) { error += dx; y += sy; } } }
  polygon(points: Array<[number, number]>, color: Rgba): void { const minX = Math.min(...points.map((p) => p[0])); const maxX = Math.max(...points.map((p) => p[0])); const minY = Math.min(...points.map((p) => p[1])); const maxY = Math.max(...points.map((p) => p[1])); for (let y = minY; y <= maxY; y += 1) for (let x = minX; x <= maxX; x += 1) { let inside = false; for (let i = 0, j = points.length - 1; i < points.length; j = i++) { const [xi, yi] = points[i]; const [xj, yj] = points[j]; if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside; } if (inside) this.set(x, y, color); } }
  ellipse(cx: number, cy: number, rx: number, ry: number, color: Rgba): void { for (let y = cy - ry; y <= cy + ry; y += 1) for (let x = cx - rx; x <= cx + rx; x += 1) if (((x - cx) ** 2) / (rx ** 2) + ((y - cy) ** 2) / (ry ** 2) <= 1) this.set(x, y, color); }
  blit(source: Raster, hide?: (x: number, y: number) => boolean): void { for (let y = 0; y < source.height; y += 1) for (let x = 0; x < source.width; x += 1) { if (hide?.(x, y)) continue; const pixel = source.pixel(x, y); if (pixel[3] === 255) this.set(x, y, pixel); } }
  upscale(scale: number): Raster { const output = new Raster(this.width * scale, this.height * scale); for (let y = 0; y < output.height; y += 1) for (let x = 0; x < output.width; x += 1) output.set(x, y, this.pixel(Math.floor(x / scale), Math.floor(y / scale))); return output; }
  resizeNearest(width: number, height: number): Raster { const output = new Raster(width, height); for (let y = 0; y < height; y += 1) for (let x = 0; x < width; x += 1) output.set(x, y, this.pixel(Math.floor(x * this.width / width), Math.floor(y * this.height / height))); return output; }
  partialAlphaPixels(): number { let count = 0; for (let i = 3; i < this.data.length; i += 4) if (this.data[i] !== 0 && this.data[i] !== 255) count += 1; return count; }
}

export function encodePng(raster: Raster): Buffer { const png = new PNG({ width: raster.width, height: raster.height, colorType: 6, inputColorType: 6, inputHasAlpha: true }); png.data = Buffer.from(raster.data); return PNG.sync.write(png, { colorType: 6, inputColorType: 6, inputHasAlpha: true }); }
export function decodePng(buffer: Buffer): Raster { const png = PNG.sync.read(buffer); const raster = new Raster(png.width, png.height); raster.data.set(png.data); return raster; }
export async function readPng(path: string): Promise<Raster> { return decodePng(await readFile(path)); }
export async function writePng(path: string, raster: Raster): Promise<void> { await mkdir(dirname(path), { recursive: true }); await writeFile(path, encodePng(raster)); }
