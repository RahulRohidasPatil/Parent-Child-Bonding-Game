export type Rgba = readonly [number, number, number, number];

export type LayerSlot =
  | 'hair_back'
  | 'body_skin'
  | 'bottoms'
  | 'shoes'
  | 'top'
  | 'outerwear'
  | 'eyes'
  | 'brows'
  | 'mouth'
  | 'hair_front'
  | 'facial_hair'
  | 'earrings'
  | 'glasses'
  | 'face_accessory'
  | 'headwear'
  | 'neck_accessory'
  | 'wrist_accessory'
  | 'body_accessory';

export interface ColorSelection {
  id: string;
  color: string;
}

export interface AvatarConfig {
  version: 1;
  rig: 'front_idle_v1';
  skin: string;
  eyes: string;
  brows: string;
  mouth: string;
  hair: string;
  hairColor: string;
  facialHair: string | null;
  top: ColorSelection;
  outerwear: ColorSelection | null;
  bottom: ColorSelection;
  shoes: ColorSelection;
  headwear: ColorSelection | null;
  glasses: ColorSelection | null;
  accessories: string[];
}

export interface AssetDefinition {
  id: string;
  label: string;
  slot: LayerSlot;
  file: string;
  colors: readonly string[];
  z: number;
  mask: string;
  hairPart?: 'front' | 'back';
  hairMask?: 'hair_mask_cap_v1' | 'hair_mask_beanie_v1';
  imagegenSource: string;
}

export interface RenderOptions {
  size?: 128;
  grid?: boolean;
  masks?: boolean;
}
