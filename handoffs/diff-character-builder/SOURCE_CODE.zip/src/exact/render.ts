import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {Raster,decodePng,encodePng} from '../avatar/raster.js';
import {validateExact,ExactManifest,EXACT_SLOTS,ExactLayer} from './model.js';
import {exactLayerFile} from './assets.js';
const ROOT=resolve('assets/avatar/atelier-r5');let metadata:Promise<ExactManifest>|undefined;
const images=new Map<string,Promise<Raster>>(),cache=new Map<string,Buffer>();
export function exactManifest():Promise<ExactManifest>{return metadata??=readFile(resolve(ROOT,'manifest.json'),'utf8').then(JSON.parse);}
async function image(file:string){let p=images.get(file);if(!p){p=readFile(resolve(ROOT,file)).then(bytes=>{const r=decodePng(bytes);if(r.width!==128||r.height!==128||r.partialAlphaPixels())throw new Error('Invalid layer '+file);return r;});images.set(file,p);}return p;}
export async function renderExact(input:unknown,hidden:string[]=[]){const m=await exactManifest(),c=validateExact(input,m);if(hidden.some(s=>s!=='body'&&!EXACT_SLOTS.includes(s as typeof EXACT_SLOTS[number])))throw new Error('Invalid hidden slot');const hash=createHash('sha256').update(JSON.stringify({m,c,hidden:[...new Set(hidden)].sort()})).digest('hex').slice(0,24),layers:ExactLayer[]=[];if(!hidden.includes('body'))layers.push(m.skins.find(s=>s.id===c.skin)!.layer);for(const slot of EXACT_SLOTS){const id=c.equipment[slot];if(id&&!hidden.includes(slot))layers.push(...m.cosmetics.find(a=>a.id===id)!.layers);}layers.sort((a,b)=>a.z-b.z);const files=layers.map(l=>exactLayerFile(l,c)),cached=cache.get(hash);if(cached)return{png:cached,hash,layers:files};const masks:Record<string,Raster[]>={};for(const l of layers)for(const target of l.hide??[]){const[region,key]=target.split(':');(masks[region]??=[]).push(await image(m.masks[key]));}const out=new Raster(128,128);for(const l of layers){const mask=masks[l.region];out.blit(await image(exactLayerFile(l,c)),mask?(x,y)=>mask.some(r=>r.pixel(x,y)[3]===255):undefined);}const png=encodePng(out);if(cache.size>=512)cache.delete(cache.keys().next().value!);cache.set(hash,png);return{png,hash,layers:files};}
