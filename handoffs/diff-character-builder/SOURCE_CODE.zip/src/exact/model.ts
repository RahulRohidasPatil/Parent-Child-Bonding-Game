import {z} from 'zod';
import {RefinedConfigSchema,DEFAULT_REFINED,type RefinedManifest} from '../refined/model.js';
export {EYE_COLORS,EYE_COLOR_INFO,REFINED_SLOTS as EXACT_SLOTS} from '../refined/model.js';
export type {RefinedSlot as ExactSlot,RefinedLayer as ExactLayer,RefinedCosmetic as ExactCosmetic,EyeColor} from '../refined/model.js';
export const ExactConfigSchema=RefinedConfigSchema.extend({version:z.literal(5),pack:z.literal('atelier-r5'),rig:z.literal('front_reference_v1')}).strict();
export type ExactConfig=z.infer<typeof ExactConfigSchema>;
export interface ExactManifest extends Omit<RefinedManifest,'version'|'pack'|'rig'>{version:5;pack:'atelier-r5';rig:'front_reference_v1';master:string;masterHash:string;partitionMasks:Record<string,string>;slotMasks?:Record<string,string>;compiledHashes?:Record<string,string>}
export const DEFAULT_EXACT:ExactConfig={...DEFAULT_REFINED,version:5,pack:'atelier-r5',rig:'front_reference_v1',equipment:{...DEFAULT_REFINED.equipment,shoes:'shoes.black'}};
export function validateExact(input:unknown,m:ExactManifest){const c=ExactConfigSchema.parse(input);for(const[slot,id]of Object.entries(c.equipment))if(id){const item=m.cosmetics.find(a=>a.id===id);if(!item||item.slot!==slot)throw new Error(`Invalid ${slot}: ${id}`);}return c;}
export function exactPresets(){return [{id:'reference',name:'Reference look',detail:'The original character, in layers.',config:DEFAULT_EXACT},{id:'quarter',name:'Clean quarter zip',detail:'A softer everyday.',config:{...DEFAULT_EXACT,equipment:{...DEFAULT_EXACT.equipment,top:'top.quarter'}}},{id:'hoodie',name:'Build night',detail:'Black hoodie. One more idea.',config:{...DEFAULT_EXACT,equipment:{...DEFAULT_EXACT.equipment,top:'top.hoodie'}}},{id:'forest',name:'Forest green',detail:'A relaxed zip hoodie.',config:{...DEFAULT_EXACT,equipment:{...DEFAULT_EXACT.equipment,top:'top.forest_hoodie'}}}];}
