import type {ExactConfig,ExactLayer} from './model.js';
export function exactLayerFile(l:ExactLayer,c:ExactConfig){return l.headSkinVariants?.[c.equipment.head]?.[c.skin]??l.eyeVariants?.[c.eyeColor]??l.skinVariants?.[c.skin]??l.file;}
