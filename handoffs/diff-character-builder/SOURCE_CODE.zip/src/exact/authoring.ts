import {Raster} from '../avatar/raster.js';
import {bounds,type Box} from '../atelier/pixels.js';
import {SKIN_PALETTES} from '../avatar/palettes.js';
export const LABELS=['body','head','hair','eyes','brows','nose','mouth','ears','top','bottom','shoes'] as const;
export type Label=typeof LABELS[number];
const inside=(x:number,y:number,b:Box)=>x>=b[0]&&x<b[0]+b[2]&&y>=b[1]&&y<b[1]+b[3];
export function partitionMaster(master:Raster){const parts=Object.fromEntries(LABELS.map(s=>[s,new Raster(128,128)])) as Record<Label,Raster>;
 for(let y=0;y<128;y++)for(let x=0;x<128;x++){const p=master.pixel(x,y);if(!p[3])continue;let slot:Label;
 const eye=(inside(x,y,[57,20,5,3])||inside(x,y,[67,20,5,3]))&&!(y===20&&(x===57||x===67));
 const brow=inside(x,y,[56,18,5,1])||inside(x,y,[68,18,5,1]);
 const nose=[[63,23],[62,24],[63,24],[63,26],[64,26],[65,26],[64,27]].some(([a,b])=>a===x&&b===y);
 const mouth=inside(x,y,[62,29,5,3])&&y!==30;
 const ears=y>=21&&y<=26&&(x<=54||x>=74);
 const warm=p[0]>p[1]+8&&p[0]>p[2]+8;
 if(eye)slot='eyes';else if(brow)slot='brows';else if(nose)slot='nose';else if(mouth)slot='mouth';else if(y<=23&&p[0]<175&&warm&&!ears)slot='hair';else if(y<18)slot=p[0]>200&&p[1]>140?'head':'hair';else if(ears&&y<30)slot='ears';else if(y<=33)slot='head';else if((y<=39&&x>=58&&x<=70&&warm)||(y>=71&&y<=77&&warm&&p[0]>125))slot='body';else if(y<=73)slot='top';else if(y>=112&&!(p[2]>p[0]+7))slot='shoes';else if(y<=113)slot='bottom';else slot='shoes';
 parts[slot].set(x,y,p);
 }return parts;
}
/** Recolour skin regions only. The reference skin keeps every original RGB value. */
export function skinVariant(r:Raster,id:string){if(id==='skin_02')return r;const p=SKIN_PALETTES[id],out=new Raster(128,128);for(let y=0;y<128;y++)for(let x=0;x<128;x++){const c=r.pixel(x,y);if(!c[3])continue;if(c[0]>c[1]+12&&c[1]>c[2]+8&&c[0]>100)out.set(x,y,c[0]>245?p.highlight:c[0]>215?p.base:c[0]>160?p.shadow:p.outlineShadow);else out.set(x,y,c);}return out;}
export function clipTo(r:Raster,mask:Raster){for(let i=3;i<r.data.length;i+=4)if(!mask.data[i])r.data.fill(0,i-3,i+1);return r;}
/** Map Imagegen garment pixels to the reference rig's garment silhouette. No new paint. */
export function textureToTemplate(source:Raster,template:Raster,openCenter=false){
 const out=new Raster(128,128),[sx,sy,sw,sh]=bounds(source),[tx,ty,tw,th]=bounds(template);
 for(let y=ty;y<ty+th;y++){
  const yy=Math.min(source.height-1,Math.floor(sy+(y-ty+.5)*sh/th));
  const xs:number[]=[],targets:number[]=[];
  for(let x=sx;x<sx+sw;x++)if(source.pixel(x,yy)[3]>=192)xs.push(x);
  for(let x=tx;x<tx+tw;x++)if(template.pixel(x,y)[3])targets.push(x);
  if(!xs.length||!targets.length)continue;
  const left=xs[0],right=xs.at(-1)!,start=targets[0],end=targets.at(-1)!;
  for(const x of targets){
   let xx=Math.round(left+(x-start)*(right-left)/Math.max(1,end-start)),c=source.pixel(xx,yy);
   if(c[3]<192){if(openCenter&&Math.abs(x-64)<=3)continue;xx=xs.reduce((a,b)=>Math.abs(a-xx)<Math.abs(b-xx)?a:b);c=source.pixel(xx,yy);}
   out.set(x,y,[c[0],c[1],c[2],255]);
  }
 }
 return out;
}
export function resampleSupport(r:Raster,master:Raster,head=false){const out=new Raster(128,128);for(let y=0;y<128;y++)for(let x=0;x<128;x++){if(!master.pixel(x,y)[3])continue;if(head){if(y>33)continue;const sx=Math.floor((x-51)*r.width*.56/27+r.width*.25),sy=Math.floor((y-4)*r.height*.228/30+r.height*.031);const p=r.pixel(sx,sy);if(p[0]>p[1]+8&&p[0]>p[2]+8)out.set(x,y,[p[0],p[1],p[2],255]);}else{if(y<34)continue;let sy=y<=73?550+(y-34)*510/39:y<=114?1060+(y-73)*910/41:1970+(y-114)*100/8;const arm=x<55||x>74;if(arm&&y<78)sy=(y+.5)*16.5;if(arm&&y>=78)continue;let sx=(x-64)*16.5+r.width/2;const drift=Math.max(0,Math.min(1,(y-58)/18))*3;if(arm&&y<78)sx+=(x<64?-drift:drift)*16.5;const p=r.pixel(Math.floor(sx),Math.floor(sy)),warm=p[0]>p[1]+10&&p[0]>p[2]+12,boxers=y>=70&&y<=84&&x>=54&&x<=74&&Math.max(...p.slice(0,3))<205&&Math.min(...p.slice(0,3))>45;if(warm||boxers)out.set(x,y,[p[0],p[1],p[2],255]);}}return out;}
