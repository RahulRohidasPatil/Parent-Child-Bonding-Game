import type {CollectionConfig,CollectionManifest} from '../collection/model.js';
import {suggestFaces,applyFaceSuggestion,type FaceSuggestion} from './matcher.js';
import type {FaceMetrics} from './measure.js';
import {nearestSkin,type SkinSample} from './skinTone.js';
import type {FacialHairObservation} from './facialHair.js';
import {matchHair,type HairObservation} from './hair.js';
import {HAIR_PALETTES} from '../collection/hairPalettes.js';
import {combinePhotos,type PhotoAnalysis} from './aggregate.js';

export function initSelfie(getCurrent:()=>CollectionConfig,manifest:CollectionManifest,apply:(c:CollectionConfig)=>void) {
 const dialog=document.getElementById('selfie-dialog') as HTMLDialogElement;
 const input=document.getElementById('selfie-file') as HTMLInputElement;
 const photo=document.getElementById('selfie-photo') as HTMLImageElement;
 const status=document.getElementById('selfie-status')!,results=document.getElementById('selfie-results')!,tones=document.getElementById('selfie-tones')!;
 let generation=0,previewGeneration=0,worker:Worker|undefined,timer:ReturnType<typeof setTimeout>|undefined;
 const urls:string[]=[];let cancelPending:(()=>void)|undefined;const gallery=document.getElementById('selfie-photo-list')!;
 const stop=()=>{worker?.terminate();worker=undefined;clearTimeout(timer);timer=undefined;const cancel=cancelPending;cancelPending=undefined;cancel?.();};
 const clear=()=>{
  generation++;previewGeneration++;stop();const diagnostic=document.getElementById('selfie-diagnostics');if(diagnostic)diagnostic.textContent='';for(const url of urls)URL.revokeObjectURL(url);urls.length=0;gallery.replaceChildren();
  photo.removeAttribute('src');photo.hidden=true;input.value='';results.replaceChildren();tones.replaceChildren();tones.hidden=true;
  status.textContent='';status.removeAttribute('data-error');
 };
 const close=()=>{clear();dialog.close();};
 const showError=(message:string)=>{previewGeneration++;status.textContent=message;status.dataset.error='true';results.replaceChildren();tones.replaceChildren();tones.hidden=true;};
 function showSuggestions(suggestions:FaceSuggestion[],sample:SkinSample|null|undefined,hair:HairObservation|null|undefined,facialHair:FacialHairObservation|null|undefined,ticket:number) {
  let skin=getCurrent().skin;
  if(sample?.reliable)skin=nearestSkin(sample.rgb,manifest.skins) as CollectionConfig['skin'];
  const hairMatches=matchHair(hair,manifest);let keepHair=false,hairColor=hairMatches[0]?.color??getCurrent().hairColor,hairChoice:string|null=hairMatches.length?'auto':getCurrent().equipment.hair;
  let beardChoice:string|null|undefined=facialHair&&manifest.cosmetics.some(c=>c.slot==='facialHair'&&c.id==='facialHair.'+facialHair.kind)?'facialHair.'+facialHair.kind:undefined;
  tones.hidden=false;
  const note=document.createElement('p');note.className='selfie-tone-note';
  note.textContent=sample?.reliable?'Suggested skin tone · Lighting affects the estimate. Adjust it here.':'Choose your skin tone · The photo lighting was unclear, so we kept your current tone.';
  const swatches=document.createElement('div');swatches.className='selfie-skin-swatches';swatches.setAttribute('aria-label','Suggested skin tone');
  const keep=document.createElement('button');keep.type='button';keep.className='selfie-keep-tone';keep.textContent='Keep my current skin tone';
  const renderPreviews=()=>{
   const previewTicket=++previewGeneration;results.replaceChildren();
   swatches.querySelectorAll<HTMLButtonElement>('button').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.skin===skin)));
   suggestions.forEach((features,index)=>{
    const chosenHair=keepHair?getCurrent().equipment.hair:hairChoice==='auto'?(hairMatches[index]?.id??hairMatches[0]?.id):hairChoice;
    const patch={...features,skin,facialHair:beardChoice,hair:chosenHair,hairColor:keepHair?getCurrent().hairColor:hairColor},button=document.createElement('button');button.type='button';button.className='selfie-result';button.disabled=true;button.setAttribute('aria-label','Use face suggestion '+(index+1));
    const image=document.createElement('img');image.alt='Face suggestion '+(index+1);image.width=128;image.height=128;
    image.onload=()=>{if(ticket===generation&&previewTicket===previewGeneration)button.disabled=false;};
    image.onerror=()=>{if(ticket===generation&&previewTicket===previewGeneration)showError('The avatar previews could not load. Please try again.');};
    image.src='/api/collection/render?'+new URLSearchParams({config:JSON.stringify(applyFaceSuggestion(getCurrent(),patch))});
    const frame=document.createElement('span');frame.className='selfie-result-image';frame.append(image);
    const label=document.createElement('span');label.textContent='Option '+(index+1);if(chosenHair){const name=document.createElement('small');name.textContent=manifest.cosmetics.find(c=>c.id===chosenHair)?.name??'';label.append(document.createElement('br'),name);}button.append(frame,label);
    button.onclick=()=>{if(ticket!==generation||previewTicket!==previewGeneration||!dialog.open)return;apply(applyFaceSuggestion(getCurrent(),patch));close();};results.append(button);
   });
  };
  for(const palette of manifest.skins) {
   const button=document.createElement('button');button.type='button';button.className='skin-swatch';button.style.background=palette.color;button.dataset.skin=palette.id;
   button.setAttribute('aria-label','Suggested skin tone '+Number(palette.id.slice(-2)));
   button.onclick=()=>{skin=palette.id as CollectionConfig['skin'];renderPreviews();};swatches.append(button);
  }
  keep.onclick=()=>{skin=getCurrent().skin;renderPreviews();};tones.append(note,swatches,keep);
  const hairNote=document.createElement('p');hairNote.className='selfie-tone-note';hairNote.textContent=hairMatches.length?'Three hairstyle possibilities from your photo. Compare the shape and texture; choose a fixed style below if you prefer.':'Your hair was unclear in this photo. Your current hairstyle is kept; you can change it in Hair.';
  const hairControls=document.createElement('div');hairControls.className='selfie-hair-controls';
  const styleLabel=document.createElement('label');styleLabel.textContent='Hairstyle ';const styleSelect=document.createElement('select');styleSelect.setAttribute('aria-label','Suggested hairstyle');if(hairMatches.length){const option=document.createElement('option');option.value='auto';option.textContent='Compare three matched hairstyles';styleSelect.append(option);}for(const item of manifest.cosmetics.filter(c=>c.slot==='hair')){const option=document.createElement('option');option.value=item.id;option.textContent=item.name;styleSelect.append(option);}styleSelect.value=hairChoice??'';styleSelect.onchange=()=>{hairChoice=styleSelect.value;renderPreviews();};styleLabel.append(styleSelect);
  const colorLabel=document.createElement('label');colorLabel.textContent='Hair color ';const colorSelect=document.createElement('select');colorSelect.setAttribute('aria-label','Suggested hair color');
  for(const palette of HAIR_PALETTES){const option=document.createElement('option');option.value=palette.id;option.textContent=palette.name;colorSelect.append(option);}colorSelect.value=hairColor;
  colorSelect.onchange=()=>{hairColor=colorSelect.value as CollectionConfig['hairColor'];keepHair=false;keepHairButton.textContent='Keep my current hair';renderPreviews();};colorLabel.append(colorSelect);
  const keepHairButton=document.createElement('button');keepHairButton.type='button';keepHairButton.className='selfie-keep-tone';keepHairButton.textContent='Keep my current hair';
  keepHairButton.onclick=()=>{keepHair=!keepHair;keepHairButton.textContent=keepHair?'Use photo-matched hair':'Keep my current hair';colorSelect.disabled=keepHair;styleSelect.disabled=keepHair;renderPreviews();};
  const beardLabel=document.createElement('label');beardLabel.textContent='Facial hair ';const beardSelect=document.createElement('select');beardSelect.setAttribute('aria-label','Suggested facial hair');
  for(const item of [{id:'keep',name:'Keep my current facial hair'},{id:'none',name:'None'},...manifest.cosmetics.filter(c=>c.slot==='facialHair')]){const option=document.createElement('option');option.value=item.id;option.textContent=item.name;beardSelect.append(option);}
  beardSelect.value=beardChoice??'keep';beardSelect.onchange=()=>{beardChoice=beardSelect.value==='keep'?undefined:beardSelect.value==='none'?null:beardSelect.value;renderPreviews();};beardLabel.append(beardSelect);
  hairControls.append(styleLabel,colorLabel,beardLabel);if(hairMatches.length)hairControls.append(keepHairButton);tones.append(hairNote,hairControls);renderPreviews();
 }
 async function analyzeFile(file:File,ticket:number,index:number,total:number):Promise<PhotoAnalysis> {
  if(!['image/jpeg','image/png','image/webp'].includes(file.type))throw Error('Choose a JPEG, PNG or WebP photo.');
  if(file.size>20*1024*1024)throw Error('Choose a photo smaller than 20 MB.');
  const active=()=>{if(ticket!==generation||!dialog.open)throw new DOMException('Cancelled','AbortError');};
  let decoded:ImageBitmap|undefined,transfer:ImageBitmap|undefined;
  try {
   active();status.textContent=`Preparing photo ${index+1} of ${total}…`;
   decoded=await createImageBitmap(file,{imageOrientation:'from-image'});active();
   if(decoded.width*decoded.height>40000000)throw Error('Choose a photo under 40 megapixels.');
   if(Math.min(decoded.width,decoded.height)<160)throw Error('Choose a larger, clearer portrait.');
   const scale=Math.min(1,1024/Math.max(decoded.width,decoded.height));
   const canvas=new OffscreenCanvas(Math.round(decoded.width*scale),Math.round(decoded.height*scale)),ctx=canvas.getContext('2d');
   if(!ctx)throw Error('This browser cannot prepare the photo.');
   ctx.drawImage(decoded,0,0,canvas.width,canvas.height);decoded.close();decoded=undefined;
   const preview=await canvas.convertToBlob({type:'image/jpeg',quality:.8});transfer=await createImageBitmap(canvas);active();
   const url=URL.createObjectURL(preview);urls.push(url);
   if(total===1){photo.src=url;photo.hidden=false;}else{const thumbnail=document.createElement('img');thumbnail.src=url;thumbnail.alt='Local reference photo '+(index+1);thumbnail.className='selfie-photo';gallery.append(thumbnail);}
   return await new Promise<PhotoAnalysis>((resolve,reject)=>{
    let settled=false;
    const finish=(error:Error|null,value?:PhotoAnalysis)=>{if(settled)return;settled=true;cancelPending=undefined;stop();if(error)reject(error);else resolve(value!);};
    worker=new Worker(new URL('./worker.js',import.meta.url),{type:'module'});
    cancelPending=()=>{if(settled)return;settled=true;reject(new DOMException('Cancelled','AbortError'));};
    timer=setTimeout(()=>finish(Error('Analysis took too long. Try a smaller photo or use the face controls.')),45000);
    worker.onerror=()=>finish(Error('Local analysis could not start. Try another browser or use the face controls.'));
    worker.onmessage=({data})=>{
     if(ticket!==generation||!dialog.open||settled)return;
     if(data.type==='status'){status.textContent=`Photo ${index+1} of ${total} · ${data.text??'Analyzing…'}`;return;}
     if(data.type==='error'){finish(Error(data.message??'Please try another portrait.'));return;}
     if(data.type!=='result'||!data.metrics){finish(Error('The face could not be measured.'));return;}
     finish(null,data as PhotoAnalysis);
    };
    try{worker.postMessage({bitmap:transfer},[transfer!]);transfer=undefined;}catch(error){finish(error instanceof Error?error:Error('Local analysis could not start.'));}
   });
  }finally{decoded?.close();transfer?.close();}
 }
 async function processPhotos(source:File[]|Promise<File[]>) {
  clear();const ticket=generation;
  const active=()=>ticket===generation&&dialog.open;
  try {
   const files=await source;if(!active())return;
   if(!files.length||files.length>3)throw Error('Choose between one and three photos of the same person.');
   if(typeof Worker==='undefined'||typeof createImageBitmap==='undefined'||typeof OffscreenCanvas==='undefined')throw Error('Local photo analysis is not supported here. You can still use the face controls.');
   const analyses:PhotoAnalysis[]=[],issues:string[]=[],seen=new Set<string>(),sourceIndices:number[]=[];
   for(let index=0;index<files.length;index++){
    if(!active())return;
    const file=files[index];
    try {
     if(file.size>20*1024*1024)throw Error('Choose a photo smaller than 20 MB.');
     const digest=await crypto.subtle.digest('SHA-256',await file.arrayBuffer());if(!active())return;
     const key=Array.from(new Uint8Array(digest),v=>v.toString(16).padStart(2,'0')).join('');
     if(seen.has(key)){issues.push(`Photo ${index+1} is a duplicate and was skipped.`);continue;}seen.add(key);
     const analysis=await analyzeFile(file,ticket,index,files.length);if(!active())return;
     analyses.push(analysis);sourceIndices.push(index);
    }catch(error){if(!active()||error instanceof DOMException&&error.name==='AbortError')return;issues.push(`Photo ${index+1}: ${error instanceof Error?error.message:'This photo could not be read.'}`);}
   }
   if(!active())return;
   if(!analyses.length)throw Error(issues.join(' ')||'No usable photos. Try a clear portrait.');
   const combined=combinePhotos(analyses),suggestions=suggestFaces(combined.metrics,manifest);
   const diagnostic=document.getElementById('selfie-diagnostics');if(diagnostic)diagnostic.textContent=JSON.stringify({analyses,combined,issues,sourceIndices},null,2);
   status.textContent=(files.length>1?`Using ${combined.used.length} of ${files.length} photos. `:'')+'Three starting points. Choose one, then fine-tune it.';
   showSuggestions(suggestions,combined.skin,combined.hair,combined.facialHair,ticket);
   const warnings=[...issues,...combined.warnings];if(warnings.length){const notice=document.createElement('p');notice.className='selfie-note';notice.textContent=warnings.join(' ');tones.prepend(notice);}
   return {analyses,combined,suggestions,issues};
  }catch(error){if(active()){stop();showError(error instanceof Error?error.message:'These photos could not be read. Please try again.');}}
  finally{if(active())input.value='';}
 }
 const processPhoto=(source:File|Promise<File>)=>processPhotos(Promise.resolve(source).then(file=>[file]));
 const open=()=>{clear();if(!dialog.open)dialog.showModal();};
 document.getElementById('selfie-open')!.onclick=open;
 document.getElementById('selfie-close')!.onclick=close;
 // Native Escape emits close asynchronously. Do not clear a newly reopened dialog.
 dialog.addEventListener('close',()=>{if(!dialog.open)clear();});
 dialog.addEventListener('cancel',()=>clear());
 dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const b=dialog.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)close();});
 input.onchange=()=>{const files=Array.from(input.files??[]);if(files.length)void processPhotos(files);};
 return {open,processPhoto,processPhotos};
}
