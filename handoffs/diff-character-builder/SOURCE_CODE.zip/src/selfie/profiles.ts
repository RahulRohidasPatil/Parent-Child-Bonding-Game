import type {FaceMetrics} from './measure.js';
export type MatchedSlot='head'|'eyes'|'brows'|'nose'|'mouth';
export interface FaceProfile {id:string;slot:MatchedSlot;traits:Partial<FaceMetrics>}
/** Art-directed starting-point descriptors, not a trained identity or demographic classifier. */
export const FACE_PROFILES:FaceProfile[]=[
 ...[['head.soft_oval',1.26,.78],['head.round',1.15,.82],['head.soft_square',1.21,.86],['head.full_round',1.08,.89],['head.narrow',1.40,.70],['head.angular',1.28,.74]].map(([id,aspect,jaw])=>({id:id as string,slot:'head' as const,traits:{aspect:aspect as number,jaw:jaw as number}})),
 ...[['eyes.reference_neutral',.25,0],['eyes.reference_friendly',.30,0],['eyes.reference_focused',.18,.02],['eyes.almond',.24,.025],['eyes.hooded',.16,0],['eyes.monolid',.14,.025],['eyes.round_soft',.35,0],['eyes.upturned',.25,.08],['eyes.mature',.22,-.04]].map(([id,eyeOpen,eyeTilt])=>({id:id as string,slot:'eyes' as const,traits:{eyeOpen:eyeOpen as number,eyeTilt:eyeTilt as number}})),
 ...[['brows.reference_neutral',.16,.035],['brows.reference_friendly',.19,.03],['brows.reference_focused',.10,.045],['brows.fine',.14,.018],['brows.full',.14,.06],['brows.arch',.22,.035],['brows.bushy',.18,.075]].map(([id,browArch,browThickness])=>({id:id as string,slot:'brows' as const,traits:{browArch:browArch as number,browThickness:browThickness as number}})),
 ...[['nose.reference_neutral',.20,.24],['nose.reference_friendly',.19,.22],['nose.reference_focused',.18,.25],['nose.button',.18,.18],['nose.broad',.29,.22],['nose.straight',.19,.31],['nose.curved',.24,.32]].map(([id,noseWidth,noseLength])=>({id:id as string,slot:'nose' as const,traits:{noseWidth:noseWidth as number,noseLength:noseLength as number}})),
 ...[['mouth.reference_neutral',.38,.15,0],['mouth.reference_friendly',.44,.18,.08],['mouth.reference_focused',.35,.12,-.02],['mouth.wide_smile',.49,.14,.10],['mouth.thin',.38,.08,0],['mouth.full',.42,.26,0],['mouth.mature',.41,.13,.04]].map(([id,mouthWidth,lipFullness,smile])=>({id:id as string,slot:'mouth' as const,traits:{mouthWidth:mouthWidth as number,lipFullness:lipFullness as number,smile:smile as number}}))
];
