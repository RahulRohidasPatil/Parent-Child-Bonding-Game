import type {HairDetails} from '../collection/hairCatalog.js';
import type {HairMetrics} from './hair.js';
/** Initial art descriptors for expansion cosmetics. They are lower-priority than calibrated core profiles. */
export function libraryHairTraits(id:string,details:HairDetails):HairMetrics {
 const name=id.replace('hair.',''),short=details.length==='Short',medium=details.length==='Medium',tied=details.length==='Tied';
 const curly=details.texture==='curly'||details.texture==='coily',bun=['high_bun','low_bun','double_buns'].includes(name);
 let volume=short?.15:.22,width=short?1.1:1.35,length=short?0:medium?.2:tied?(bun?0:.6):.8;
 if(['tall_afro','tapered_afro','rounded_coils','curly_mop'].includes(name)){volume=name==='tall_afro'?.48:.3;width=name==='tall_afro'?1.65:1.35;}
 if(['high_and_tight','mid_taper_fade','high_taper_fade','skin_fade_crop','mini_afro','flat_twists'].includes(name))volume=.075;
 if(['disconnected_undercut','textured_undercut','brush_cut'].includes(name))volume=.25;
 if(name==='waist_length_straight')length=1.4;
 if(name==='micro_bob')length=.02;
 if(name==='high_bun'||name==='double_buns'){volume=.52;width=name==='double_buns'?1.7:1.1;}
 if(name==='long_pixie')length=.02;
 const fringe={open:.025,middle:.38,side:.22,blunt:.76,textured:.57}[details.fringe];
 return {volume,width,length,sideDepth:short?.42:bun?.6:1+length,fringe,asymmetry:details.fringe==='side'?.24:.07,crown:.92,texture:details.texture==='coily'||details.texture==='locs'?.75:details.texture==='braided'?.58:curly?.6:details.texture==='wavy'?.38:.2};
}
