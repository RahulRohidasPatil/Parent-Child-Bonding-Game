/** Development-only controls exercise the same file preparation, worker and UI path. */
export function bindSelfieLab(selfie:{processPhoto:(source:File|Promise<File>)=>Promise<unknown>;processPhotos:(source:File[]|Promise<File[]>)=>Promise<unknown>}) {
  const details=document.createElement('details'),summary=document.createElement('summary'),metrics=document.createElement('pre');summary.textContent='Analysis details (development)';metrics.id='selfie-diagnostics';metrics.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;font-size:11px';details.append(summary,metrics);document.getElementById('selfie-dialog')!.append(details);
  const fixtureControls=document.getElementById('selfie-fixtures')!;
  for(const id of ['portrait','michelle','joe','donald','kamala','jill','watkins','williams','hadfield','jemison','ride','bluford']){
    const button=document.createElement('button');button.textContent='Three variants: '+id;fixtureControls.append(button);
    button.onclick=()=>{void selfie.processPhotos((async()=>{
      const blob=await(await fetch('/dev/selfie-fixture/'+id)).blob(),original=new File([blob],id+'.jpg',{type:'image/jpeg'}),bitmap=await createImageBitmap(blob),files=[original];
      try{for(const brightness of [.88,1.12]){const canvas=new OffscreenCanvas(bitmap.width,bitmap.height),ctx=canvas.getContext('2d')!;ctx.filter='brightness('+brightness+')';ctx.drawImage(bitmap,0,0);files.push(new File([await canvas.convertToBlob({type:'image/jpeg',quality:.92})],id+'-'+brightness+'.jpg',{type:'image/jpeg'}));}}finally{bitmap.close();}return files;
    })());};
  }
  for(const kind of ['duplicates','mixed','too-many']){
    const button=document.createElement('button');button.textContent='Test '+kind;fixtureControls.append(button);
    button.onclick=()=>{void selfie.processPhotos((async()=>{const blob=await(await fetch('/dev/selfie-fixture/portrait')).blob(),photo=new File([blob],'portrait.jpg',{type:'image/jpeg'});return kind==='mixed'?[new File(['invalid'],'invalid.txt',{type:'text/plain'}),photo]:Array.from({length:kind==='too-many'?4:3},()=>photo);})());};
  }
  document.querySelectorAll<HTMLButtonElement>('[data-fixture]').forEach(button => {
    button.onclick = () => {
      const source = (async () => {
        const kind = button.dataset.fixture!;
        if (kind === 'invalid') return new File(['invalid'], 'test.txt', {type:'text/plain'});
        const response = await fetch('/dev/selfie-fixture/' + (kind === 'multiple' ? 'portrait' : kind));
        if (!response.ok) throw Error('Fixture unavailable');
        const blob = await response.blob();
        if (kind !== 'multiple') return new File([blob], kind + '.jpg', {type:'image/jpeg'});
        const portrait = await createImageBitmap(blob);
        try {
          const canvas = new OffscreenCanvas(portrait.width * 2, portrait.height);
          const ctx = canvas.getContext('2d')!;
          ctx.drawImage(portrait, 0, 0);
          ctx.drawImage(portrait, portrait.width, 0);
          return new File([await canvas.convertToBlob({type:'image/jpeg'})], 'two.jpg', {type:'image/jpeg'});
        } finally { portrait.close(); }
      })();
      // Reserve the generation before the fixture fetch; cancelled fixtures cannot re-open work.
      void selfie.processPhoto(source);
    };
  });
}
