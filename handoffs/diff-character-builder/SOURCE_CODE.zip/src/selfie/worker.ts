import {measureFace,PhotoError} from './measure.js';
import {localAssetFetch} from './network.js';
import {measureFacialHair} from './facialHair.js';
import {sampleSkin} from './skinTone.js';
import {measureHair,type HairObservation} from './hair.js';
globalThis.fetch=localAssetFetch(globalThis.fetch.bind(globalThis),self.location.origin);
const worker=self as unknown as {onmessage:((event:MessageEvent<{bitmap:ImageBitmap}>)=>void)|null;postMessage:(message:unknown)=>void};
worker.onmessage=async({data})=>{
 const bitmap=data.bitmap;let task:import('@mediapipe/tasks-vision').FaceLandmarker|undefined,segmenter:import('@mediapipe/tasks-vision').ImageSegmenter|undefined;
 try {
  worker.postMessage({type:'status',text:'Loading local face analysis…'});
  const modulePath='/assets/selfie/v1/vision_bundle.mjs';
  const {FilesetResolver,FaceLandmarker,ImageSegmenter}=await import(modulePath) as typeof import('@mediapipe/tasks-vision');
  const files=await FilesetResolver.forVisionTasks('/assets/selfie/v1/wasm',true);
  task=await FaceLandmarker.createFromOptions(files,{baseOptions:{modelAssetPath:'/assets/selfie/v1/face_landmarker.task',delegate:'CPU'},canvas:new OffscreenCanvas(1,1),runningMode:'IMAGE',numFaces:2,minFaceDetectionConfidence:.6,minFacePresenceConfidence:.6,outputFaceBlendshapes:false,outputFacialTransformationMatrixes:false});
  worker.postMessage({type:'status',text:'Finding facial proportions…'});
  const start=performance.now(),result=task.detect(bitmap);
  if(result.faceLandmarks.length===0)throw new PhotoError('no_face','No clear face found. Try a well-lit, front-facing photo.');
  if(result.faceLandmarks.length!==1)throw new PhotoError('multiple','Please choose a photo with just one person.');
  const points=result.faceLandmarks[0],metrics=measureFace(points,bitmap.width,bitmap.height);
  const sampleCanvas=new OffscreenCanvas(bitmap.width,bitmap.height),ctx=sampleCanvas.getContext('2d',{willReadFrequently:true})!;ctx.drawImage(bitmap,0,0);
  const facePixels=ctx.getImageData(0,0,bitmap.width,bitmap.height);
  const skin=sampleSkin(facePixels,points),facialHair=measureFacialHair(facePixels,points);
  task.close();task=undefined;
  let hair:HairObservation|null=null,hairIssue:string|undefined;
  try {
   worker.postMessage({type:'status',text:'Matching your hair shape and color…'});
   // SDK 1.0.1 consumes the loader's global factory after initialization. A second
   // stable module URL re-executes the loader for this task, without private SDK mutation.
   const hairFiles={...files,wasmLoaderPath:files.wasmLoaderPath+'?task=hair-v1'};
   segmenter=await ImageSegmenter.createFromOptions(hairFiles,{baseOptions:{modelAssetPath:'/assets/selfie/v1/hair_segmenter.tflite',delegate:'CPU'},canvas:new OffscreenCanvas(1,1),runningMode:'IMAGE',outputConfidenceMasks:true,outputCategoryMask:false});
   const hairIndex=segmenter.getLabels().findIndex(s=>s.toLowerCase()==='hair');
   if(hairIndex<0)throw Error('Hair model labels unavailable');
   // Analyze a face-relative portrait crop so a distant background cannot dominate hair selection.
   const fw=Math.hypot((points[234].x-points[454].x)*bitmap.width,(points[234].y-points[454].y)*bitmap.height);
   const fh=Math.hypot((points[10].x-points[152].x)*bitmap.width,(points[10].y-points[152].y)*bitmap.height);
   const side=Math.ceil(Math.max(fw*2.6,fh*2.5)),left=Math.floor(points[10].x*bitmap.width-side/2),top=Math.floor(points[10].y*bitmap.height-fh*.6);
   const canvas=new OffscreenCanvas(512,512),context=canvas.getContext('2d',{willReadFrequently:true})!;
   context.drawImage(bitmap,left,top,side,side,0,0,512,512);
   const pixels=context.getImageData(0,0,512,512),cropPoints=points.map(p=>({x:(p.x*bitmap.width-left)/side,y:(p.y*bitmap.height-top)/side}));
   segmenter.segment(canvas,segmentation=>{
    const mask=segmentation.confidenceMasks?.[hairIndex];
    if(mask)hair=measureHair(pixels,mask.getAsFloat32Array(),mask.width,mask.height,cropPoints);
   });
  }catch(error){hair=null;hairIssue=error instanceof Error?error.message:'Hair analysis failed';} // A missing/uncertain hair model must not discard successful face suggestions.
  worker.postMessage({type:'result',metrics,skin,hair,facialHair,hairIssue,inferenceMs:Math.round(performance.now()-start)});
 }catch(error){worker.postMessage({type:'error',code:error instanceof PhotoError?error.code:'runtime',message:error instanceof PhotoError?error.message:'Local analysis could not start in this browser. Try again or use the face controls.'});}
 finally{bitmap?.close();task?.close();segmenter?.close();}
};
