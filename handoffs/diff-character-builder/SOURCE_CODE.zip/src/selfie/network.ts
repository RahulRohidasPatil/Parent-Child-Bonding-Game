/** Restrict the isolated model worker to versioned, local, read-only runtime assets.
 * MediaPipe 1.0.1 includes usage telemetry. It must not leave this worker.
 * The worker response CSP independently blocks external connections/imports.
 */
export function localAssetFetch(nativeFetch: typeof fetch, origin: string): typeof fetch {
  const paths = new Set([
    '/assets/selfie/v1/face_landmarker.task',
    '/assets/selfie/v1/hair_segmenter.tflite',
    ...['vision_wasm_internal', 'vision_wasm_module_internal', 'vision_wasm_nosimd_internal']
      .flatMap(name => ['js', 'wasm'].map(ext => `/assets/selfie/v1/wasm/${name}.${ext}`)),
  ]);
  return async (input, init) => {
    const request = input instanceof Request ? input : undefined;
    const url = new URL(request?.url ?? String(input), origin);
    const method = (init?.method ?? request?.method ?? 'GET').toUpperCase();
    if (url.origin !== origin || !paths.has(url.pathname) || url.search || url.hash || method !== 'GET') {
      throw new TypeError('The local analysis worker cannot make this network request.');
    }
    return nativeFetch(url.href, { ...init, method: 'GET', credentials: 'omit', redirect: 'error' });
  };
}
