import type {Point} from './measure.js';
export interface FacialHairObservation {kind:'mustache'|'short_beard'|'uncertain';confidence:number;upper:number;lower:number}
interface Pixels {width:number;height:number;data:Uint8ClampedArray}
/** Conservative local contrast measurement, excluding lips, nostrils and jaw boundaries.
 * This is a starting-point suggestion; shadow and makeup can still be ambiguous.
 */
export function measureFacialHair(image:Pixels,points:Point[]):FacialHairObservation|null {
 if(points.length<468||image.data.length!==image.width*image.height*4)return null;
 const p=points.map(q=>({x:q.x*image.width,y:q.y*image.height}));
 if(p.some(q=>!Number.isFinite(q.x)||!Number.isFinite(q.y)))return null;
 const l=p[61],r=p[291],dx=r.x-l.x,dy=r.y-l.y,mw=Math.hypot(dx,dy);
 if(mw<24)return null;
 const cos=dx/mw,sin=dy/mw,mid={x:(l.x+r.x)/2,y:(l.y+r.y)/2};
 const relative=(q:{x:number;y:number})=>({x:((q.x-mid.x)*cos+(q.y-mid.y)*sin)/mw,y:(-(q.x-mid.x)*sin+(q.y-mid.y)*cos)/mw});
 const nose=relative(p[2]).y,lip=relative(p[0]).y,lower=relative(p[17]).y,chin=relative(p[152]).y;
 if(lip-nose<.06||chin-lower<.2)return null;
 const region=(x0:number,x1:number,y0:number,y1:number)=>{
  const values:number[]=[];
  for(let u=x0;u<x1;u+=.025)for(let v=y0;v<y1;v+=.025){const x=Math.round(mid.x+mw*(u*cos-v*sin)),y=Math.round(mid.y+mw*(u*sin+v*cos));if(x<0||x>=image.width||y<0||y>=image.height)continue;const i=(y*image.width+x)*4;if(image.data[i+3]===255)values.push(.2126*image.data[i]+.7152*image.data[i+1]+.0722*image.data[i+2]);}
  values.sort((a,b)=>a-b);return values.length>=8?values[Math.floor(values.length*.5)]:NaN;
 };
 const cheekLeft=region(-.8,-.56,nose,lip),cheekRight=region(.56,.8,nose,lip);
 if(!Number.isFinite(cheekLeft+cheekRight)||Math.abs(cheekLeft-cheekRight)>45)return null;
 const contrast=(value:number,ref:number)=>Math.max(0,(ref-value)/Math.max(30,ref));
 const y0=nose+(lip-nose)*.3,y1=lip-(lip-nose)*.12;
 const upper=Math.min(contrast(region(-.4,-.12,y0,y1),cheekLeft),contrast(region(.12,.4,y0,y1),cheekRight));
 const lowerScore=Math.min(contrast(region(-.4,-.12,lower+(chin-lower)*.25,lower+(chin-lower)*.6),cheekLeft),contrast(region(.12,.4,lower+(chin-lower)*.25,lower+(chin-lower)*.6),cheekRight));
 if(!Number.isFinite(upper+lowerScore))return null;
 if(upper>.32&&lowerScore>.35)return {kind:'short_beard',confidence:Math.min(1,Math.min(upper,lowerScore)*2),upper,lower:lowerScore};
 if(upper>.28&&lowerScore<.24)return {kind:'mustache',confidence:Math.min(1,upper*2),upper,lower:lowerScore};
 return {kind:'uncertain',confidence:0,upper,lower:lowerScore};
}
