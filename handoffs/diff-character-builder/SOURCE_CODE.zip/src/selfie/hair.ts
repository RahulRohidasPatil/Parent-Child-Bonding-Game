import {hairDetails} from '../collection/hairCatalog.js';
import type {Point} from './measure.js';
import type {CollectionManifest} from '../collection/model.js';
import {HAIR_PALETTES,type HairColor} from '../collection/hairPalettes.js';
import {nearestSkin,type Rgb} from './skinTone.js';
export interface HairMetrics {volume:number;width:number;length:number;fringe:number;asymmetry:number;texture:number;crown:number;sideDepth:number}
export interface HairObservation {metrics:HairMetrics;rgb:Rgb;reliable:boolean;directionality?:number}
export interface HairChoice {id:string;color:HairColor}
interface Pixels {width:number;height:number;data:Uint8ClampedArray}
const percentile=(values:number[],q:number)=>values.sort((a,b)=>a-b)[Math.min(values.length-1,Math.floor(values.length*q))];
/** Hair-only segmentation is measured relative to the face. No hair is guessed from skin tone. */
export function measureHair(image:Pixels,confidence:Float32Array,maskWidth:number,maskHeight:number,points:Point[]):HairObservation|null {
 if(points.length<468||confidence.length!==maskWidth*maskHeight||image.data.length!==image.width*image.height*4)return null;
 const p=points.map(q=>({x:q.x*image.width,y:q.y*image.height}));
 if(p.some(q=>!Number.isFinite(q.x)||!Number.isFinite(q.y)))return null;
 const fw=Math.hypot(p[234].x-p[454].x,p[234].y-p[454].y),fh=Math.hypot(p[10].x-p[152].x,p[10].y-p[152].y);
 if(fw<20||fh<30)return null;
 const roll=Math.atan2(p[263].y-p[33].y,p[263].x-p[33].x),cos=Math.cos(roll),sin=Math.sin(roll),origin=p[10];
 const upright=(x:number,y:number)=>({x:(x-origin.x)*cos+(y-origin.y)*sin,y:-(x-origin.x)*sin+(y-origin.y)*cos});
 const eyeY=(upright(p[33].x,p[33].y).y+upright(p[263].x,p[263].y).y)/2;
 const xs:number[]=[],ys:number[]=[],channels:[number[],number[],number[]]=[[],[],[]];
 let fringeHair=0,fringeArea=0,crownHair=0,crownArea=0,left=0,right=0,totalConfidence=0,edge=0,gradientCount=0,relativeGradient=0,gradientX=0,gradientY=0;
 const at=(x:number,y:number)=>confidence[Math.max(0,Math.min(maskHeight-1,Math.floor((y+.5)*maskHeight/image.height)))*maskWidth+Math.max(0,Math.min(maskWidth-1,Math.floor((x+.5)*maskWidth/image.width)))];
 const luminance=(i:number)=>image.data[i]*.2126+image.data[i+1]*.7152+image.data[i+2]*.0722;
 const step=Math.max(1,Math.round(fw/70));
 for(let y=0;y<image.height;y++)for(let x=0;x<image.width;x++) {
  const q=upright(x,y),score=at(x,y);
  if(Math.abs(q.x)>fw*1.35||q.y<-.9*fh||q.y>2.1*fh)continue;
  if(Math.abs(q.x)<fw*.28&&q.y>=0&&q.y<eyeY*.85){fringeArea++;if(score>.65)fringeHair++;}
  if(Math.abs(q.x)<fw*.20&&q.y>=-.25*fh&&q.y<-.03*fh){crownArea++;if(score>.65)crownHair++;}
  if(score<.65||!Number.isFinite(score))continue;
  const i=(y*image.width+x)*4;if(image.data[i+3]!==255)continue;
  xs.push(q.x);ys.push(q.y);totalConfidence+=score;q.x<0?left++:right++;
  if(x<2||y<2||x>=image.width-2||y>=image.height-2)edge++;
  // Confident interior pixels only for color and texture; exclude boundary/background blends.
  if(score>.85&&at(x-step,y)>.85&&at(x+step,y)>.85&&at(x,y-step)>.85&&at(x,y+step)>.85){
   channels[0].push(image.data[i]);channels[1].push(image.data[i+1]);channels[2].push(image.data[i+2]);
   if(x+step<image.width&&y+step<image.height){const gx=Math.abs(luminance(i)-luminance(i+step*4)),gy=Math.abs(luminance(i)-luminance(i+step*image.width*4));gradientX+=gx;gradientY+=gy;relativeGradient+=(gx+gy)/2/Math.max(24,luminance(i));gradientCount++;}
  }
 }
 // Absence can be a bald head, an occlusion or a failed segmentation; preserve current hair.
 if(xs.length<fw*fh*.025||channels[0].length<20)return null;
 const top=percentile(ys.slice(),.02),bottom=percentile(ys.slice(),.98);
 let rgb=channels.map(c=>percentile(c,.5)) as Rgb;
 // For chromatic hair, sample diffuse mid-high tones rather than pooled dark shadows.
 if(Math.max(...rgb)-Math.min(...rgb)>Math.max(5,Math.max(...rgb)*.16))rgb=channels.map(c=>percentile(c,.7)) as Rgb;
 // Landmark 10 is the upper forehead, not the skull vertex. Remove a shared
 // forehead-to-scalp allowance so a close crop is not interpreted as a quiff.
 return {directionality:(gradientX-gradientY)/Math.max(1,gradientX+gradientY),metrics:{sideDepth:Math.max(0,bottom/fh),crown:crownArea?crownHair/crownArea:0,volume:Math.max(0,-top/fh-.25),width:(percentile(xs.slice(),.98)-percentile(xs.slice(),.02))/(fw*1.1),length:Math.max(0,(bottom-fh)/fh),fringe:fringeArea?fringeHair/fringeArea:0,asymmetry:Math.abs(left-right)/(left+right),texture:Math.min(1,(gradientCount?relativeGradient/gradientCount:0)*3)},rgb,reliable:totalConfidence/xs.length>.78&&edge/xs.length<.02};
}
// Art-directed hairstyle descriptors. These describe silhouette, not demographic identity.
// Volume is extension above the forehead; length is visible extension below the chin.
export const HAIR_PROFILES:{id:string;traits:HairMetrics}[]=[
 ['textured',.24,1.13,0,.66,.12,.40],['fluffy',.28,1.18,0,.50,.02,.38],['crop',.16,1.04,0,.55,.03,.52],['curls',.23,1.13,0,.27,.02,.65],
 ['long',.20,1.42,.9,.18,.08,.48],['bob',.24,1.3,.2,.20,.05,.17],['braids',.17,1.35,1,.12,.05,.63],
 ['buzz',.065,.98,0,.015,.015,.20],['crew_cut',.12,1.04,0,.05,.03,.30],['french_crop',.16,1.08,0,.72,.02,.38],['side_part',.18,1.08,0,.22,.19,.16],
 ['quiff',.31,1.13,0,.08,.17,.25],['pompadour',.36,1.17,0,.03,.07,.18],['spiky',.32,1.20,0,.12,.05,.60],['short_waves',.21,1.12,0,.46,.10,.40],
 ['afro',.42,1.65,0,.18,.02,.78],['coils',.14,1.08,0,.08,.02,.78],['tapered_curls',.30,1.22,0,.30,.04,.67],
 ['curtains',.20,1.23,.02,.44,.03,.17],['shag',.27,1.36,.2,.65,.08,.53],['wolf_cut',.25,1.36,.30,.54,.09,.51],['mullet',.22,1.20,.40,.38,.15,.40],
 ['straight_shoulder',.16,1.30,.50,.20,.03,.12],['locs',.23,1.45,.90,.35,.07,.75],['ponytail',.33,1.35,.65,.10,.38,.30],['bun',.51,1.10,0,.10,.08,.35],
 ['twists',.27,1.40,.35,.32,.06,.71],['receding_crop',.17,1.06,0,.0,.03,.30],['receding_waves',.19,1.08,0,.01,.09,.43],['balding_crown',.04,1.10,0,0,.02,.23],
 ['flat_top',.27,1.22,0,.04,.02,.75],['short_twists',.28,1.25,.03,.57,.10,.78],['cornrows',.09,1.05,0,.01,.02,.53],['afro_puffs',.48,1.82,0,.04,.02,.77],['side_bob',.21,1.37,.24,.44,.28,.23],
].map(([id,volume,width,length,fringe,asymmetry,texture])=>({id:'hair.'+id,traits:{volume:volume as number,width:width as number,length:length as number,fringe:fringe as number,asymmetry:asymmetry as number,texture:texture as number,sideDepth:({bob:1.05,side_bob:1.1,shag:1.15,wolf_cut:1.25,mullet:1.4,curtains:.8,afro:.6,afro_puffs:.65,bun:.5,buzz:.25,crew_cut:.3,side_part:.3,receding_crop:.25,receding_waves:.3,balding_crown:.5,short_twists:.65}[String(id)]??(Number(length)>.01?1+Number(length):.6)),crown:id==='balding_crown'?.1:String(id).startsWith('receding_')?.55:id==='cornrows'?.65:id==='afro_puffs'?.3:.95}}));
export function getHairProfiles(manifest:Pick<CollectionManifest,'cosmetics'>){const known=new Set(HAIR_PROFILES.map(p=>p.id));return [...HAIR_PROFILES.map(p=>({...p,penalty:0})),...manifest.cosmetics.filter(c=>c.slot==='hair'&&!known.has(c.id)&&c.hairMatch).map(c=>({id:c.id,traits:c.hairMatch!,penalty:.35}))];}
export function matchHair(observation:HairObservation|null|undefined,manifest:Pick<CollectionManifest,'cosmetics'>):HairChoice[] {
 if(!observation?.reliable)return [];
 const scales:HairMetrics={volume:.10,width:.24,length:.32,fringe:.4,asymmetry:.28,texture:.32,crown:.85,sideDepth:.32};
 if(observation.metrics.volume<.10&&observation.metrics.sideDepth<.65)scales.texture=1.2;
 if(Object.keys(scales).some(k=>!Number.isFinite(observation.metrics[k as keyof HairMetrics])))return [];
 const max=Math.max(...observation.rgb),chroma=max-Math.min(...observation.rgb),neutral=chroma<Math.max(5,max*.16);
 const color=nearestSkin(observation.rgb,HAIR_PALETTES.filter(p=>p.id!=='hair.original'&&(!neutral||['hair.black','hair.silver','hair.platinum'].includes(p.id)))) as HairColor;
 return getHairProfiles(manifest).filter(p=>(p.id!=='hair.balding_crown'||observation.metrics.crown<.35)&&( !p.id.includes('receding_')||observation.metrics.width<1.18)&&(!['hair.cornrows','hair.flat_twists'].includes(p.id)||(observation.directionality??0)>.28)&&manifest.cosmetics.some(c=>c.slot==='hair'&&c.id===p.id)).map(p=>({id:p.id,color,score:p.penalty+((['braided','locs'].includes(hairDetails(manifest.cosmetics.find(c=>c.id===p.id)!).texture)||p.id.includes('twists'))&&(observation.directionality??0)<.2?5:0)+Object.keys(scales).reduce((sum,k)=>sum+((observation.metrics[k as keyof HairMetrics]-p.traits[k as keyof HairMetrics])/scales[k as keyof HairMetrics])**2,0)})).sort((a,b)=>a.score-b.score||a.id.localeCompare(b.id)).slice(0,3).map(({id,color})=>({id,color}));
}
