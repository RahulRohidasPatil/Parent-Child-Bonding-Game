import type {FacialHairObservation} from './facialHair.js';
import type {FaceMetrics} from './measure.js';
import type {HairObservation} from './hair.js';
import type {SkinSample,Rgb} from './skinTone.js';
export interface PhotoAnalysis {metrics:FaceMetrics;skin?:SkinSample|null;hair?:HairObservation|null;inferenceMs?:number;facialHair?:FacialHairObservation|null}
export interface CombinedAnalysis extends PhotoAnalysis {used:number[];warnings:string[]}
export const median=(values:number[])=>{const s=[...values].sort((a,b)=>a-b),i=Math.floor(s.length/2);return s.length%2?s[i]:(s[i-1]+s[i])/2;};
const geometryScales={aspect:.13,jaw:.09,noseWidth:.07,noseLength:.07};
const geometryDistance=(a:PhotoAnalysis,b:PhotoAnalysis)=>Math.sqrt(Object.entries(geometryScales).reduce((sum,[k,scale])=>sum+((a.metrics[k as keyof FaceMetrics]-b.metrics[k as keyof FaceMetrics])/scale)**2,0)/4);
function combineNumbers<T extends object>(items:T[]):T{return Object.fromEntries(Object.keys(items[0]).map(k=>[k,median(items.map(v=>Number(v[k as keyof T])))])) as T;}
const colorDistance=(a:Rgb,b:Rgb)=>Math.hypot(...a.map((v,i)=>v-b[i]));
function combineColor(samples:Rgb[]):{rgb:Rgb;reliable:boolean}{
 const rgb=[0,1,2].map(i=>Math.round(median(samples.map(c=>c[i])))) as Rgb;
 const radius=samples.length===2?35:55;
 // Three photos can tolerate one color outlier; two need to agree with each other.
 const inliers=samples.filter(c=>colorDistance(c,rgb)<=radius);
 return {rgb,reliable:inliers.length>=Math.min(2,samples.length)};
}
/** Consistency filtering is not identity recognition. Users must select one person's photos. */
export function combinePhotos(photos:PhotoAnalysis[]):CombinedAnalysis {
 if(!photos.length||photos.length>3)throw Error('Choose between one and three photos.');
 const keys: (keyof FaceMetrics)[]=['aspect','jaw','eyeOpen','eyeTilt','browArch','browThickness','noseWidth','noseLength','mouthWidth','lipFullness','smile'];
 if(photos.some(p=>keys.some(k=>!Number.isFinite(p.metrics[k]))))throw Error('Invalid photo measurements');
 const ranked=photos.map((p,i)=>({i,neighbors:photos.map((q,j)=>({j,d:geometryDistance(p,q)})).filter(q=>q.d<=1.8)})).sort((a,b)=>b.neighbors.length-a.neighbors.length||a.neighbors.reduce((s,n)=>s+n.d,0)-b.neighbors.reduce((s,n)=>s+n.d,0)||a.i-b.i);
 if(photos.length>1&&ranked[0].neighbors.length<2)throw Error('These photos differ too much. Choose clear, front-facing photos of the same person.');
 const used=ranked[0].neighbors.map(n=>n.j).sort((a,b)=>a-b),accepted=used.map(i=>photos[i]),warnings:string[]=[];
 if(used.length<photos.length)warnings.push('One inconsistent photo was excluded.');
 const colors=accepted.flatMap(p=>p.skin?.reliable?[p.skin.rgb]:[]);
 const skin=colors.length?combineColor(colors):null;
 if(skin&&!skin.reliable)warnings.push('Lighting differs between photos. Please choose your skin tone.');
 const hairs=accepted.flatMap(p=>p.hair?.reliable?[p.hair]:[]);
 let hair:HairObservation|null=null;
 if(hairs.length){
  const lengths=hairs.map(h=>h.metrics.sideDepth),widths=hairs.map(h=>h.metrics.width);
  // Do not invent an intermediate hairstyle when the photos show different cuts or occlusions.
  const stable=Math.max(...lengths)-Math.min(...lengths)<.45&&Math.max(...widths)-Math.min(...widths)<.55;
  if(stable){const color=combineColor(hairs.map(h=>h.rgb));hair={metrics:combineNumbers(hairs.map(h=>h.metrics)),rgb:color.rgb,reliable:color.reliable,directionality:median(hairs.map(h=>h.directionality??0))};if(!color.reliable)warnings.push('Hair color differs between photos. Your current hair is kept.');}
  else {warnings.push('Hair differs between photos. Your current hair is kept; choose the hairstyle manually.');}
 }
 const beards=accepted.flatMap(p=>p.facialHair?[p.facialHair]:[]);
 const facialHair=beards.length>=Math.ceil(accepted.length*.66)&&beards.every(b=>b.kind===beards[0].kind)?{...beards[0],confidence:median(beards.map(b=>b.confidence))}:null;
 return {metrics:combineNumbers(accepted.map(p=>p.metrics)),skin,hair,facialHair,used,warnings};
}
