import type {CollectionConfig,CollectionManifest} from '../collection/model.js';import type {FaceMetrics} from './measure.js';import {FACE_PROFILES,type MatchedSlot} from './profiles.js';
export type FaceSuggestion=Pick<CollectionConfig['equipment'],MatchedSlot>&{skin?:CollectionConfig['skin'];hair?:CollectionConfig['equipment']['hair'];hairColor?:CollectionConfig['hairColor'];facialHair?:CollectionConfig['equipment']['facialHair']};
const slots:MatchedSlot[]=['head','eyes','brows','nose','mouth'];
const scales:FaceMetrics={aspect:.16,jaw:.10,eyeOpen:.08,eyeTilt:.07,browArch:.08,browThickness:.035,noseWidth:.065,noseLength:.065,mouthWidth:.10,lipFullness:.10,smile:.10};
export function suggestFaces(metrics:FaceMetrics,manifest:Pick<CollectionManifest,'cosmetics'>):FaceSuggestion[]{
 if(Object.keys(scales).some(k=>!Number.isFinite(metrics[k as keyof FaceMetrics])))throw Error('Invalid face proportions');
 let candidates:{patch:Partial<FaceSuggestion>;score:number}[]=[{patch:{},score:0}];
 for(const slot of slots){const profiles=FACE_PROFILES.filter(p=>p.slot===slot&&manifest.cosmetics.some(c=>c.id===p.id&&c.slot===slot)).map(p=>({id:p.id,score:Object.entries(p.traits).reduce((sum,[k,value])=>sum+((metrics[k as keyof FaceMetrics]-value!)/scales[k as keyof FaceMetrics])**2,0)})).sort((a,b)=>a.score-b.score||a.id.localeCompare(b.id)).slice(0,3);if(!profiles.length)throw Error('Face options are unavailable');candidates=candidates.flatMap(c=>profiles.map(p=>({patch:{...c.patch,[slot]:p.id},score:c.score+p.score})));}
 candidates.sort((a,b)=>a.score-b.score||JSON.stringify(a.patch).localeCompare(JSON.stringify(b.patch)));const selected:FaceSuggestion[]=[];
 for(const c of candidates){const patch=c.patch as FaceSuggestion;if(selected.every(p=>slots.filter(s=>p[s]!==patch[s]).length>=2)){selected.push(patch);if(selected.length===3)break;}}
 if(selected.length!==3)throw Error('Not enough different face options');return selected;
}
export function applyFaceSuggestion(current:CollectionConfig,patch:FaceSuggestion):CollectionConfig{return {...current,skin:patch.skin??current.skin,hairColor:patch.hairColor??current.hairColor,equipment:{...current.equipment,...Object.fromEntries(slots.map(s=>[s,patch[s]])),...(patch.hair!==undefined?{hair:patch.hair}:{}),...(patch.facialHair!==undefined?{facialHair:patch.facialHair}:{})}};}
