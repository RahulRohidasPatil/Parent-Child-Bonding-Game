export interface Point {x:number;y:number;z?:number}
export interface FaceMetrics {aspect:number;jaw:number;eyeOpen:number;eyeTilt:number;browArch:number;browThickness:number;noseWidth:number;noseLength:number;mouthWidth:number;lipFullness:number;smile:number}
export class PhotoError extends Error {constructor(public code:string,message:string){super(message);}}
/** MediaPipe Face Mesh topology; ratios use image pixels, not distorted normalized x/y units. */
export function measureFace(points:Point[],width:number,height:number):FaceMetrics{
 if(points.length<468||!Number.isFinite(width)||!Number.isFinite(height)||width<=0||height<=0||points.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)))throw new PhotoError('invalid','The face could not be measured. Please try another photo.');
 const p=points.map(p=>({x:p.x*width,y:p.y*height})),d=(a:number,b:number)=>Math.hypot(p[a].x-p[b].x,p[a].y-p[b].y),faceWidth=d(234,454),faceHeight=d(10,152),eyeWidth=(d(33,133)+d(362,263))/2;
 if(faceWidth<80||faceHeight<100||eyeWidth<10)throw new PhotoError('small','Your face is too small in this photo. Choose a closer portrait.');
 if(d(61,291)<5||d(33,263)<20)throw new PhotoError('invalid','The face could not be measured. Please try another photo.');
 const roll=Math.atan2(p[263].y-p[33].y,p[263].x-p[33].x);if(Math.abs(roll)>.38)throw new PhotoError('tilted','Choose a photo with your head upright and facing the camera.');
 const center={x:(p[33].x+p[263].x)/2,y:(p[33].y+p[263].y)/2},cos=Math.cos(roll),sin=Math.sin(roll);
 const upright=p.map(q=>({x:(q.x-center.x)*cos+(q.y-center.y)*sin,y:-(q.x-center.x)*sin+(q.y-center.y)*cos}));
 if(Math.abs(upright[1].x)/d(33,263)>.22)throw new PhotoError('profile','Please use a front-facing portrait rather than a side view.');
 const oval=[10,152,234,454];if(oval.some(i=>points[i].x<.01||points[i].x>.99||points[i].y<.01||points[i].y>.99))throw new PhotoError('cropped','Your face is cut off. Choose a photo showing your full face.');
 const y=(i:number)=>upright[i].y,clamp=(v:number,a:number,b:number)=>Math.max(a,Math.min(b,v));
 return {aspect:clamp(faceHeight/faceWidth,.9,1.9),jaw:clamp(d(172,397)/faceWidth,.4,1),eyeOpen:clamp((d(159,145)+d(386,374))/(2*eyeWidth),.05,.5),eyeTilt:clamp(((y(133)-y(33))+(y(362)-y(263)))/(2*eyeWidth),-.2,.2),browArch:clamp((((y(70)+y(107))/2-y(105))+((y(300)+y(336))/2-y(334)))/(2*eyeWidth),0,.25),browThickness:clamp((d(105,52)+d(334,282))/(2*faceWidth),.01,.12),noseWidth:clamp(d(98,327)/faceWidth,.08,.4),noseLength:clamp(d(168,2)/faceHeight,.1,.4),mouthWidth:clamp(d(61,291)/faceWidth,.2,.65),lipFullness:clamp((d(0,17)-d(13,14))/d(61,291),.03,.4),smile:clamp((((y(13)+y(14))/2)-((y(61)+y(291))/2))/d(61,291),-.15,.2)};
}
