import type {Point} from './measure.js';
export type Rgb = [number,number,number];
export interface SkinSample {rgb:Rgb;reliable:boolean}
interface Pixels {width:number;height:number;data:Uint8ClampedArray}
const diffuse=(values:number[])=>values.sort((a,b)=>a-b)[Math.floor(values.length*.35)];
/** Sample two small cheek areas below the eyes and above the mouth.
 * Diffuse cheek percentiles reduce small bright highlights; clipping and bilateral
 * illumination disagreement cause abstention. This cannot recover true color from arbitrary light.
 */
export function sampleSkin(image:Pixels,points:Point[]):SkinSample|null {
 if(points.length<468||image.data.length!==image.width*image.height*4)return null;
 const p=points.map(q=>({x:q.x*image.width,y:q.y*image.height}));
 if(p.some(q=>!Number.isFinite(q.x)||!Number.isFinite(q.y)))return null;
 const radius=Math.max(2,Math.round(Math.hypot(p[33].x-p[133].x,p[33].y-p[133].y)*.28));
 const patches:Rgb[]=[];let clipped=0,sampled=0;
 for(const [a,b,mouth] of [[33,133,61],[362,263,291]]) {
  const eye={x:(p[a].x+p[b].x)/2,y:(p[a].y+p[b].y)/2};
  const center={x:eye.x*.65+p[mouth].x*.35,y:eye.y*.5+p[mouth].y*.5};
  const channels:[number[],number[],number[]]=[[],[],[]];
  for(let y=Math.max(0,Math.floor(center.y-radius));y<=Math.min(image.height-1,Math.ceil(center.y+radius));y++)for(let x=Math.max(0,Math.floor(center.x-radius));x<=Math.min(image.width-1,Math.ceil(center.x+radius));x++) {
   if((x-center.x)**2+(y-center.y)**2>radius**2)continue;
   const i=(y*image.width+x)*4,[r,g,b,alpha]=image.data.subarray(i,i+4);
   if(alpha!==255)continue;sampled++;if(r>=252||g>=252||b>=252)clipped++;
   if((r>248&&g>248&&b>248)||(r<8&&g<8&&b<8))continue;
   channels[0].push(r);channels[1].push(g);channels[2].push(b);
  }
  if(channels[0].length>=8)patches.push(channels.map(diffuse) as Rgb);
 }
 if(patches.length!==2)return null;
 const spread=Math.hypot(...patches[0].map((v,i)=>v-patches[1][i]));
 return {rgb:patches[0].map((v,i)=>Math.round((v+patches[1][i])/2)) as Rgb,reliable:spread<65&&clipped/Math.max(1,sampled)<.2};
}
/** Match the observed photo color to existing art palettes. Lighting is not inferred or corrected. */
export function nearestSkin(rgb:Rgb,palettes:{id:string;color:string}[]):string {
 if(rgb.length!==3||rgb.some(v=>!Number.isFinite(v)||v<0||v>255))throw Error('Invalid skin sample');
 const ranked=palettes.map(p=>{
  const channels=p.color.startsWith('#')&&/^#[a-f\d]{6}$/i.test(p.color)?[1,3,5].map(i=>parseInt(p.color.slice(i,i+2),16)):/^rgb\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)$/.test(p.color)?p.color.match(/\d+/g)!.map(Number):[];
  if(channels.length!==3||channels.some(v=>v>255))throw Error('Invalid skin palette');
  return {id:p.id,distance:channels.reduce((sum,v,i)=>sum+(v-rgb[i])**2,0)};
 }).sort((a,b)=>a.distance-b.distance||a.id.localeCompare(b.id));
 if(!ranked.length)throw Error('Skin palettes unavailable');return ranked[0].id;
}
