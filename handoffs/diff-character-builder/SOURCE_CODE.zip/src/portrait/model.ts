import {z} from 'zod';
import {AtelierConfigSchema,DEFAULT_ATELIER,type AtelierManifest,type Cosmetic,type ImageLayer} from '../atelier/model.js';
export const PORTRAIT_SLOTS=['head','hair','eyes','brows','nose','mouth','ears','top','jacket','bottom','shoes','hat','glasses','earrings'] as const;
export type PortraitSlot=typeof PORTRAIT_SLOTS[number];
export const PortraitConfigSchema=AtelierConfigSchema.extend({version:z.literal(3),pack:z.literal('atelier-r3'),equipment:AtelierConfigSchema.shape.equipment.extend({head:z.string().regex(/^head\.[a-z_]+$/)})}).strict();
export type PortraitConfig=z.infer<typeof PortraitConfigSchema>;
export interface PortraitCosmetic extends Omit<Cosmetic,'slot'>{slot:PortraitSlot}
export interface PortraitManifest extends Omit<AtelierManifest,'version'|'pack'|'cosmetics'>{version:3;pack:'atelier-r3';cosmetics:PortraitCosmetic[];inherited:Record<string,string>;faceSources:Record<string,{file:string;frame:[number,number,number,number];parts:Record<string,[number,number,number,number]>}>}
export const DEFAULT_PORTRAIT:PortraitConfig={...DEFAULT_ATELIER,version:3,pack:'atelier-r3',equipment:{...DEFAULT_ATELIER.equipment,head:'head.soft_oval',eyes:'eyes.reference_neutral',brows:'brows.reference_neutral',nose:'nose.reference_neutral',mouth:'mouth.reference_neutral',ears:'ears.small'}};
export function validatePortrait(input:unknown,m:PortraitManifest):PortraitConfig{const c=PortraitConfigSchema.parse(input);for(const slot of PORTRAIT_SLOTS){const id=c.equipment[slot];if(id){const a=m.cosmetics.find(a=>a.id===id);if(!a||a.slot!==slot)throw new Error(`Invalid ${slot}: ${id}`);}}return c;}
export function portraitPresets(){return [
 {id:'navy',name:'Night shift',detail:'Deep navy. Clear focus.',config:DEFAULT_PORTRAIT},
 {id:'quarter',name:'Clean quarter zip',detail:'A softer everyday.',config:{...DEFAULT_PORTRAIT,equipment:{...DEFAULT_PORTRAIT.equipment,top:'top.quarter'}}},
 {id:'hoodie',name:'Build night',detail:'Black hoodie. One more idea.',config:{...DEFAULT_PORTRAIT,equipment:{...DEFAULT_PORTRAIT.equipment,top:'top.hoodie',bottom:'bottom.black'}}},
 {id:'sport',name:'Off duty',detail:'Forest green, easy fit.',config:{...DEFAULT_PORTRAIT,equipment:{...DEFAULT_PORTRAIT.equipment,top:'top.forest_hoodie',bottom:'bottom.track'}}}
 ];}
export type {ImageLayer};
