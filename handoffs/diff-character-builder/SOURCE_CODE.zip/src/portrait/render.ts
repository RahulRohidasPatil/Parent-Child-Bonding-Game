import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {Raster,decodePng,encodePng} from '../avatar/raster.js';
import {validatePortrait,PortraitManifest,PORTRAIT_SLOTS,ImageLayer} from './model.js';
const ROOT=resolve('assets/avatar/atelier-r3');
let metadata:Promise<PortraitManifest>|undefined;
const loaded=new Map<string,Promise<Raster>>(),composites=new Map<string,Buffer>();
export function portraitManifest():Promise<PortraitManifest>{return metadata??=readFile(resolve(ROOT,'manifest.json'),'utf8').then(raw=>JSON.parse(raw));}
async function image(file:string):Promise<Raster>{let pending=loaded.get(file);if(!pending){pending=readFile(resolve(ROOT,file)).then(bytes=>{const r=decodePng(bytes);if(r.width!==128||r.height!==128||r.partialAlphaPixels())throw new Error('Invalid layer '+file);return r;}).catch(e=>{loaded.delete(file);throw e;});loaded.set(file,pending);}return pending;}
export async function renderPortrait(input:unknown,hidden:string[]=[]){
 const m=await portraitManifest(),c=validatePortrait(input,m);if(hidden.some(s=>s!=='body'&&!PORTRAIT_SLOTS.includes(s as typeof PORTRAIT_SLOTS[number])))throw new Error('Invalid hidden slot');
 const revision=createHash('sha256').update(JSON.stringify(m)).digest('hex');
 const hash=createHash('sha256').update(JSON.stringify({revision,config:c,hidden:[...new Set(hidden)].sort()})).digest('hex').slice(0,24);
 const layers:ImageLayer[]=[];if(!hidden.includes('body'))layers.push(m.skins.find(s=>s.id===c.skin)!.layer);
 for(const slot of PORTRAIT_SLOTS){const id=c.equipment[slot];if(id&&!hidden.includes(slot))layers.push(...m.cosmetics.find(a=>a.id===id)!.layers);}layers.sort((a,b)=>a.z-b.z);
 const files=layers.map(l=>l.skinVariants?.[c.skin]??l.file),cached=composites.get(hash);if(cached)return{png:cached,hash,layers:files};
 const masks:Record<string,Raster[]>={};for(const l of layers)for(const spec of l.hide??[]){const [region,id]=spec.split(':');if(!m.masks[id])throw new Error('Missing mask '+id);(masks[region]??=[]).push(await image(m.masks[id]));}
 const out=new Raster(128,128);for(const l of layers){const r=await image(l.skinVariants?.[c.skin]??l.file),occlusion=masks[l.region];out.blit(r,occlusion?(x,y)=>occlusion.some(mask=>mask.pixel(x,y)[3]===255):undefined);}
 const png=encodePng(out);if(composites.size>=512)composites.delete(composites.keys().next().value!);composites.set(hash,png);return{png,hash,layers:files};
}
