import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION} from '../../src/collection/model.js';
import {decodePng} from '../../src/avatar/raster.js';

test('twenty distinct Imagegen garments are published with valid color layers and stable rig geometry',async()=>{
 const jobs=JSON.parse(await readFile('references/avatar-wardrobe-two/prompts.json','utf8')).jobs,m=await collectionManifest();
 assert.equal(jobs.length,20);assert.equal(new Set(jobs.map((j:{id:string})=>j.id)).size,20);
 const sources=new Set<string>();
 for(const j of jobs){const item=m.cosmetics.find(c=>c.id===j.id);assert.ok(item,j.id);assert.equal(item.slot,j.kind);assert.equal(item.name,j.name);assert.ok(item.layers.some(l=>l.recolor?.family==='wear'));
  const source=await readFile('references/avatar-wardrobe-two/'+j.source);sources.add(createHash('sha256').update(source).digest('hex'));
  const c=structuredClone(DEFAULT_COLLECTION);c.equipment[item.slot]=item.id;const original=await renderCollection(c);assert.deepEqual(original.warnings,[]);
  c.wearColors[j.kind as 'top'|'jacket'|'bottom']='wear.red';const colored=await renderCollection(c);assert.deepEqual(colored.warnings,[]);assert.notDeepEqual(original.png,colored.png);
  const a=decodePng(original.png),b=decodePng(colored.png);assert.equal(a.width,128);assert.equal(a.height,128);assert.equal(b.partialAlphaPixels(),0);
  for(let i=3;i<a.data.length;i+=4)assert.equal(a.data[i],b.data[i],j.id+' alpha');
 }
 assert.equal(sources.size,20,'Distinct source artwork, not palette-only duplicates');
 for(const [slot,count]of [['top',8],['jacket',6],['bottom',6]])assert.equal(jobs.filter((j:{kind:string})=>j.kind===slot).length,count);
});
