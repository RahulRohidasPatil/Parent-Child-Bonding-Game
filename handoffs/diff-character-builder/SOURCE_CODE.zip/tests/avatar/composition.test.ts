import test from 'node:test';
import assert from 'node:assert/strict';
import { CHECKPOINT_VARIANTS } from '../../src/avatar/schema.js';
import { renderAvatar } from '../../src/avatar/renderer.js';
import { SLOT_MASKS } from '../../src/avatar/rig.js';

const allowedByVariant: Record<string, Array<keyof typeof SLOT_MASKS>> = {
  variant_a_cap: ['headwear', 'hair_front'],
  variant_b_beanie: ['headwear', 'hair_front'],
  variant_c_track_jacket: ['outerwear'],
  variant_d_long_wavy: ['hair_back', 'hair_front'],
  variant_e_glasses: ['glasses'],
  variant_f_track_pants: ['bottoms'],
};

test('each checkpoint variant changes only its declared module regions', async () => {
  const base = (await renderAvatar(CHECKPOINT_VARIANTS.base)).raster;
  for (const [name, slots] of Object.entries(allowedByVariant)) {
    const variant = (await renderAvatar(CHECKPOINT_VARIANTS[name])).raster;
    let changed = 0;
    for (let y = 0; y < 128; y += 1) for (let x = 0; x < 128; x += 1) {
      const different = base.pixel(x, y).some((value, index) => value !== variant.pixel(x, y)[index]);
      if (!different) continue;
      changed += 1;
      assert.ok(slots.some((slot) => SLOT_MASKS[slot].containsLogical(Math.floor(x / 2), Math.floor(y / 2))), `${name} changed forbidden pixel ${x},${y}`);
    }
    assert.ok(changed > 0, `${name} made no visual change`);
  }
});
