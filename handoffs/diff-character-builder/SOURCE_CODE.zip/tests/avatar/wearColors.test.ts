import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {collectionManifest,renderCollection,renderCollectionLayer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,CollectionConfigSchema,type CollectionConfig} from '../../src/collection/model.js';
import {WEAR_SLOTS,WEAR_COLOR_IDS,DEFAULT_WEAR_COLORS,type WearSlot} from '../../src/collection/wearPalettes.js';
import {Raster,decodePng} from '../../src/avatar/raster.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';
const root='assets/avatar/atelier-r6/';
const config=(slot:WearSlot,id:string):CollectionConfig=>({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,[slot]:id,...(slot==='tie'?{top:'top.dress_white'}:{})}});
test('50 distinct source items include 26 new footwear models and preserve the approved default',async()=>{
 const m=await collectionManifest(),jobs=JSON.parse(await readFile('references/avatar-wardrobe-expansion/prompts.json','utf8')).jobs;
 assert.equal(jobs.length,50);assert.equal(jobs.filter((j:{kind:string})=>j.kind==='shoes').length,26);const hashes=new Set<string>();
 for(const j of jobs){const c=m.cosmetics.find(c=>c.id===j.id)!;assert.ok(c,j.id);assert.ok(c.layers.every(l=>(l.source.startsWith('references/avatar-wardrobe-expansion/')||l.source.startsWith('references/avatar-polish/'))));hashes.add(createHash('sha256').update(Buffer.concat(await Promise.all(c.layers.map(l=>readFile(root+l.file))))).digest('hex'));}
 assert.equal(hashes.size,50);assert.deepEqual((await renderCollection(DEFAULT_COLLECTION)).png,await readFile(root+m.master));
});
test('all wearables have 18 distinct colorways; tinting preserves alpha and pixels outside the material mask',async()=>{
 const m=await collectionManifest();for(const item of m.cosmetics.filter(c=>WEAR_SLOTS.includes(c.slot as WearSlot)&&!c.fixedColors)){
  const c=config(item.slot as WearSlot,item.id),colors=new Set<string>();
  for(const color of WEAR_COLOR_IDS){const tinted={...c,wearColors:{...c.wearColors,[item.slot]:color}},images=[];
   for(let index=0;index<item.layers.length;index++){
    const l=item.layers[index],original=decodePng(await renderCollectionLayer(c,item.slot,index)),mask=l.recolor?decodePng(await readFile(root+l.recolor.mask)):new Raster(128,128),bytes=await renderCollectionLayer(tinted,item.slot,index),p=decodePng(bytes);images.push(bytes);
    for(let i=0;i<16384;i++){assert.equal(p.data[i*4+3],original.data[i*4+3],item.id+' alpha');if(!mask.data[i*4+3]||!mask.data[i*4])assert.deepEqual(p.data.subarray(i*4,i*4+4),original.data.subarray(i*4,i*4+4),item.id+' protected material');}
   }colors.add(createHash('sha256').update(Buffer.concat(images)).digest('hex'));
  }assert.equal(colors.size,18,item.id+' lacks color variation');
 }
});
test('color schema migrates old drafts, rejects invalid palettes and keeps slots independent',async()=>{
 const {wearColors,...legacy}=DEFAULT_COLLECTION;assert.deepEqual(CollectionConfigSchema.parse(legacy).wearColors,DEFAULT_WEAR_COLORS);
 assert.equal(CollectionConfigSchema.safeParse({...DEFAULT_COLLECTION,wearColors:{...wearColors,shoes:'hair.black'}}).success,false);
 assert.equal(CollectionConfigSchema.safeParse({...DEFAULT_COLLECTION,wearColors:{...wearColors,body:'wear.red'}}).success,false);
 const c={...DEFAULT_COLLECTION,wearColors:{...wearColors,shoes:'wear.red' as const}};assert.deepEqual(await renderCollectionLayer(c,'top'),await renderCollectionLayer(DEFAULT_COLLECTION,'top'));assert.notDeepEqual(await renderCollectionLayer(c,'shoes'),await renderCollectionLayer(DEFAULT_COLLECTION,'shoes'));
 const noShoes={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,shoes:null}};assert.equal((await renderCollection(noShoes)).hash,(await renderCollection({...noShoes,wearColors:c.wearColors})).hash);
});
test('all new shoes share baseline 122 and new garments leave the face untouched',async()=>{
 const m=await collectionManifest();for(const item of m.cosmetics.filter(c=>c.layers.some(l=>l.source.includes('wardrobe-expansion')))){
  for(const l of item.layers){const p=decodePng(await readFile(root+l.file));for(let y=0;y<32;y++)for(let x=0;x<128;x++)assert.equal(p.pixel(x,y)[3],0,item.id+' touches face');
   if(item.slot==='shoes'){for(const [lo,hi]of [[47,63],[66,82]]){let bottom=-1;for(let y=0;y<128;y++)for(let x=lo;x<=hi;x++)if(p.pixel(x,y)[3])bottom=Math.max(bottom,y);assert.equal(bottom,122,item.id+' foot baseline');}}
  }
 }
});
test('wear palette catalog, colored layer and source-art routes are available',async()=>{
 const server=createStudioServer();await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+(server.address() as {port:number}).port;
 try{const catalog=await(await fetch(base+'/api/collection/catalog')).json();assert.equal(catalog.wearColors.length,18);const c={...config('shoes','shoes.penny_loafer'),wearColors:{...DEFAULT_WEAR_COLORS,shoes:'wear.brown' as const}},q=new URLSearchParams({config:JSON.stringify(c),slot:'shoes',index:'0'}),response=await fetch(base+'/api/collection/layer?'+q);assert.equal(response.status,200);assert.deepEqual(Buffer.from(await response.arrayBuffer()),await renderCollectionLayer(c,'shoes'));assert.equal((await fetch(base+'/references/avatar-wardrobe-expansion/shoes_penny_loafer.png')).status,200);}finally{server.closeAllConnections();await new Promise<void>(r=>server.close(()=>r()));}
});

test('new open jackets expose the equipped top through the shared opening',async()=>{
 const m=await collectionManifest(),jobs=JSON.parse(await readFile('references/avatar-wardrobe-expansion/prompts.json','utf8')).jobs;
 for(const j of jobs.filter((j:{kind:string;closed?:boolean})=>j.kind==='jacket'&&!j.closed)){const item=m.cosmetics.find(c=>c.id===j.id)!;for(const l of item.layers.filter(l=>l.z>20)){const p=decodePng(await readFile(root+l.file));for(let y=43;y<74;y++)for(let x=61;x<68;x++)assert.equal(p.pixel(x,y)[3],0,j.id+' center');}}
});
test('dark navy track-jacket folds retain tonal contrast in light colorways',async()=>{
 const m=await collectionManifest(),item=m.cosmetics.find(c=>c.id==='jacket.navy_track')!,c={...config('jacket',item.id),wearColors:{...DEFAULT_WEAR_COLORS,jacket:'wear.cream' as const}},colors=new Set<string>();
 for(let index=0;index<item.layers.length;index++){const l=item.layers[index];if(!l.recolor)continue;const p=decodePng(await renderCollectionLayer(c,'jacket',index)),mask=decodePng(await readFile(root+l.recolor.mask));for(let i=0;i<16384;i++)if(mask.data[i*4+3])colors.add([...p.data.subarray(i*4,i*4+3)].join(','));}
 assert.ok(colors.size>=8,'Recoloring collapsed dark folds into a flat fill');
});
