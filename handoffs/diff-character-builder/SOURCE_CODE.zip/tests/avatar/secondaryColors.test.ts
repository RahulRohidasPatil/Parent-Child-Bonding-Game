import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {collectionManifest,renderCollection,renderCollectionLayer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,CollectionConfigSchema,type CollectionConfig} from '../../src/collection/model.js';
import {WEAR_COLOR_IDS,DEFAULT_WEAR_COLORS,WEAR_SLOTS,type WearSlot} from '../../src/collection/wearPalettes.js';
import {decodePng,Raster} from '../../src/avatar/raster.js';
import {randomCollection} from '../../scripts/avatar/validateCollection.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';
const root='assets/avatar/atelier-r6/';
test('old configs retain original detail behavior and strict secondary color validation',async()=>{
 const {wearAccentColors,...old}=DEFAULT_COLLECTION;assert.deepEqual(CollectionConfigSchema.parse(old).wearAccentColors,DEFAULT_WEAR_COLORS);
 assert.equal(CollectionConfigSchema.safeParse({...DEFAULT_COLLECTION,wearAccentColors:{...wearAccentColors,shoes:'hair.black'}}).success,false);
 assert.equal(CollectionConfigSchema.safeParse({...DEFAULT_COLLECTION,wearAccentColors:{...wearAccentColors,unknown:'wear.red'}}).success,false);
 assert.deepEqual((await renderCollection(old)).png,await readFile(root+'rig/reference_master.png'));
});
test('all clothing and footwear expose detail colors that preserve alpha and all pixels outside their mask',async()=>{
 const m=await collectionManifest();for(const item of m.cosmetics.filter(c=>['top','jacket','bottom','shoes'].includes(c.slot)&&!c.fixedColors)){
  assert.ok(item.layers.some(l=>l.accentMask),item.id+' has no detail mask');
  const c:CollectionConfig={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,[item.slot]:item.id},wearColors:{...DEFAULT_WEAR_COLORS,[item.slot]:'wear.navy'}},hashes=new Set<string>();
  for(const color of WEAR_COLOR_IDS){const tinted={...c,wearAccentColors:{...DEFAULT_WEAR_COLORS,[item.slot]:color}},buffers=[];
   for(let index=0;index<item.layers.length;index++){const l=item.layers[index],base=decodePng(await renderCollectionLayer(c,item.slot,index)),bytes=await renderCollectionLayer(tinted,item.slot,index),p=decodePng(bytes),mask=l.accentMask?decodePng(await readFile(root+l.accentMask)):new Raster(128,128);buffers.push(bytes);
    for(let i=0;i<16384;i++){assert.equal(p.data[i*4+3],base.data[i*4+3]);if(!mask.data[i*4+3])assert.deepEqual(p.data.subarray(i*4,i*4+4),base.data.subarray(i*4,i*4+4),item.id+' changed main material');}
   }hashes.add(createHash('sha256').update(Buffer.concat(buffers)).digest('hex'));
  }assert.ok(hashes.size>=17,item.id+' lacks distinct detail colors');
 }
});
test('detail selection stays fixed while main color changes; unused detail choices do not affect hashes',async()=>{
 const c={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,shoes:'shoes.court_high'},wearAccentColors:{...DEFAULT_WEAR_COLORS,shoes:'wear.red' as const}},m=await collectionManifest(),l=m.cosmetics.find(c=>c.id==='shoes.court_high')!.layers[0],mask=decodePng(await readFile(root+l.accentMask!));
 const a=decodePng(await renderCollectionLayer(c,'shoes')),b=decodePng(await renderCollectionLayer({...c,wearColors:{...DEFAULT_WEAR_COLORS,shoes:'wear.forest'}},'shoes'));
 for(let i=0;i<16384;i++)if(mask.data[i*4+3])assert.deepEqual(a.data.subarray(i*4,i*4+4),b.data.subarray(i*4,i*4+4));
 const none={...c,equipment:{...c.equipment,shoes:null}};assert.equal((await renderCollection(none)).hash,(await renderCollection({...none,wearAccentColors:DEFAULT_WEAR_COLORS})).hash);
});
test('5000 seeded combinations with independent primary/detail colors render deterministically without fallback',async()=>{
 const m=await collectionManifest();for(let i=0;i<5000;i++){const c=randomCollection(m,93000+i);for(let k=0;k<WEAR_SLOTS.length;k++)c.wearAccentColors[WEAR_SLOTS[k]]=WEAR_COLOR_IDS[(i*7+k*11)%WEAR_COLOR_IDS.length];const r=await renderCollection(c);assert.equal(r.warnings.length,0);const p=decodePng(r.png);assert.equal(p.partialAlphaPixels(),0);if(i%500===0)assert.deepEqual(await renderCollection(c),r);}
});
test('inspector and export HTTP endpoints use both color channels',async()=>{
 const server=createStudioServer();await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+(server.address() as {port:number}).port,c={...DEFAULT_COLLECTION,wearColors:{...DEFAULT_WEAR_COLORS,shoes:'wear.forest' as const},wearAccentColors:{...DEFAULT_WEAR_COLORS,shoes:'wear.red' as const}};
 try{const q=new URLSearchParams({config:JSON.stringify(c),slot:'shoes',index:'0'}),response=await fetch(base+'/api/collection/layer?'+q);assert.equal(response.status,200);assert.deepEqual(Buffer.from(await response.arrayBuffer()),await renderCollectionLayer(c,'shoes'));const r=await fetch(base+'/api/collection/render?'+new URLSearchParams({config:JSON.stringify(c)}));assert.deepEqual(Buffer.from(await r.arrayBuffer()),(await renderCollection(c)).png);}finally{server.closeAllConnections();await new Promise<void>(r=>server.close(()=>r()));}
});
