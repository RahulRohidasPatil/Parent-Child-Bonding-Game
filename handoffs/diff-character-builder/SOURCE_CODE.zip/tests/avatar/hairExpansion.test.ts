import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION} from '../../src/collection/model.js';
import {HAIR_COLOR_IDS} from '../../src/collection/hairPalettes.js';
import {decodePng} from '../../src/avatar/raster.js';
const root='assets/avatar/atelier-r6/';
test('twenty distinct Imagegen styles supplement the seven existing hairstyles',async()=>{
 const m=await collectionManifest(),jobs=JSON.parse(await readFile('references/avatar-hair-expansion/prompts.json','utf8')).jobs;
 assert.equal(jobs.length,20);assert.equal(new Set(jobs.map((j:{id:string})=>j.id)).size,20);assert.equal(m.cosmetics.filter(c=>c.slot==='hair').length,100);
 const hashes=new Set<string>();for(const j of jobs){const c=m.cosmetics.find(c=>c.id===j.id)!;assert.ok(c,j.id);assert.ok(c.layers.every(l=>l.source.startsWith('references/avatar-hair-expansion/')));hashes.add(createHash('sha256').update(Buffer.concat(await Promise.all(c.layers.map(l=>readFile(root+l.file))))).digest('hex'));if(j.group!=='Short'){assert.ok(c.layers.some(l=>l.region==='hair_back'));assert.ok(c.layers.some(l=>l.region==='hair_front'));}}
 assert.equal(hashes.size,20);
});
test('new front hair never paints the shared eyes, brows, nose or mouth area',async()=>{
 const m=await collectionManifest(),jobs=JSON.parse(await readFile('references/avatar-hair-expansion/prompts.json','utf8')).jobs;
 for(const j of jobs){const c=m.cosmetics.find(c=>c.id===j.id)!;for(const l of c.layers.filter(l=>l.region==='hair_front')){const p=decodePng(await readFile(root+l.file));for(let y=18;y<=34;y++)for(let x=55;x<=73;x++)assert.equal(p.pixel(x,y)[3],0,j.id+' covers face');}}
});
test('every hairstyle supports twelve distinct deterministic colors without changing silhouette',async()=>{
 const m=await collectionManifest();
 for(const hair of m.cosmetics.filter(c=>c.slot==='hair')){
  const c={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hair:hair.id}},original=decodePng((await renderCollection(c)).png),hashes=new Set<string>();
  const masks=await Promise.all(hair.layers.map(l=>readFile(root+l.recolor!.mask).then(decodePng)));
  for(const hairColor of HAIR_COLOR_IDS){const result=await renderCollection({...c,hairColor});assert.equal(result.warnings.length,0);hashes.add(createHash('sha256').update(result.png).digest('hex'));const p=decodePng(result.png);
   for(let i=0;i<16384;i++){assert.equal(p.data[i*4+3],original.data[i*4+3]);if(!masks.some(mask=>mask.data[i*4+3]&&mask.data[i*4]))assert.deepEqual(p.data.subarray(i*4,i*4+4),original.data.subarray(i*4,i*4+4),hair.id+' recolored a protected pixel');}
  }assert.equal(hashes.size,12,hair.id+' lacks distinct palettes');
 }
});
test('all head, hairstyle and hat combinations retain visible eye pixels and valid resources',async()=>{
 const m=await collectionManifest(),eye=m.cosmetics.find(c=>c.id===DEFAULT_COLLECTION.equipment.eyes)!,eyes=decodePng(await readFile(root+eye.layers[0].file));
 for(const head of m.cosmetics.filter(c=>c.slot==='head'))for(const hair of m.cosmetics.filter(c=>c.slot==='hair'))for(const hat of [null,...m.cosmetics.filter(c=>c.slot==='hat').map(c=>c.id)]){
  const result=await renderCollection({...DEFAULT_COLLECTION,hairColor:'hair.platinum',equipment:{...DEFAULT_COLLECTION.equipment,head:head.id,hair:hair.id,hat}});assert.equal(result.warnings.length,0);const p=decodePng(result.png);
  for(let y=20;y<=22;y++)for(let x=57;x<=71;x++)if(eyes.pixel(x,y)[3])assert.deepEqual(p.pixel(x,y),eyes.pixel(x,y),head.id+' / '+hair.id+' / '+hat+' hides eyes');
 }
});
