import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile,mkdir,mkdtemp,writeFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {EditorAsyncState,withDeadline} from '../../src/atelier/asyncState.js';
import {AtelierHistory} from '../../src/atelier/history.js';
import {createCollectionRenderer,collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION} from '../../src/collection/model.js';
import {decodePng} from '../../src/avatar/raster.js';
import {uncoveredPixels} from '../../src/collection/coverage.js';
import {publishValidatedPack} from '../../scripts/avatar/publishPack.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';
const root='assets/avatar/atelier-r6';

test('old render/save completions cannot unlock or replace an unfinished latest preview',()=>{
 const state=new EditorAsyncState(),first=state.beginRender();state.finishRender(first,true);assert.ok(state.beginSave());
 const second=state.beginRender();state.finishSave();assert.equal(state.canSave,false);assert.equal(state.canExport,false);
 assert.equal(state.finishRender(first,true),false);assert.equal(state.canExport,false);
 state.finishRender(second,true);assert.ok(state.canSave);assert.ok(state.beginSave());assert.equal(state.beginSave(),false);
 state.finishSave();const failed=state.beginRender();state.finishRender(failed,false);assert.equal(state.canSave,false);
});
test('stalled work times out and cancellation propagates instead of leaving a permanent spinner',async()=>{
 const waitsForAbort=(signal:AbortSignal)=>new Promise<void>((_,reject)=>{if(signal.aborted)reject(new Error('aborted'));else signal.addEventListener('abort',()=>reject(new Error('aborted')),{once:true});});
 await assert.rejects(()=>withDeadline(waitsForAbort,undefined,5),/took too long/);
 const controller=new AbortController();const pending=withDeadline(waitsForAbort,controller.signal);controller.abort();await assert.rejects(()=>pending,/aborted/);
 assert.equal(await withDeadline(async()=>42),42);
});
test('equivalent config property order does not create fake undo history',()=>{
 const history=new AtelierHistory(DEFAULT_COLLECTION);assert.equal(history.commit(Object.fromEntries(Object.entries(DEFAULT_COLLECTION).reverse()) as typeof DEFAULT_COLLECTION),false);assert.equal(history.canUndo,false);
});
test('a failed jacket drops only that slot, applies no stale mask, and recovers on retry',async()=>{
 const m=await collectionManifest(),c={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,jacket:'jacket.diff_track'}};
 const failed=m.cosmetics.find(a=>a.id===c.equipment.jacket)!.layers.at(-1)!.file;let broken=true;const logs:string[]=[];
 const renderer=createCollectionRenderer(root,{loadFile:async file=>{if(file===failed&&broken)throw new Error('fixture missing image');return readFile(join(root,file));},log:m=>logs.push(m)});
 const first=await renderer.render(c);assert.deepEqual(first.png,(await renderCollection(DEFAULT_COLLECTION)).png);assert.deepEqual(first.warnings,[{slot:'jacket',requestedId:'jacket.diff_track',fallbackId:null}]);assert.equal(logs.length,1);
 broken=false;const second=await renderer.render(c);assert.equal(second.warnings.length,0);assert.deepEqual(second.png,(await renderCollection(c)).png);assert.notEqual(second.hash,first.hash);
});
test('a partial long-hair load falls back as one slot without leaving its rear component',async()=>{
 const m=await collectionManifest(),hair=m.cosmetics.find(a=>a.id==='hair.long')!;assert.ok(hair);
 const c={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hair:hair.id}};
 const renderer=createCollectionRenderer(root,{loadFile:file=>file===hair.layers.at(-1)!.file?Promise.reject(new Error('missing front')):readFile(join(root,file)),log:()=>{}});
 const r=await renderer.render(c);assert.deepEqual(r.png,(await renderCollection(DEFAULT_COLLECTION)).png);assert.equal(r.warnings[0].fallbackId,DEFAULT_COLLECTION.equipment.hair);
});
test('a missing hat mask removes the hat without masking the existing hair',async()=>{
 const m=await collectionManifest(),hat=m.cosmetics.find(a=>a.slot==='hat')!,key=hat.layers[0].hide![0].split(':')[1];
 const renderer=createCollectionRenderer(root,{loadFile:file=>file===m.masks[key]?Promise.reject(new Error('missing mask')):readFile(join(root,file)),log:()=>{}});
 const r=await renderer.render({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hat:hat.id}});assert.deepEqual(r.png,(await renderCollection(DEFAULT_COLLECTION)).png);assert.equal(r.warnings[0].slot,'hat');
});
test('export snapshots stay byte-identical to a degraded preview after its asset recovers',async()=>{
 const m=await collectionManifest(),file=m.cosmetics.find(c=>c.id==='jacket.diff_track')!.layers.at(-1)!.file;let broken=true;
 const renderer=createCollectionRenderer(root,{loadFile:f=>f===file&&broken?Promise.reject(new Error('missing jacket')):readFile(join(root,f)),log:()=>{}});
 const server=createStudioServer({collectionRender:renderer.render});await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const url='http://127.0.0.1:'+(server.address() as {port:number}).port;
 try{
  const c={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,jacket:'jacket.diff_track'}};
  const first=await fetch(url+'/api/collection/render',{method:'POST',body:JSON.stringify(c)}),hash=first.headers.get('x-avatar-hash'),png=Buffer.from(await first.arrayBuffer());
  assert.equal(JSON.parse(decodeURIComponent(first.headers.get('x-avatar-warnings')!)).length,1);
  broken=false;const recovered=await fetch(url+'/api/collection/render',{method:'POST',body:JSON.stringify(c)});assert.notEqual(recovered.headers.get('x-avatar-hash'),hash);await recovered.arrayBuffer();
  const snapshot=await fetch(url+'/api/collection/snapshot/'+hash+'.png');assert.equal(snapshot.status,200);assert.match(snapshot.headers.get('content-disposition')!,/attachment/);assert.deepEqual(Buffer.from(await snapshot.arrayBuffer()),png);
 }finally{server.closeAllConnections();await new Promise<void>((r,e)=>server.close(err=>err?e(err):r()));}
});
test('all tops and jackets cover their required waist region while open jacket centers stay open',async()=>{
 const m=await collectionManifest();for(const c of m.cosmetics.filter(c=>['top','jacket'].includes(c.slot))){const fronts=c.layers.filter(l=>l.z>20);const mask=decodePng(await readFile(join(root,m.coverageMasks![fronts[0].waistCoverage!])));assert.deepEqual(uncoveredPixels(mask,await Promise.all(fronts.map(async l=>decodePng(await readFile(join(root,l.file)))))),[],c.id);}
});
test('invalid staged builds cannot replace the working pack',async()=>{
 const folder=await mkdtemp(join(tmpdir(),'diff-publish-test-'));try{
  const current=join(folder,'current'),staged=join(folder,'staged');await mkdir(current);await mkdir(staged);await writeFile(join(current,'image.png'),'old picture');await writeFile(join(staged,'image.png'),'invalid picture');
  await assert.rejects(()=>publishValidatedPack(staged,current,join(folder,'archive'),async()=>{throw new Error('invalid mask');}),/invalid mask/);
  assert.equal(await readFile(join(current,'image.png'),'utf8'),'old picture');assert.equal(await readFile(join(staged,'image.png'),'utf8'),'invalid picture');
 }finally{await rm(folder,{recursive:true,force:true});}
});
test('successful pack publication preserves the previous images in its archive',async()=>{
 const folder=await mkdtemp(join(tmpdir(),'diff-publish-test-'));try{
  const current=join(folder,'current'),staged=join(folder,'staged');await mkdir(current);await mkdir(staged);await writeFile(join(current,'image.png'),'old picture');await writeFile(join(staged,'image.png'),'new picture');
  const archive=await publishValidatedPack(staged,current,join(folder,'archive'),async()=>true);assert.equal(await readFile(join(current,'image.png'),'utf8'),'new picture');assert.equal(await readFile(join(archive!,'image.png'),'utf8'),'old picture');
 }finally{await rm(folder,{recursive:true,force:true});}
});
