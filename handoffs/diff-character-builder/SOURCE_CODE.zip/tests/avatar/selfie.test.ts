import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {measureFace,type Point,type FaceMetrics} from '../../src/selfie/measure.js';
import {suggestFaces,applyFaceSuggestion} from '../../src/selfie/matcher.js';
import {FACE_PROFILES} from '../../src/selfie/profiles.js';
import {localAssetFetch} from '../../src/selfie/network.js';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,collectionPresets,validateCollection} from '../../src/collection/model.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';

// A frontal mesh fixture in image pixels. It exercises measurement invariance, not face detection.
function mesh():Point[] {
 const p=Array.from({length:478},()=>({x:250,y:250}));
 const set=(i:number,x:number,y:number)=>p[i]={x,y};
 for(const [i,x,y] of [[10,250,100],[152,250,380],[234,150,245],[454,350,245],[172,180,335],[397,320,335],[33,185,220],[133,225,220],[362,275,220],[263,315,220],[159,205,215],[145,205,225],[386,295,215],[374,295,225],[70,180,202],[107,230,202],[105,205,199],[52,205,205],[300,320,202],[336,270,202],[334,295,199],[282,295,205],[1,250,270],[168,250,235],[2,250,300],[98,230,280],[327,270,280],[61,215,325],[291,285,325],[0,250,319],[17,250,335],[13,250,325],[14,250,329]])set(i,x,y);
 return p;
}
const normalized=(p:Point[],w:number,h:number)=>p.map(q=>({x:q.x/w,y:q.y/h}));
const sample:FaceMetrics={aspect:1.4,jaw:.7,eyeOpen:.25,eyeTilt:0,browArch:.05,browThickness:.03,noseWidth:.2,noseLength:.24,mouthWidth:.38,lipFullness:.16,smile:0};

test('face geometry is independent of image aspect ratio, uniform scaling and modest head roll',()=>{
 const p=mesh(),base=measureFace(normalized(p,500,500),500,500);
 const aspectCorrected=measureFace(normalized(p,600,800),600,800);
 for(const key of Object.keys(base) as (keyof FaceMetrics)[])assert.ok(Math.abs(base[key]-aspectCorrected[key])<1e-10,key);
 assert.deepEqual(measureFace(normalized(p,500,500),1000,1000),base);
 const angle=.2,turned=p.map(q=>({x:250+(q.x-250)*Math.cos(angle)-(q.y-250)*Math.sin(angle),y:250+(q.x-250)*Math.sin(angle)+(q.y-250)*Math.cos(angle)}));
 const measured=measureFace(normalized(turned,500,500),500,500);
 for(const key of Object.keys(base) as (keyof FaceMetrics)[])assert.ok(Math.abs(base[key]-measured[key])<1e-10,key);
});
test('unusable landmarks fail instead of returning fabricated or non-finite proportions',()=>{
 const p=normalized(mesh(),500,500);
 assert.throws(()=>measureFace(p.slice(0,100),500,500),/could not be measured/);
 assert.throws(()=>measureFace(p,100,100),/too small/);
 assert.throws(()=>measureFace(p,NaN,500),/could not be measured/);
 const invalid=structuredClone(p);invalid[100].x=NaN;assert.throws(()=>measureFace(invalid,500,500),/could not be measured/);
 const closed=structuredClone(p);closed[291]=closed[61];assert.throws(()=>measureFace(closed,500,500),/could not be measured/);
 const side=structuredClone(p);side[1].x=.8;assert.throws(()=>measureFace(side,500,500),/front-facing/);
 const cropped=structuredClone(p);cropped[10].y=0;assert.throws(()=>measureFace(cropped,500,500),/cut off/);
 const tilted=structuredClone(p);tilted[263].y=.65;assert.throws(()=>measureFace(tilted,500,500),/upright/);
});
test('the matcher returns three deterministic, distinct, renderable catalog combinations',async()=>{
 const m=await collectionManifest(),suggestions=suggestFaces(sample,m);
 assert.equal(suggestions.length,3);assert.deepEqual(suggestions,suggestFaces(sample,m));
 for(let i=0;i<3;i++){
  const c=validateCollection(applyFaceSuggestion(DEFAULT_COLLECTION,suggestions[i]),m);
  assert.equal((await renderCollection(c)).warnings.length,0);
  for(let j=i+1;j<3;j++)assert.ok(Object.keys(suggestions[i]).filter(k=>suggestions[i][k as keyof typeof suggestions[0]]!==suggestions[j][k as keyof typeof suggestions[0]]).length>=2);
 }
 const rounded=suggestFaces({...sample,aspect:1.12,jaw:.89},m);
 const narrow=suggestFaces({...sample,aspect:1.52,jaw:.68},m);
 assert.equal(rounded[0].head,'head.full_round');assert.equal(narrow[0].head,'head.narrow');
});
test('all face profiles exist in their correct slots and incomplete catalogs fail clearly',async()=>{
 const m=await collectionManifest();
 for(const p of FACE_PROFILES)assert.ok(m.cosmetics.some(c=>c.id===p.id&&c.slot===p.slot),p.id);
 assert.throws(()=>suggestFaces({...sample,eyeOpen:NaN},m),/Invalid face/);
 assert.throws(()=>suggestFaces(sample,{cosmetics:m.cosmetics.filter(c=>c.slot!=='nose')}),/unavailable/);
 assert.throws(()=>suggestFaces(sample,{cosmetics:m.cosmetics.filter(c=>['head.soft_oval','eyes.reference_neutral','brows.reference_neutral','nose.reference_neutral','mouth.reference_neutral'].includes(c.id))}),/Not enough/);
});
test('applying a suggestion preserves outfit, colors and personal details without mutating the input',async()=>{
 const m=await collectionManifest(),original=structuredClone(collectionPresets().find(p=>p.id==='suited')!.config);
 for(const slot of ['facialHair','freckles','birthmark','scar','ageLines','hearingAidLeft','hearingAidRight'] as const)original.equipment[slot]=m.cosmetics.find(c=>c.slot===slot)!.id;
 const before=structuredClone(original),patch=suggestFaces(sample,m)[0];
 const next=applyFaceSuggestion(original,{...patch,top:'untrusted'} as typeof patch);
 assert.deepEqual(original,before);
 for(const key of Object.keys(original) as (keyof typeof original)[])if(key!=='equipment')assert.deepEqual(next[key],original[key]);
 for(const [key,value]of Object.entries(original.equipment))if(!(key in patch))assert.equal(next.equipment[key as keyof typeof next.equipment],value,key);
 validateCollection(next,m);
});
test('model fetch permits only local immutable asset reads and blocks telemetry, uploads and redirects',async()=>{
 const requests:{url:string;init?:RequestInit}[]=[];
 const native:typeof fetch=async(input,init)=>{requests.push({url:String(input),init});return new Response('model');};
 const guarded=localAssetFetch(native,'https://diff.example');
 assert.equal(await(await guarded('/assets/selfie/v1/face_landmarker.task')).text(),'model');
 assert.equal(requests[0].init?.credentials,'omit');assert.equal(requests[0].init?.redirect,'error');
 for(const url of ['https://odml.pa.googleapis.com/v1/log','https://other.example/assets/selfie/v1/face_landmarker.task','/api/collection/render','/assets/selfie/v1/face_landmarker.task?photo=data','/assets/selfie/v1/face_landmarker.task#data'])await assert.rejects(()=>guarded(url),/cannot make/);
 await assert.rejects(()=>guarded('/assets/selfie/v1/face_landmarker.task',{method:'POST',body:'photo'}),/cannot make/);
 await assert.rejects(()=>guarded(new Request('https://diff.example/assets/selfie/v1/face_landmarker.task',{method:'POST',body:'photo'})),/cannot make/);
 assert.equal(requests.length,1);assert.equal(await(await guarded('/assets/selfie/v1/hair_segmenter.tflite')).text(),'model');
});
test('vendored runtime files match the pinned inventory and model checksum',async()=>{
 const root='assets/selfie/v1/',inventory=JSON.parse(await readFile(root+'manifest.json','utf8'));
 assert.equal(inventory.version,'1.0.1');
 for(const entry of inventory.files){const bytes=await readFile(root+entry.file);assert.equal(bytes.length,entry.bytes);assert.equal(createHash('sha256').update(bytes).digest('hex'),entry.sha256,entry.file);}
 assert.equal(inventory.files.find((f:{file:string})=>f.file==='face_landmarker.task').sha256,'64184e229b263107bc2b804c6625db1341ff2bb731874b0bcc2fe6544e0bc9ff');
 assert.match(await readFile(root+'LICENSE.txt','utf8'),/Apache License/);
});
test('server serves local runtime with safe MIME/cache/CSP and excludes test photos in production',async()=>{
 const oldEnv=process.env.NODE_ENV;process.env.NODE_ENV='production';
 const server=createStudioServer();await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+(server.address() as {port:number}).port;
 try{
  for(const [path,type]of [['wasm/vision_wasm_module_internal.wasm','application/wasm'],['vision_bundle.mjs','text/javascript'],['face_landmarker.task','application/octet-stream'],['hair_segmenter.tflite','application/octet-stream']]){
   const r=await fetch(base+'/assets/selfie/v1/'+path,{method:'HEAD'});assert.equal(r.status,200);assert.ok(r.headers.get('content-type')?.startsWith(type));assert.match(r.headers.get('cache-control')! ,/immutable/);
  }
  const worker=await fetch(base+'/dist/src/selfie/worker.js');assert.match(worker.headers.get('content-security-policy')!,/connect-src 'self'/);await worker.text();
  assert.equal((await fetch(base+'/assets/selfie/v1/face_landmarker.task',{method:'POST',body:'no uploads'})).status,405);
  for(const path of ['/dev/selfie-lab','/dev/selfie-comparison','/dev/selfie-fixture/portrait','/dev/selfie-fixture/no-face','/dev/selfie-fixture/michelle','/dev/selfie-new-photo-tests','/dev/selfie-fixture/watkins','/dev/selfie-fixture/williams','/dev/selfie-fixture/hadfield','/dev/selfie-fixture/jemison','/dev/selfie-refinement','/dev/selfie-fixture/ride','/dev/selfie-fixture/bluford'])assert.equal((await fetch(base+path)).status,404);
  const html=await(await fetch(base+'/avatar-studio')).text();assert.match(html,/Find my face/);assert.doesNotMatch(html,/data-fixture/);
 }finally{if(oldEnv===undefined)delete process.env.NODE_ENV;else process.env.NODE_ENV=oldEnv;server.closeAllConnections();await new Promise<void>(r=>server.close(()=>r()));}
});

test('cheek sampling ignores the background and maps all twelve palette colors accurately',async()=>{
 const {sampleSkin,nearestSkin}=await import('../../src/selfie/skinTone.js'),m=await collectionManifest();
 for(const palette of m.skins){
  const rgb=palette.color.match(/\d+/g)!.map(Number) as [number,number,number];
  const data=new Uint8ClampedArray(500*500*4);
  for(let i=0;i<data.length;i+=4)data.set([20,220,230,255],i);
  // Known cheek neighborhoods of the synthetic mesh; hair, eyes and background are outside them.
  for(const centerX of [208.5,291.5])for(let y=258;y<=287;y++)for(let x=Math.floor(centerX)-15;x<=Math.ceil(centerX)+15;x++)data.set([...rgb,255],(y*500+x)*4);
  const measured=sampleSkin({data,width:500,height:500},normalized(mesh(),500,500));
  assert.ok(measured?.reliable,palette.id);assert.deepEqual(measured.rgb,rgb);assert.equal(nearestSkin(measured.rgb,m.skins),palette.id);
 }
});
test('skin sampling refuses clipped or unmeasurable samples and flags uneven lighting',async()=>{
 const {sampleSkin,nearestSkin}=await import('../../src/selfie/skinTone.js');
 const data=new Uint8ClampedArray(500*500*4).fill(255),points=normalized(mesh(),500,500);
 assert.equal(sampleSkin({data,width:500,height:500},points),null);
 assert.equal(sampleSkin({data,width:500,height:500},[]),null);
 for(let y=0;y<500;y++)for(let x=0;x<500;x++)data.set(x<250?[210,170,140,255]:[90,50,35,255],(y*500+x)*4);
 assert.equal(sampleSkin({data,width:500,height:500},points)?.reliable,false);
 assert.throws(()=>nearestSkin([NaN,0,0],[]),/Invalid/);assert.throws(()=>nearestSkin([100,80,60],[]),/unavailable/);
});
test('suggested skin colors recolor the existing body and face without moving pixels or recoloring clothing',async()=>{
 const {decodePng}=await import('../../src/avatar/raster.js');
 const m=await collectionManifest(),features=suggestFaces(sample,m)[0];
 let referenceAlpha:number[]|undefined;
 for(const palette of m.skins){
  const c=applyFaceSuggestion(DEFAULT_COLLECTION,{...features,skin:palette.id as typeof DEFAULT_COLLECTION.skin});
  assert.equal(c.skin,palette.id);assert.deepEqual(c.wearColors,DEFAULT_COLLECTION.wearColors);assert.equal(c.hairColor,DEFAULT_COLLECTION.hairColor);
  const r=await renderCollection(validateCollection(c,m));assert.equal(r.warnings.length,0);
  const png=decodePng(r.png),alpha=Array.from({length:128*128},(_,i)=>png.pixel(i%128,Math.floor(i/128))[3]);
  if(referenceAlpha)assert.deepEqual(alpha,referenceAlpha,palette.id);else referenceAlpha=alpha;
 }
});

test('hair matching covers the whole catalog and separates close crops, long hair and large volume',async()=>{
 const {HAIR_PROFILES,matchHair,getHairProfiles}=await import('../../src/selfie/hair.js'),m=await collectionManifest();
 assert.deepEqual(getHairProfiles(m).map(p=>p.id).sort(),m.cosmetics.filter(c=>c.slot==='hair').map(c=>c.id).sort());
 for(const id of ['hair.buzz','hair.long','hair.afro','hair.bun','hair.side_bob']){
  const observation={metrics:HAIR_PROFILES.find(p=>p.id===id)!.traits,rgb:[37,37,43] as [number,number,number],reliable:true};
  const matches=matchHair(observation,m);assert.equal(matches.length,3);assert.equal(matches[0].id,id);assert.equal(matches[0].color,'hair.black');assert.deepEqual(matches,matchHair(observation,m));
  for(const hair of matches){const patch={...suggestFaces(sample,m)[0],hair:hair.id,hairColor:hair.color};assert.equal((await renderCollection(validateCollection(applyFaceSuggestion(DEFAULT_COLLECTION,patch),m))).warnings.length,0);}
 }
 assert.deepEqual(matchHair(null,m),[]);assert.deepEqual(matchHair({metrics:HAIR_PROFILES[0].traits,rgb:[80,50,30],reliable:false},m),[]);
});
test('hair segmentation samples only masked hair, excludes the background and distinguishes length',async()=>{
 const {measureHair}=await import('../../src/selfie/hair.js');
 const width=500,height=500,data=new Uint8ClampedArray(width*height*4),confidence=new Float32Array(width*height);
 for(let i=0;i<data.length;i+=4)data.set([230,50,170,255],i);
 const points=Array.from({length:478},()=>({x:.5,y:.5}));
 points[10]={x:.5,y:.3};points[152]={x:.5,y:.65};points[234]={x:.35,y:.45};points[454]={x:.65,y:.45};points[33]={x:.4,y:.4};points[263]={x:.6,y:.4};
 const fill=(x0:number,y0:number,x1:number,y1:number)=>{for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){confidence[y*width+x]=.99;data.set([37,37,43,255],(y*width+x)*4);}};
 fill(176,138,324,157);
 const short=measureHair({width,height,data},confidence,width,height,points);assert.ok(short?.reliable);assert.deepEqual(short.rgb,[37,37,43]);assert.equal(short.metrics.length,0);assert.ok(short.metrics.volume<.1);
 fill(145,140,169,470);fill(331,140,355,470);
 const long=measureHair({width,height,data},confidence,width,height,points);assert.ok(long?.reliable);assert.ok(long.metrics.length>.7);assert.deepEqual(long.rgb,[37,37,43]);
 confidence.fill(0);assert.equal(measureHair({width,height,data},confidence,width,height,points),null);
});
test('automatic hair choices apply with palette while preserving clothing and personal features',async()=>{
 const m=await collectionManifest(),original=structuredClone(DEFAULT_COLLECTION),patch={...suggestFaces(sample,m)[0],hair:'hair.buzz',hairColor:'hair.black' as const,skin:'skin_05' as const};
 const before=structuredClone(original),c=applyFaceSuggestion(original,patch);
 assert.equal(c.equipment.hair,'hair.buzz');assert.equal(c.hairColor,'hair.black');assert.equal(c.skin,'skin_05');assert.deepEqual(original,before);
 for(const slot of ['top','bottom','jacket','shoes','facialHair','freckles','ears'] as const)assert.equal(c.equipment[slot],original.equipment[slot]);
 assert.deepEqual(c.wearColors,original.wearColors);assert.deepEqual(c.wearAccentColors,original.wearAccentColors);validateCollection(c,m);
});

test('short neutral gray-black hair does not turn brown or become a bald crown or cornrows',async()=>{
 const {matchHair}=await import('../../src/selfie/hair.js'),m=await collectionManifest();
 const observation={metrics:{volume:.047,width:1.107,length:0,fringe:0,asymmetry:.061,texture:1,crown:.53,sideDepth:.45},rgb:[111,104,99] as [number,number,number],reliable:true,directionality:0};
 const choices=matchHair(observation,m);
 assert.ok(choices.every(c=>c.color==='hair.black'));
 assert.ok(choices.every(c=>!['hair.cornrows','hair.balding_crown','hair.long'].includes(c.id)));
 assert.ok(choices.some(c=>['hair.buzz','hair.mini_afro','hair.high_and_tight'].includes(c.id)),'Close-cropped hair stays among the short options as the catalog expands');
});
