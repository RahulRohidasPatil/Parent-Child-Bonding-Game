import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PNG} from 'pngjs';
import {AtelierConfigSchema,DEFAULT_ATELIER,SLOTS,validateAtelier} from '../../src/atelier/model.js';
import {atelierManifest,renderAtelier,atelierPresets} from '../../src/atelier/render.js';
import {validateCollection,randomConfiguration} from '../../scripts/avatar/validateAtelier.js';
import {AtelierHistory} from '../../src/atelier/history.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';

test('atelier production collection validates geometry, alpha, provenance and all skin variants',async()=>{const r=await validateCollection();assert.ok(r.cosmetics>=40);assert.equal(r.skins,12);});
test('atelier rejects unknown, mixed-slot and legacy configurations',async()=>{
 const m=await atelierManifest();assert.deepEqual(validateAtelier(DEFAULT_ATELIER,m),DEFAULT_ATELIER);
 assert.throws(()=>validateAtelier({...DEFAULT_ATELIER,equipment:{...DEFAULT_ATELIER.equipment,hair:'top.navy'}},m));
 assert.throws(()=>validateAtelier({...DEFAULT_ATELIER,equipment:{...DEFAULT_ATELIER.equipment,hair:'hair.unknown'}},m));
 assert.throws(()=>AtelierConfigSchema.parse({...DEFAULT_ATELIER,version:1}));assert.throws(()=>AtelierConfigSchema.parse({...DEFAULT_ATELIER,x:1}));
});
test('hair never covers the shared eye pixels or moves the body',async()=>{
 const m=await atelierManifest(),eye=m.cosmetics.find(a=>a.id==='eyes.neutral')!;
 const eyes=PNG.sync.read(await readFile('assets/avatar/atelier-r2/'+eye.layers[0].file));
 for(const h of m.cosmetics.filter(a=>a.slot==='hair'))for(const l of h.layers.filter(l=>l.z>20)){
   const p=PNG.sync.read(await readFile('assets/avatar/atelier-r2/'+l.file));
   for(let i=3;i<p.data.length;i+=4)assert.ok(!p.data[i]||!eyes.data[i],`${h.id} covers an eye at pixel ${Math.floor(i/4)}`);
 }
 const base=PNG.sync.read((await renderAtelier(DEFAULT_ATELIER)).png);
 for(const h of m.cosmetics.filter(a=>a.slot==='hair')){const p=PNG.sync.read((await renderAtelier({...DEFAULT_ATELIER,equipment:{...DEFAULT_ATELIER.equipment,hair:h.id}})).png);assert.deepEqual(p.data.subarray(60*128*4),base.data.subarray(60*128*4));}
});
test('shoes share the same foot baseline',async()=>{
 const m=await atelierManifest();for(const s of m.cosmetics.filter(a=>a.slot==='shoes')){const p=PNG.sync.read(await readFile('assets/avatar/atelier-r2/'+s.layers[0].file));let baseline=0;for(let i=3;i<p.data.length;i+=4)if(p.data[i])baseline=Math.max(baseline,Math.floor(i/4/128));assert.equal(baseline,120,s.id);}
});
test('long hair uses separate back and front layers and masks have declared targets',async()=>{
 const m=await atelierManifest();for(const id of ['hair.long','hair.bob','hair.braids']){const layers=m.cosmetics.find(a=>a.id===id)!.layers;assert.deepEqual(layers.map(l=>l.z),[10,60]);}
 for(const h of m.cosmetics.filter(a=>a.slot==='hat'))assert.deepEqual(h.layers[0].hide,['hair_front:hair_crown','hair_back:hair_crown']);
});
test('canonical hashes and render bytes survive property reordering',async()=>{
 const reverse=(o:Record<string,unknown>)=>Object.fromEntries(Object.entries(o).reverse());
 const a=await renderAtelier(DEFAULT_ATELIER),b=await renderAtelier({...reverse(DEFAULT_ATELIER),equipment:reverse(DEFAULT_ATELIER.equipment)});
 assert.equal(a.hash,b.hash);assert.deepEqual(a.png,b.png);
 assert.notEqual((await renderAtelier({...DEFAULT_ATELIER,equipment:{...DEFAULT_ATELIER.equipment,top:'top.quarter'}})).hash,a.hash);
 assert.equal((await renderAtelier(DEFAULT_ATELIER,['eyes','brows'])).hash,(await renderAtelier(DEFAULT_ATELIER,['brows','eyes','eyes'])).hash);
});
test('all top/jacket and hair/hat combinations render using valid layers',async()=>{
 const m=await atelierManifest();for(const [a,b] of [['top','jacket'],['hair','hat']] as const)for(const x of m.cosmetics.filter(c=>c.slot===a))for(const y of m.cosmetics.filter(c=>c.slot===b)){const r=await renderAtelier({...DEFAULT_ATELIER,equipment:{...DEFAULT_ATELIER.equipment,[a]:x.id,[b]:y.id}});assert.ok(r.png.length>100);}
 for(let i=0;i<100;i++)validateAtelier(randomConfiguration(m,i),m);for(const p of atelierPresets(DEFAULT_ATELIER))validateAtelier(p.config,m);
});
test('history restores nested equipment and clears only abandoned redo entries',()=>{
 const h=new AtelierHistory(DEFAULT_ATELIER),c=h.current;c.equipment.top='top.quarter';assert.equal(h.current.equipment.top,'top.navy');h.commit(c);h.undo();assert.equal(h.current.equipment.top,'top.navy');h.redo();assert.equal(h.current.equipment.top,'top.quarter');h.undo();h.commit({...DEFAULT_ATELIER,skin:'skin_12'});assert.equal(h.canRedo,false);
});
test('HTTP contract serves the actual 128 PNG, validates inputs, downloads and preserves legacy endpoint',async()=>{
 const server=createStudioServer();await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const address=server.address() as {port:number},url='http://127.0.0.1:'+address.port;
 try{const response=await fetch(url+'/api/atelier/render?download=1');assert.equal(response.status,200);assert.ok(response.headers.get('content-disposition')?.startsWith('attachment'));const p=PNG.sync.read(Buffer.from(await response.arrayBuffer()));assert.equal(p.width,128);assert.equal(p.height,128);
 assert.equal((await fetch(url+'/api/atelier/render?size=256')).status,400);
 assert.equal((await fetch(url+'/api/atelier/validate',{method:'POST',body:JSON.stringify({...DEFAULT_ATELIER,rig:'bad'})})).status,400);
 assert.equal((await fetch(url+'/api/studio/render')).status,200);
 const page=await (await fetch(url+'/avatar-studio')).text();assert.ok(page.includes('/dist/src/atelier/client.js'));assert.equal((await fetch(url+'/dist/src/atelier/client.js')).status,200);
 for(const slot of SLOTS)assert.ok((await atelierManifest()).cosmetics.some(a=>a.slot===slot));
 }finally{await new Promise<void>((r,e)=>server.close(err=>err?e(err):r()));}
});
