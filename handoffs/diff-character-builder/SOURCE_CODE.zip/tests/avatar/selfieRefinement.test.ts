import test from 'node:test';
import assert from 'node:assert/strict';
import {measureHair,matchHair} from '../../src/selfie/hair.js';
import {measureFacialHair} from '../../src/selfie/facialHair.js';
import {combinePhotos} from '../../src/selfie/aggregate.js';
import {applyFaceSuggestion,suggestFaces} from '../../src/selfie/matcher.js';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,validateCollection} from '../../src/collection/model.js';
import {readFile} from 'node:fs/promises';

test('hair texture measures relative contrast consistently across brightness and rejects background',()=>{
 const width=300,height=300,points=Array.from({length:478},()=>({x:.5,y:.5}));
 Object.assign(points,{10:{x:.5,y:.35},152:{x:.5,y:.75},234:{x:.3,y:.5},454:{x:.7,y:.5},33:{x:.37,y:.45},263:{x:.63,y:.45}});
 const confidence=new Float32Array(width*height),make=(brightness:number)=>{
  const data=new Uint8ClampedArray(width*height*4);
  for(let y=0;y<height;y++)for(let x=0;x<width;x++){const hair=y>35&&y<95&&x>80&&x<220;confidence[y*width+x]=hair?.99:0;const tone=hair?Math.round((50+((Math.floor(x/3)+Math.floor(y/3))%2)*20)*brightness):220;data.set([tone,tone,tone,255],(y*width+x)*4);}return measureHair({width,height,data},confidence,width,height,points)!;
 };
 const dark=make(.6),light=make(1.4);assert.ok(dark.reliable&&light.reliable);assert.ok(Math.abs(dark.metrics.texture-light.metrics.texture)<.02);assert.equal(dark.metrics.volume,light.metrics.volume);assert.ok(dark.rgb[0]<light.rgb[0]);
});

test('lip pixels alone do not create a mustache; bilateral hair above lips can produce a suggestion',()=>{
 const width=400,height=400,p=Array.from({length:478},()=>({x:.5,y:.5}));
 p[61]={x:.375,y:.55};p[291]={x:.625,y:.55};p[2]={x:.5,y:.43};p[0]={x:.5,y:.53};p[17]={x:.5,y:.59};p[152]={x:.5,y:.77};
 const data=new Uint8ClampedArray(width*height*4);for(let i=0;i<data.length;i+=4)data.set([180,130,100,255],i);
 const paint=(x0:number,y0:number,x1:number,y1:number)=>{for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++)data.set([50,40,30,255],(y*width+x)*4);};
 paint(150,213,250,236);assert.notEqual(measureFacialHair({width,height,data},p)?.kind,'mustache');
 paint(160,183,187,207);paint(213,183,240,207);assert.equal(measureFacialHair({width,height,data},p)?.kind,'mustache');
 assert.equal(measureFacialHair({width,height,data},p.slice(0,10)),null);
});

test('photo refinements remain renderable, offer distinct hair choices, and keep outfit geometry',async()=>{
 const m=await collectionManifest(),rows=JSON.parse(await readFile('artifacts/selfie/refinement/iteration-single.json','utf8'));
 for(const row of rows){const a=row.analysis.combined,choices=matchHair(a.hair,m);assert.equal(new Set(choices.map(c=>c.id)).size,3);
  for(const choice of choices){const config=validateCollection(applyFaceSuggestion(DEFAULT_COLLECTION,{...suggestFaces(a.metrics,m)[0],hair:choice.id,hairColor:choice.color}),m);assert.equal((await renderCollection(config)).warnings.length,0);for(const s of ['top','bottom','jacket','shoes'] as const)assert.equal(config.equipment[s],DEFAULT_COLLECTION.equipment[s]);}
 }
 const curls=rows.find((r:{id:string})=>r.id==='watkins').analysis.combined.hair;assert.ok(matchHair(curls,m).every(c=>!c.id.includes('receding')));
 const long=rows.find((r:{id:string})=>r.id==='williams').analysis.combined.hair;assert.ok(matchHair(long,m).some(c=>['hair.long','hair.curly_shoulder','hair.long_curls_sidepart'].includes(c.id)));
});

test('facial hair needs multi-photo agreement and explicit patches preserve other personal slots',async()=>{
 const m=await collectionManifest(),row=JSON.parse(await readFile('artifacts/selfie/refinement/iteration-single.json','utf8'))[0].analysis.combined;
 const mustache={kind:'mustache' as const,confidence:.8,upper:.4,lower:.04};
 assert.equal(combinePhotos([{...row,facialHair:mustache},{...row,facialHair:null}]).facialHair,null);
 assert.equal(combinePhotos([{...row,facialHair:mustache},{...row,facialHair:mustache},{...row,facialHair:null}]).facialHair?.kind,'mustache');
 const current=structuredClone(DEFAULT_COLLECTION);current.equipment.freckles=m.cosmetics.find(c=>c.slot==='freckles')!.id;
 const next=applyFaceSuggestion(current,{...suggestFaces(row.metrics,m)[0],facialHair:'facialHair.mustache'});validateCollection(next,m);assert.equal(next.equipment.facialHair,'facialHair.mustache');assert.equal(next.equipment.freckles,current.equipment.freckles);assert.equal(current.equipment.facialHair,null);
});
