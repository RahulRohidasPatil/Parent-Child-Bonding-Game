import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {createStudioServer} from '../../../scripts/avatar/previewServer.js';
import {createCollectionRenderer} from '../../../src/collection/render.js';
const folder='artifacts/avatar-hardening';await mkdir(folder,{recursive:true});
const stateFile=folder+'/recovery-mode.json';await writeFile(stateFile,JSON.stringify({mode:'error'}));
const root='assets/avatar/atelier-r6';const m=JSON.parse(await readFile(root+'/manifest.json','utf8'));
const failedFile=m.cosmetics.find((c:{id:string})=>c.id==='jacket.diff_track').layers.at(-1).file;
let mode='error';
const renderer=createCollectionRenderer(root,{loadFile:file=>file===failedFile&&mode==='missing'?Promise.reject(new Error('Injected missing jacket')):readFile(root+'/'+file),log:()=>{}});
const server=createStudioServer({collectionRender:async(config,hidden)=>{
 mode=JSON.parse(await readFile(stateFile,'utf8')).mode;
 if(mode==='error')throw new Error('Injected renderer outage');
 return renderer.render(config,hidden);
}});
server.listen(0,'127.0.0.1',()=>console.log(`Recovery fixture http://127.0.0.1:${(server.address() as {port:number}).port}/avatar-studio`));
