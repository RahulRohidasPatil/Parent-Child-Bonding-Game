import test from 'node:test';
import assert from 'node:assert/strict';
import { CHECKPOINT_VARIANTS } from '../../src/avatar/schema.js';
import { renderAvatar } from '../../src/avatar/renderer.js';
import { encodePng } from '../../src/avatar/raster.js';

test('same config always has the same hash and exact pixels', async () => {
  for (const config of Object.values(CHECKPOINT_VARIANTS)) {
    const first = await renderAvatar(config);
    const second = await renderAvatar(structuredClone(config));
    assert.equal(first.hash, second.hash);
    assert.deepEqual(encodePng(first.raster), encodePng(second.raster));
  }
});

test('renderer exposes only the locked 128×128 production resolution', async () => {
  for (const config of Object.values(CHECKPOINT_VARIANTS)) {
    const output = (await renderAvatar(config)).raster;
    assert.equal(output.width, 128); assert.equal(output.height, 128); assert.equal(output.partialAlphaPixels(), 0);
  }
});
