import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {atelierManifest,renderAtelier} from '../../src/atelier/render.js';
import {DEFAULT_ATELIER,validateAtelier} from '../../src/atelier/model.js';

test('face refinement leaves all 45 accepted non-face layer files unchanged',async()=>{
 const hashes=JSON.parse(await readFile('artifacts/avatar-atelier/qa/accepted-nonface-hashes.json','utf8')) as Record<string,string>;
 assert.equal(Object.keys(hashes).length,45);
 for(const [file,hash] of Object.entries(hashes))assert.equal(createHash('sha256').update(await readFile(file)).digest('hex'),hash,file);
});
test('every eye pair uses the smaller shared higher bounds and stays separate from the brows',async()=>{
 const m=await atelierManifest();for(const c of m.cosmetics.filter(c=>c.slot==='eyes')){
   const p=PNG.sync.read(await readFile('assets/avatar/atelier-r2/'+c.layers[0].file));let left=0,right=0;
   for(let y=0;y<128;y++)for(let x=0;x<128;x++)if(p.data[(y*128+x)*4+3]){assert.ok(x>=59&&x<69&&y>=19&&y<21,c.id);x<64?left++:right++;}
   assert.ok(left>0&&right>0);
   for(const brow of m.cosmetics.filter(c=>c.slot==='brows')){const b=PNG.sync.read(await readFile('assets/avatar/atelier-r2/'+brow.layers[0].file));for(let i=3;i<b.data.length;i+=4)assert.ok(!p.data[i]||!b.data[i]);}
 }
});
test('every hairstyle leaves every eye, brow, nose and mouth selection visible',async()=>{
 const m=await atelierManifest();for(const h of m.cosmetics.filter(c=>c.slot==='hair'))for(const layer of h.layers.filter(l=>l.z>20)){
  const p=PNG.sync.read(await readFile('assets/avatar/atelier-r2/'+layer.file));
  for(const c of m.cosmetics.filter(c=>['eyes','brows','nose','mouth'].includes(c.slot))){const f=PNG.sync.read(await readFile('assets/avatar/atelier-r2/'+c.layers[0].file));for(let i=3;i<p.data.length;i+=4)assert.ok(!p.data[i]||!f.data[i],`${h.id} overlaps ${c.id}`);}
 }
});
test('all skin and expression combinations render without changing the outfit',async()=>{
 const m=await atelierManifest(),reference=PNG.sync.read((await renderAtelier(DEFAULT_ATELIER)).png);
 for(const skin of m.skins)for(const eyes of m.cosmetics.filter(c=>c.slot==='eyes'))for(const mouth of m.cosmetics.filter(c=>c.slot==='mouth')){
   const r=PNG.sync.read((await renderAtelier({...DEFAULT_ATELIER,skin:skin.id as typeof DEFAULT_ATELIER.skin,equipment:{...DEFAULT_ATELIER.equipment,eyes:eyes.id,mouth:mouth.id}})).png);
   // The lower outfit has no exposed skin and must be exactly unchanged.
   assert.deepEqual(r.data.subarray(77*128*4),reference.data.subarray(77*128*4));
 }
});
test('a pre-nose saved configuration migrates only an empty optional slot',async()=>{
 const c=structuredClone(DEFAULT_ATELIER) as any;delete c.equipment.nose;
 assert.equal(validateAtelier(c,await atelierManifest()).equipment.nose,null);
});
