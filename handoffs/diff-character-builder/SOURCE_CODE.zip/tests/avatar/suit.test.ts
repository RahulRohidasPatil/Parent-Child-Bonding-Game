import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';
import {collectionManifest,renderCollection,renderCollectionLayer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,CollectionConfigSchema,collectionPresets,validateCollection} from '../../src/collection/model.js';
import {WEAR_COLOR_IDS} from '../../src/collection/wearPalettes.js';import {decodePng} from '../../src/avatar/raster.js';
const suit=()=>collectionPresets().find(p=>p.id==='suited')!.config;
test('suit uses independent Imagegen shirt, jacket and tie modules; old configs migrate to no tie',async()=>{
 const m=await collectionManifest();for(const id of ['top.dress_white','jacket.suit_charcoal','tie.classic']){const c=m.cosmetics.find(c=>c.id===id)!;assert.ok(c);assert.ok(c.layers.every(l=>l.source.startsWith('references/avatar-suit/')));}
 const {tie,...equipment}=DEFAULT_COLLECTION.equipment;const {tie:t,...wearColors}=DEFAULT_COLLECTION.wearColors;const {tie:a,...wearAccentColors}=DEFAULT_COLLECTION.wearAccentColors;const old={...DEFAULT_COLLECTION,equipment,wearColors,wearAccentColors};const parsed=CollectionConfigSchema.parse(old);assert.equal(parsed.equipment.tie,null);assert.equal(parsed.wearColors.tie,'wear.original');assert.deepEqual((await renderCollection(old)).png,(await renderCollection(DEFAULT_COLLECTION)).png);
 assert.throws(()=>validateCollection({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,tie:'tie.classic'}},m),/compatible shirt/);
});
test('shirt and suit jacket remain fixed white/charcoal under all palette choices',async()=>{
 const m=await collectionManifest();for(const slot of ['top','jacket'] as const){const c=suit(),base=await renderCollection(c),item=m.cosmetics.find(a=>a.id===c.equipment[slot])!;for(const color of WEAR_COLOR_IDS){const changed={...c,wearColors:{...c.wearColors,[slot]:color},wearAccentColors:{...c.wearAccentColors,[slot]:color}};assert.equal((await renderCollection(changed)).hash,base.hash);for(let i=0;i<item.layers.length;i++)assert.deepEqual(await renderCollectionLayer(changed,slot,i),await renderCollectionLayer(c,slot,i));}}
});
test('tie has eighteen distinct colors and cannot recolor the shirt, jacket or face',async()=>{
 const c=suit(),m=await collectionManifest(),item=m.cosmetics.find(c=>c.id==='tie.classic')!,layer=decodePng(await readFile('assets/avatar/atelier-r6/'+item.layers[0].file)),base=decodePng((await renderCollection(c)).png),colors=new Set<string>();
 for(const color of WEAR_COLOR_IDS){const result=await renderCollection({...c,wearColors:{...c.wearColors,tie:color}});assert.equal(result.warnings.length,0);colors.add(result.png.toString('base64'));const p=decodePng(result.png);for(let i=0;i<16384;i++)if(!layer.data[i*4+3])assert.deepEqual(p.data.subarray(i*4,i*4+4),base.data.subarray(i*4,i*4+4));}assert.equal(colors.size,18);
});
test('tie lies above shirt, below collar and jacket; removing it only changes its own pixels',async()=>{
 const c=suit(),m=await collectionManifest(),shirt=m.cosmetics.find(c=>c.id==='top.dress_white')!,tie=m.cosmetics.find(c=>c.id==='tie.classic')!,jacket=m.cosmetics.find(c=>c.id==='jacket.suit_charcoal')!;
 assert.ok(shirt.layers.some(l=>l.z<tie.layers[0].z&&l.z>=40));assert.ok(shirt.layers.some(l=>l.z>tie.layers[0].z));assert.ok(jacket.layers.some(l=>l.z>tie.layers[0].z));
 const full=decodePng((await renderCollection(c)).png),without=decodePng((await renderCollection({...c,equipment:{...c.equipment,tie:null}})).png),mask=decodePng(await renderCollectionLayer(c,'tie'));let visible=0;
 for(let i=0;i<16384;i++){const a=full.data.subarray(i*4,i*4+4),b=without.data.subarray(i*4,i*4+4);if(!Buffer.from(a).equals(Buffer.from(b))){visible++;assert.equal(mask.data[i*4+3],255);}}assert.ok(visible>=30,'Tie obscured by collar or lapels');
});
test('suit cuffs meet the canonical wrists and cover the arms within a narrower silhouette',async()=>{
 const m=await collectionManifest(),j=decodePng(await renderCollectionLayer(suit(),'jacket',1)),body=decodePng(await readFile('assets/avatar/atelier-r6/'+m.skins[1].layer.file)),ref=decodePng(await readFile('assets/avatar/atelier-r6/'+m.partitionMasks.top));
 const row=[];for(let x=0;x<128;x++)if(j.pixel(x,70)[3])row.push(x);assert.ok(row.at(-1)!-row[0]+1<=31,'Sleeves still too wide at wrists');
 for(let y=46;y<=70;y++)for(const [lo,hi]of [[43,54],[74,85]])for(let x=lo;x<=hi;x++)if(body.pixel(x,y)[3]&&ref.pixel(x,y)[3])assert.equal(j.pixel(x,y)[3],255,'Exposed arm at '+x+','+y);
 for(const [x,y]of [[54,71],[73,71]]){assert.equal(j.pixel(x,y-1)[3],255,'Cuff detached from wrist');assert.equal(j.pixel(x,y)[3],0,'Cuff covers hand');}
});
