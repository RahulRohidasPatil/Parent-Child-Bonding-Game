import test from 'node:test';
import assert from 'node:assert/strict';
import { ASSETS, assetFile } from '../../src/avatar/manifest.js';
import { SLOT_MASKS } from '../../src/avatar/rig.js';
import { readPng } from '../../src/avatar/raster.js';

test('every checkpoint layer is full-canvas RGBA with binary alpha and legal pixels', async () => {
  for (const asset of ASSETS) for (const color of asset.colors) {
    const image = await readPng(assetFile(asset, color));
    assert.equal(image.width, 128);
    assert.equal(image.height, 128);
    assert.equal(image.partialAlphaPixels(), 0);
    let opaque = 0;
    for (let y = 0; y < 128; y += 1) for (let x = 0; x < 128; x += 1) if (image.pixel(x, y)[3]) {
      opaque += 1;
      assert.ok(SLOT_MASKS[asset.slot].containsLogical(Math.floor(x / 2), Math.floor(y / 2)), `${asset.id} escaped ${asset.mask} at ${x},${y}`);
    }
    assert.ok(opaque > 0, asset.id);
  }
});
