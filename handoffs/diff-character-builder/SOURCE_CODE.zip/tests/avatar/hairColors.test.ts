import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {collectionManifest,renderCollection,renderCollectionLayer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,CollectionConfigSchema} from '../../src/collection/model.js';
import {HAIR_COLOR_IDS,HAIR_PALETTES,HAIR_COLOR_STYLE} from '../../src/collection/hairPalettes.js';
import {decodePng} from '../../src/avatar/raster.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';
const root='assets/avatar/atelier-r6/';

test('all hairstyles offer exactly twelve palettes and old configurations keep original brown',async()=>{
 const m=await collectionManifest();assert.equal(HAIR_COLOR_IDS.length,12);assert.equal(HAIR_PALETTES.length,12);assert.equal(new Set(HAIR_COLOR_IDS).size,12);
 assert.equal(m.cosmetics.filter(c=>c.slot==='hair').length,100);assert.ok(m.cosmetics.filter(c=>c.slot==='hair').every(c=>c.layers.every(l=>l.recolor)));
 assert.equal(m.cosmetics.find(c=>c.layers.some(l=>l.recolor))!.id,HAIR_COLOR_STYLE);
 const {hairColor,...legacy}=DEFAULT_COLLECTION;assert.equal(CollectionConfigSchema.parse(legacy).hairColor,'hair.original');
 assert.throws(()=>CollectionConfigSchema.parse({...DEFAULT_COLLECTION,hairColor:'hair.unknown'}));
 assert.deepEqual((await renderCollection(DEFAULT_COLLECTION)).png,await readFile(root+m.master));
});
test('all twelve colors retain geometry, protected outlines, face and clothing on every skin tone',async()=>{
 const m=await collectionManifest(),item=m.cosmetics.find(c=>c.id===HAIR_COLOR_STYLE)!,mask=decodePng(await readFile(root+item.layers[0].recolor!.mask));
 const hashes=new Set<string>();
 for(const skin of m.skins){const c={...DEFAULT_COLLECTION,skin:skin.id as typeof DEFAULT_COLLECTION.skin},original=decodePng((await renderCollection(c)).png);
  for(const hairColor of HAIR_COLOR_IDS){const result=await renderCollection({...c,hairColor}),p=decodePng(result.png);assert.equal(result.warnings.length,0);let changes=0;
   for(let y=0;y<128;y++)for(let x=0;x<128;x++){
    const a=original.pixel(x,y),b=p.pixel(x,y),role=mask.pixel(x,y);assert.equal(a[3],b[3]);
    if(!role[3]||!role[0])assert.deepEqual(b,a,'Protected pixel changed at '+x+','+y);
    if(b.some((v,i)=>v!==a[i]))changes++;
   }
   assert.equal(changes===0,hairColor==='hair.original');
   if(skin.id==='skin_02')hashes.add(createHash('sha256').update(result.png).digest('hex'));
  }
 }assert.equal(hashes.size,12);
});
test('hair colors are deterministic, mask correctly under hats, and do not affect an unequipped hairstyle',async()=>{
 const m=await collectionManifest();
 const a=await renderCollection({...DEFAULT_COLLECTION,hairColor:'hair.copper'}),b=await renderCollection({...DEFAULT_COLLECTION,hairColor:'hair.silver'}),c=await renderCollection({...DEFAULT_COLLECTION,hairColor:'hair.copper'});
 assert.deepEqual(a.png,c.png);assert.equal(a.hash,c.hash);assert.notEqual(a.hash,b.hash);
 for(const hair of [null]){
  const config={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hair}};
  assert.deepEqual(await renderCollection({...config,hairColor:'hair.original'}),await renderCollection({...config,hairColor:'hair.platinum'}));
 }
 for(const hat of m.cosmetics.filter(c=>c.slot==='hat')){const config={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hat:hat.id}};const original=decodePng((await renderCollection(config)).png);for(const hairColor of HAIR_COLOR_IDS){const p=decodePng((await renderCollection({...config,hairColor})).png);for(const l of hat.layers){const h=decodePng(await readFile(root+l.file));for(let i=0;i<16384;i++)if(h.data[i*4+3])assert.deepEqual(p.data.subarray(i*4,i*4+4),original.data.subarray(i*4,i*4+4));}}}
});
test('colored layer inspection returns the selected palette and rejects invalid component requests',async()=>{
 const server=createStudioServer();await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+(server.address() as {port:number}).port;
 try{
  const catalog=await(await fetch(base+'/api/collection/catalog')).json();assert.equal(catalog.hairColors.length,12);assert.equal(catalog.hairColorStyle,HAIR_COLOR_STYLE);
  const config={...DEFAULT_COLLECTION,hairColor:'hair.blonde' as const},query=new URLSearchParams({slot:'hair',index:'0',config:JSON.stringify(config)});
  const response=await fetch(base+'/api/collection/layer?'+query);assert.equal(response.status,200);assert.deepEqual(Buffer.from(await response.arrayBuffer()),await renderCollectionLayer(config,'hair',0));
  assert.equal((await fetch(base+'/api/collection/layer?slot=hair&index=99')).status,400);
 }finally{server.closeAllConnections();await new Promise<void>((r,e)=>server.close(err=>err?e(err):r()));}
});
