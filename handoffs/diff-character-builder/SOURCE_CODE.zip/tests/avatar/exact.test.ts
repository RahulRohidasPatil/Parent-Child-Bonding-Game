import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PNG} from 'pngjs';
import {createHash} from 'node:crypto';
import {exactManifest,renderExact} from '../../src/exact/render.js';
import {DEFAULT_EXACT,ExactConfigSchema,validateExact,EYE_COLORS,exactPresets} from '../../src/exact/model.js';
import {exactLayerFile} from '../../src/exact/assets.js';
import {DEFAULT_PORTRAIT} from '../../src/portrait/model.js';
import {validateExactPack,randomExact,checkPng} from '../../scripts/avatar/validateExact.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';
const root='assets/avatar/atelier-r5/';
const sha=(b:Uint8Array)=>createHash('sha256').update(b).digest('hex');

test('reference pack validates every file, mask, source and color variant',async()=>{
 const r=await validateExactPack();assert.equal(r.modules,50);assert.equal(r.heads,6);assert.equal(r.eyeColors,6);assert.equal(r.skins,12);
});
test('independent source partitions exactly reconstruct the frozen 128 reference',async()=>{
 const m=await exactManifest(),master=PNG.sync.read(await readFile(root+m.master)),out=Buffer.alloc(128*128*4),used=new Uint8Array(16384);
 for(const file of Object.values(m.partitionMasks)){const p=PNG.sync.read(await readFile(root+file));for(let i=0;i<16384;i++)if(p.data[i*4+3]){assert.equal(used[i],0,'Overlapping source partitions');used[i]=1;p.data.copy(out,i*4,i*4,i*4+4);}}
 assert.deepEqual(out,master.data);assert.deepEqual((await renderExact(DEFAULT_EXACT)).png,await readFile(root+m.master));
});
test('all eye colors keep whites, pupil shape and position; only two iris pixels change',async()=>{
 const m=await exactManifest();
 for(const eye of m.cosmetics.filter(c=>c.slot==='eyes')){
  const initial=PNG.sync.read(await readFile(root+exactLayerFile(eye.layers[0],DEFAULT_EXACT))),hashes=new Set<string>();
  for(const eyeColor of EYE_COLORS){const bytes=await readFile(root+exactLayerFile(eye.layers[0],{...DEFAULT_EXACT,eyeColor}));hashes.add(sha(bytes));const p=PNG.sync.read(bytes);let changes=0;
   for(let i=0;i<16384;i++){assert.equal(p.data[i*4+3],initial.data[i*4+3]);if(!p.data.subarray(i*4,i*4+4).equals(initial.data.subarray(i*4,i*4+4))){changes++;assert.ok(i===22*128+60||i===22*128+69,'Eye geometry/white changed');}}
   assert.equal(changes,eyeColor==='eye.dark_brown'?0:2);
  }assert.equal(hashes.size,6);
 }
});
test('eyes brows nose and mouth stay in separate, disjoint transparent layers',async()=>{
 const m=await exactManifest();for(const family of ['neutral','friendly','focused']){const used=new Uint8Array(16384);for(const slot of ['eyes','brows','nose','mouth']){const l=m.cosmetics.find(c=>c.id===`${slot}.reference_${family}`)!.layers[0],p=PNG.sync.read(await readFile(root+exactLayerFile(l,DEFAULT_EXACT)));for(let i=0;i<16384;i++)if(p.data[i*4+3]){assert.equal(used[i],0);used[i]=1;}}}
});
test('all head shapes attach through the same warm neck seam and retain skin geometry',async()=>{
 const m=await exactManifest(),shapes=new Set<string>();
 for(const h of m.cosmetics.filter(c=>c.slot==='head')){let alpha:Buffer|undefined;
  for(const file of Object.values(h.layers[0].skinVariants!)){const p=PNG.sync.read(await readFile(root+file)),a=Buffer.from(p.data.filter((_,i)=>i%4===3));if(alpha)assert.deepEqual(a,alpha);alpha=a;}
  shapes.add(sha(alpha!));const p=PNG.sync.read(await readFile(root+exactLayerFile(h.layers[0],DEFAULT_EXACT)));
  for(let x=60;x<=67;x++){const i=(33*128+x)*4;assert.equal(p.data[i+3],255);assert.ok(p.data[i]>90,'Near-black jaw bar returned');}
 }assert.equal(shapes.size,6);
 for(const h of m.cosmetics.filter(c=>c.slot==='head'))for(const t of m.cosmetics.filter(c=>c.slot==='top')){const p=PNG.sync.read((await renderExact({...DEFAULT_EXACT,equipment:{...DEFAULT_EXACT.equipment,head:h.id,top:t.id}})).png);for(let y=34;y<=37;y++)for(let x=60;x<=67;x++)assert.equal(p.data[(y*128+x)*4+3],255,'Neck gap');}
});
test('reference footwear belongs entirely to shoes, including ankle and heel pixels',async()=>{
 const m=await exactManifest(),p=PNG.sync.read(await readFile(root+m.partitionMasks.bottom)),master=PNG.sync.read(await readFile(root+m.master));
 for(let y=112;y<128;y++)for(let x=0;x<128;x++){const i=(y*128+x)*4;if(master.data[i+3]&&master.data[i+2]<=master.data[i]+7)assert.equal(p.data[i+3],0,'Reference shoe baked into trousers');}
});
test('one forbidden pixel fails validation and alpha cannot blur',async()=>{
 const m=await exactManifest(),l=m.cosmetics.find(c=>c.slot==='eyes')!.layers[0],p=PNG.sync.read(await readFile(root+l.file)),mask=PNG.sync.read(await readFile(root+m.slotMasks!.eyes));
 p.data.set([1,1,1,255],0);assert.throws(()=>checkPng(PNG.sync.write(p),'stray pixel',mask),/Forbidden pixel/);
 p.data.set([0,0,0,0],0);p.data[(20*128+58)*4+3]=128;assert.throws(()=>checkPng(PNG.sync.write(p),'soft edge',mask),/Partial alpha/);
});
test('schema, canonical hashes, presets and seeded random configuration are deterministic',async()=>{
 const m=await exactManifest();for(const c of [DEFAULT_PORTRAIT,{...DEFAULT_EXACT,x:1},{...DEFAULT_EXACT,eyeColor:'eye.neon'},{...DEFAULT_EXACT,rig:'front_idle_v1'}])assert.equal(ExactConfigSchema.safeParse(c).success,false);
 assert.throws(()=>validateExact({...DEFAULT_EXACT,equipment:{...DEFAULT_EXACT.equipment,eyes:'top.navy'}},m));
 const a=await renderExact(DEFAULT_EXACT),b=await renderExact(Object.fromEntries(Object.entries(DEFAULT_EXACT).reverse()));assert.equal(a.hash,b.hash);assert.deepEqual(a.png,b.png);
 for(const p of exactPresets())validateExact(p.config,m);for(let i=0;i<100;i++)assert.deepEqual(randomExact(m,i),randomExact(m,i));
});
test('HTTP serves reference and color-aware exports, source links, and preserves legacy APIs',async()=>{
 const server=createStudioServer();await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+(server.address() as {port:number}).port;
 try{const catalog=await(await fetch(base+'/api/exact/catalog')).json();assert.equal(catalog.eyeColors.length,6);
  const response=await fetch(base+'/api/exact/render?download=1');assert.equal(response.status,200);assert.match(response.headers.get('content-disposition')!,/attachment/);assert.deepEqual(Buffer.from(await response.arrayBuffer()),(await renderExact(DEFAULT_EXACT)).png);
  assert.equal((await fetch(base+'/api/exact/render?size=64')).status,400);
  assert.equal((await fetch(base+'/api/exact/validate',{method:'POST',body:JSON.stringify(DEFAULT_PORTRAIT)})).status,400);
  for(const endpoint of ['/api/portrait/render','/api/atelier/render','/api/studio/render','/references/avatar-exact-v5/body-reference.png','/dist/src/exact/assets.js'])assert.equal((await fetch(base+endpoint)).status,200,endpoint);
 }finally{await new Promise<void>((r,e)=>server.close(err=>err?e(err):r()));}
});
