import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {StudioConfigSchema,DEFAULT_STUDIO,PRESETS,activeAssetIds} from '../../src/studio/model.js';
import {StudioHistory} from '../../src/studio/history.js';
import {getStudioManifest,renderStudio} from '../../src/studio/render.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';

test('studio preserves its original Imagegen source files byte for byte',async()=>{
  const manifest=await getStudioManifest();for(const [path,expected] of Object.entries(manifest.sourceHashes))assert.equal(createHash('sha256').update(await readFile(path)).digest('hex'),expected,path);
});
test('studio layers are actual full-canvas RGBA8 files with no stray pixels',async()=>{
  const {assets}=await getStudioManifest();assert.equal(assets.length,26);
  for(const a of assets){const bytes=await readFile('assets/avatar/studio-r1/'+a.file);assert.equal(bytes[24],8);assert.equal(bytes[25],6);const png=PNG.sync.read(bytes);assert.equal(png.width,128);assert.equal(png.height,128);let opaque=0;
    for(let y=0;y<128;y++)for(let x=0;x<128;x++){const alpha=png.data[(y*128+x)*4+3];assert.ok(alpha===0||alpha===255);if(alpha){opaque++;assert.ok(x>=a.bounds[0]&&y>=a.bounds[1]&&x<=a.bounds[2]&&y<=a.bounds[3],`${a.id}: ${x},${y}`);}}
    assert.ok(opaque>0&&opaque<128*128,a.id);
  }
});
test('caps and beanies contain complete crowns instead of sparse differences',async()=>{
  for(const name of ['hat_cap','hat_beanie']){const img=PNG.sync.read(await readFile(`assets/avatar/studio-r1/${name}.png`));for(let y=7;y<=15;y++)for(let x=58;x<=70;x++)assert.equal(img.data[(y*128+x)*4+3],255,`${name} crown hole ${x},${y}`);}
});
test('every supported styled outfit combination renders deterministically at 128',async()=>{
  let count=0;
  for(const skin of ['skin_01','skin_02','skin_03','skin_04','skin_05','skin_06','skin_07','skin_08','skin_09','skin_10','skin_11','skin_12'])for(const hair of ['fluffy','long_wavy'])for(const hat of [null,'cap','beanie'])for(const jacket of [false,true])for(const bottom of ['straight','track'])for(const glasses of [false,true]){
    const c=StudioConfigSchema.parse({...DEFAULT_STUDIO,skin,hair,hat,jacket,bottom,glasses});const a=await renderStudio(c);const b=await renderStudio({...c});assert.equal(a.hash,b.hash);assert.deepEqual(a.png,b.png);const image=PNG.sync.read(a.png);assert.equal(image.width,128);assert.equal(image.height,128);assert.equal(a.layerIds.length,activeAssetIds(c).length);count++;
  }
  assert.equal(count,576);
});
test('base-only and layer inspection do not modify the saved outfit',async()=>{
  const c=structuredClone(DEFAULT_STUDIO);const full=await renderStudio(c);const without=await renderStudio(c,['top']);assert.notEqual(full.hash,without.hash);assert.deepEqual(c,DEFAULT_STUDIO);assert.deepEqual((await renderStudio(c)).png,full.png);
  const base={...c,hair:null,eyes:false,brows:false,mouth:false,top:false,jacket:false,bottom:null,shoes:false,hat:null,glasses:false};assert.deepEqual((await renderStudio(base)).layerIds,['body.skin_04']);
  await assert.rejects(()=>renderStudio(c,['invalid-layer']));
});
test('strict configs reject slot mistakes and do not accept legacy appearance silently',()=>{
  for(const invalid of [{...DEFAULT_STUDIO,hat:'hoodie'},{...DEFAULT_STUDIO,skin:'skin_99'},{...DEFAULT_STUDIO,x:1},{...DEFAULT_STUDIO,pack:'studio-r2'},{...DEFAULT_STUDIO,version:2}])assert.equal(StudioConfigSchema.safeParse(invalid).success,false);
});
test('undo redo reset and branching retain complete independent configurations',()=>{
  const h=new StudioHistory(DEFAULT_STUDIO);h.commit({...h.current,jacket:true});h.commit({...h.current,hat:'cap'});assert.equal(h.undo().hat,null);assert.equal(h.current.jacket,true);assert.equal(h.redo().hat,'cap');h.undo();h.commit({...h.current,glasses:true});assert.equal(h.canRedo,false);h.commit(DEFAULT_STUDIO);assert.equal(h.undo().glasses,true);const isolated=h.current;isolated.skin='skin_12';assert.equal(h.current.skin,'skin_04');
});
test('all curated looks pass the same renderer',async()=>{for(const p of PRESETS)assert.ok((await renderStudio(p.config)).png.length>100);});
test('HTTP serves the new interface and PNGs and rejects unsupported resolutions and paths',async()=>{
  const server=createStudioServer();await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const address=server.address() as {port:number};const base=`http://127.0.0.1:${address.port}`;
  try{
    for(const route of ['/','/avatar-studio','/dev/avatar-lab']){const response=await fetch(base+route);assert.equal(response.status,200);assert.match(await response.text(),/A little more you/);}
    const rendered=await fetch(base+'/api/studio/render',{method:'POST',body:JSON.stringify(DEFAULT_STUDIO)});assert.equal(rendered.status,200);assert.equal(rendered.headers.get('content-type'),'image/png');assert.equal(PNG.sync.read(Buffer.from(await rendered.arrayBuffer())).width,128);
    assert.equal((await fetch(base+'/api/studio/render?size=32')).status,400);
    assert.equal((await fetch(base+'/api/studio/render',{method:'POST',body:'{"version":900}'})).status,400);
    assert.equal((await fetch(base+'/api/studio/validate',{method:'POST',body:JSON.stringify(DEFAULT_STUDIO)})).status,200);
    assert.equal((await fetch(base+'/package.json')).status,404);assert.equal((await fetch(base+'/.git/config')).status,404);
    const sources=await fetch(base+'/api/studio/catalog');assert.equal(sources.status,200);const catalog=await sources.json();assert.equal(catalog.manifest.size,128);
  }finally{await new Promise<void>((resolve,reject)=>server.close(err=>err?reject(err):resolve()));}
});
