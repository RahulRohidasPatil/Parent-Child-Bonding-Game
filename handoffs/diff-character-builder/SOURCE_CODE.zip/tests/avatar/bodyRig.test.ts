import test from 'node:test';
import assert from 'node:assert/strict';
import { assetById, assetFile } from '../../src/avatar/manifest.js';
import { readPng } from '../../src/avatar/raster.js';

test('all twelve skins use one identical body alpha silhouette', async () => {
  const body = assetById('body.skin');
  const images = await Promise.all(body.colors.map((color) => readPng(assetFile(body, color))));
  for (let index = 1; index < images.length; index += 1) for (let offset = 3; offset < images[0].data.length; offset += 4) assert.equal(images[index].data[offset], images[0].data[offset], `${body.colors[index]} changed body geometry`);
});
