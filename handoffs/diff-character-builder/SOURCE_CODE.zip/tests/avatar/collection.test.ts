import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {PNG} from 'pngjs';
import {collectionManifest,renderCollection} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION,CollectionConfigSchema,collectionPresets,validateCollection} from '../../src/collection/model.js';
import {collectionLayerFile,canonicalVisualKey} from '../../src/collection/assets.js';
import {DEFAULT_EXACT} from '../../src/exact/model.js';
import {validateCollectionPack,randomCollection} from '../../scripts/avatar/validateCollection.js';
import {createStudioServer} from '../../scripts/avatar/previewServer.js';
import {decodePng} from '../../src/avatar/raster.js';
import {uncoveredPixels} from '../../src/collection/coverage.js';
import {shoulderCoverageMask} from '../../src/collection/authoring.js';
const ROOT='assets/avatar/atelier-r6/';

test('expanded pack has unique IDs, 50 additional Imagegen wearables, valid palettes and immutable inherited artwork',async()=>{
 const p=await validateCollectionPack();assert.equal(p.modules,270);assert.equal(p.clothing,113);assert.equal(p.heads,6);
 const m=await collectionManifest();assert.equal(new Set(m.cosmetics.map(c=>c.id)).size,270);
 for(const h of m.cosmetics.filter(c=>c.slot==='head'&&c.id!=='head.soft_oval'))assert.match(h.layers[0].source,/avatar-revision-v6\/head-/);
});
test('the approved complete base appearance remains pixel-for-pixel unchanged',async()=>{
 const result=await renderCollection(DEFAULT_COLLECTION);assert.deepEqual(result.png,await readFile('assets/avatar/atelier-r5/rig/reference_master.png'));
 const reordered=Object.fromEntries(Object.entries(DEFAULT_COLLECTION).reverse());assert.equal((await renderCollection(reordered)).hash,result.hash);
 assert.equal(canonicalVisualKey(reordered),canonicalVisualKey(DEFAULT_COLLECTION));
});
test('blank heads contain no residual eyes or brows in the interior eye band',async()=>{
 const m=await collectionManifest();for(const h of m.cosmetics.filter(c=>c.slot==='head')){
  const p=PNG.sync.read(await readFile(ROOT+collectionLayerFile(h.layers[0],DEFAULT_COLLECTION)));
  for(let y=18;y<=22;y++)for(let x=57;x<=70;x++){const i=(y*128+x)*4;assert.equal(p.data[i+3],255,h.id+' underlay hole');assert.ok(p.data[i]>170,h.id+' baked dark eye mark');}
 }
});
test('facial removal and inspector export select independent layers without changing configuration',async()=>{
 const original=structuredClone(DEFAULT_COLLECTION),full=await renderCollection(original);
 for(const slot of ['eyes','brows','nose','mouth','hair','ears']){const r=await renderCollection(original,[slot]);assert.notEqual(r.hash,full.hash);assert.notDeepEqual(r.png,full.png);}
 assert.deepEqual(original,DEFAULT_COLLECTION);await assert.rejects(()=>renderCollection(original,['unknown']));
});
test('the exposed forearm contains no inherited dark spur under short sleeves',async()=>{
 const m=await collectionManifest();for(const s of m.skins){const p=PNG.sync.read(await readFile(ROOT+s.layer.file));for(let y=65;y<70;y++)for(let x=45;x<50;x++)assert.equal(p.data[(y*128+x)*4+3],0);}
});
test('new clothes preserve different source silhouettes and open jacket centers',async()=>{
 const m=await collectionManifest(),alphas=new Set<string>();
 for(const top of m.cosmetics.filter(c=>c.slot==='top'&&c.layers.some(l=>l.source.includes('revision-v6')))){const p=PNG.sync.read(await readFile(ROOT+top.layers.at(-1)!.file));alphas.add(Buffer.from(p.data.filter((_,i)=>i%4===3)).toString('base64'));}
 assert.ok(alphas.size>=8,'New garments collapsed into one outline');
 for(const id of ['jacket.studio_bomber','jacket.light_denim','jacket.fleece','jacket.chore']){const p=PNG.sync.read(await readFile(ROOT+m.cosmetics.find(c=>c.id===id)!.layers.at(-1)!.file));for(let y=47;y<=65;y++)assert.equal(p.data[(y*128+64)*4+3],0,id+' baked center');}
});
test('every top and jacket covers the rig shoulders in front of the body',async()=>{
 const m=await collectionManifest(),mask=decodePng(await readFile(ROOT+m.coverageMasks!.shoulders));
 const body=decodePng(await readFile(ROOT+m.skins[1].layer.file)),reference=decodePng(await readFile(ROOT+m.partitionMasks.top));
 assert.deepEqual(mask.data,shoulderCoverageMask(body,reference).data);
 for(const item of m.cosmetics.filter(c=>c.slot==='top'||c.slot==='jacket')){
  const fronts=await Promise.all(item.layers.filter(l=>l.z>20).map(async l=>decodePng(await readFile(ROOT+l.file))));
  assert.deepEqual(uncoveredPixels(mask,fronts),[],item.id+' exposes shoulder skin');
 }
});
test('coverage validation detects a one-pixel shoulder hole and rear-layer misclassification',async()=>{
 const m=await collectionManifest(),mask=decodePng(await readFile(ROOT+m.coverageMasks!.shoulders));
 const item=m.cosmetics.find(c=>c.id==='top.oat_quarter')!,front=decodePng(await readFile(ROOT+item.layers.find(l=>l.region==='top')!.file));
 assert.equal(mask.pixel(53,37)[3],255);front.set(53,37,[0,0,0,0]);
 assert.deepEqual(uncoveredPixels(mask,[front]),[[53,37]]);
 assert.ok(uncoveredPixels(mask,[]).length>0,'Moving the entire shoulder layer behind the body must fail');
});
test('new configuration rejects incompatible versions/slots; random testing covers removal states',async()=>{
 const m=await collectionManifest();assert.equal(CollectionConfigSchema.safeParse(DEFAULT_EXACT).success,false);
 assert.throws(()=>validateCollection({...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,top:'eyes.reference_neutral'}},m));
 for(const p of collectionPresets())validateCollection(p.config,m);
 const none=new Set<string>();for(let seed=0;seed<500;seed++){const c=randomCollection(m,seed);validateCollection(c,m);for(const[s,id]of Object.entries(c.equipment))if(id===null)none.add(s);}
 for(const slot of ['eyes','brows','nose','mouth','hair','ears','top','bottom','shoes'])assert.ok(none.has(slot),slot+' None never tested');
});
test('HTTP export matches inspected preview; catalog and new source files are reachable',async()=>{
 const server=createStudioServer();await new Promise<void>(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+(server.address() as {port:number}).port;
 try{const cat=await(await fetch(base+'/api/collection/catalog')).json();assert.equal(cat.presets.length,9);assert.equal(cat.manifest.cosmetics.length,270);
  const response=await fetch(base+'/api/collection/render?download=1&hidden=eyes,nose');assert.equal(response.status,200);assert.match(response.headers.get('content-disposition')!,/attachment/);assert.deepEqual(Buffer.from(await response.arrayBuffer()),(await renderCollection(DEFAULT_COLLECTION,['eyes','nose'])).png);
  assert.equal((await fetch(base+'/api/collection/render?size=256')).status,400);
  for(const path of ['/dist/src/collection/assets.js','/references/avatar-revision-v6/head-round.png','/api/exact/render']){const r=await fetch(base+path);assert.equal(r.status,200);await r.arrayBuffer();}
 }finally{server.closeAllConnections();await new Promise<void>((r,e)=>server.close(err=>err?e(err):r()));}
});
