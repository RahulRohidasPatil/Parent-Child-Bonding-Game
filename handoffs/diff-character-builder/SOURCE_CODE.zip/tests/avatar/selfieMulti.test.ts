import test from 'node:test';
import assert from 'node:assert/strict';
import {combinePhotos,type PhotoAnalysis} from '../../src/selfie/aggregate.js';
import {HAIR_PROFILES} from '../../src/selfie/hair.js';
const sample:PhotoAnalysis={metrics:{aspect:1.3,jaw:.78,eyeOpen:.24,eyeTilt:.02,browArch:.16,browThickness:.035,noseWidth:.22,noseLength:.25,mouthWidth:.42,lipFullness:.18,smile:.05},skin:{rgb:[183,127,91],reliable:true},hair:{metrics:HAIR_PROFILES.find(p=>p.id==='hair.buzz')!.traits,rgb:[37,37,43],reliable:true,directionality:0}};
const changed=(values:Partial<PhotoAnalysis['metrics']>):PhotoAnalysis=>({...structuredClone(sample),metrics:{...sample.metrics,...values}});
test('multi-photo median limits a blinking/expression outlier and preserves the source observations',()=>{
 const photos=[changed({eyeOpen:.23,mouthWidth:.41}),changed({eyeOpen:.25,mouthWidth:.43}),changed({eyeOpen:.05,mouthWidth:.60})],before=structuredClone(photos),result=combinePhotos(photos);
 assert.equal(result.metrics.eyeOpen,.23);assert.equal(result.metrics.mouthWidth,.43);assert.deepEqual(result.used,[0,1,2]);assert.deepEqual(photos,before);
 assert.deepEqual(result.metrics,combinePhotos([...photos].reverse()).metrics);
});
test('an inconsistent geometry observation is excluded, but two contradictory photos are rejected',()=>{
 const bad=changed({aspect:1.9,jaw:.45,noseWidth:.39,noseLength:.39});
 const result=combinePhotos([sample,changed({aspect:1.32}),bad]);assert.deepEqual(result.used,[0,1]);assert.equal(result.warnings.length,1);
 assert.throws(()=>combinePhotos([sample,bad]),/differ too much/);
});
test('different haircuts and conflicting lighting do not synthesize a false average hairstyle or tone',()=>{
 const long=structuredClone(sample);long.hair!.metrics={...HAIR_PROFILES.find(p=>p.id==='hair.long')!.traits};long.skin!.rgb=[245,220,210];
 const result=combinePhotos([sample,long]);assert.equal(result.hair,null);assert.equal(result.skin?.reliable,false);assert.ok(result.warnings.length>=2);
 const differentColor=structuredClone(sample);differentColor.hair!.rgb=[230,210,180];assert.equal(combinePhotos([sample,differentColor]).hair?.reliable,false);
});
test('one valid photo stays usable, absent hair stays absent, and malformed batches fail',()=>{
 const result=combinePhotos([sample]);assert.deepEqual(result.metrics,sample.metrics);assert.deepEqual(result.skin,sample.skin);assert.deepEqual(result.hair,sample.hair);
 assert.equal(combinePhotos([{...sample,hair:null}]).hair,null);
 assert.throws(()=>combinePhotos([]),/one and three/);assert.throws(()=>combinePhotos([sample,sample,sample,sample]),/one and three/);assert.throws(()=>combinePhotos([changed({aspect:NaN})]),/Invalid/);
});
test('three exposure variants use their median tone instead of discarding a consistent estimate',()=>{
 const photos=[[228,158,121],[199,137,105],[251,178,138]].map(rgb=>({...structuredClone(sample),skin:{rgb:rgb as [number,number,number],reliable:true}}));
 const combined=combinePhotos(photos);assert.equal(combined.skin?.reliable,true);assert.deepEqual(combined.skin?.rgb,[228,158,121]);
});
