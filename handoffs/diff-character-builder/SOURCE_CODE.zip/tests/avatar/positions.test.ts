import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import {Raster,decodePng} from '../../src/avatar/raster.js';import {collectionManifest} from '../../src/collection/render.js';import {armCoverageGaps} from '../../src/collection/garmentPosition.js';
const root='assets/avatar/atelier-r6/';
test('all declared long sleeves cover the fixed arms and meet both hand anchors',async()=>{
 const m=await collectionManifest(),body=decodePng(await readFile(root+m.skins[1].layer.file)),ref=decodePng(await readFile(root+m.partitionMasks.top));
 for(const item of m.cosmetics.filter(c=>c.slot==='top'||c.slot==='jacket')){assert.ok(item.sleeveLength,item.id+' missing sleeve contract');if(item.sleeveLength==='short')continue;const r=new Raster(128,128);for(const l of item.layers.filter(l=>l.z>=20))r.blit(decodePng(await readFile(root+l.file)));assert.deepEqual(armCoverageGaps(r,body,ref),[],item.id);for(const x of [54,73])assert.equal(r.pixel(x,70)[3],255,item.id+' cuff is detached');}
});
test('all full-length trousers cover the canonical hip and leg silhouette',async()=>{
 const m=await collectionManifest(),body=decodePng(await readFile(root+m.skins[1].layer.file)),ref=decodePng(await readFile(root+m.partitionMasks.bottom));
 for(const item of m.cosmetics.filter(c=>c.slot==='bottom')){const r=decodePng(await readFile(root+item.layers[0].file));for(let y=77;y<=113;y++)for(let x=49;x<=80;x++)if(body.pixel(x,y)[3]&&ref.pixel(x,y)[3])assert.equal(r.pixel(x,y)[3],255,item.id+' misses leg '+x+','+y);}
});
test('all footwear keeps both feet on the same baseline with no tiny detached outsole fragments',async()=>{
 const m=await collectionManifest();for(const item of m.cosmetics.filter(c=>c.slot==='shoes')){const r=decodePng(await readFile(root+item.layers[0].file));for(const[lo,hi]of [[40,63],[64,88]]){let last=-1;for(let y=100;y<128;y++)for(let x=lo;x<=hi;x++)if(r.pixel(x,y)[3])last=Math.max(last,y);assert.equal(last,122,item.id);}
 const seen=new Set<number>();for(let i=0;i<16384;i++){if(!r.data[i*4+3]||seen.has(i))continue;const q=[i];seen.add(i);for(let n=0;n<q.length;n++){const x=q[n]%128,y=Math.floor(q[n]/128);for(let yy=y-1;yy<=y+1;yy++)for(let xx=x-1;xx<=x+1;xx++){const k=yy*128+xx;if(xx<0||xx>127||yy<0||yy>127||!r.pixel(xx,yy)[3]||seen.has(k))continue;seen.add(k);q.push(k);}}assert.ok(q.length>=4,item.id+' detached sole');}}
});
