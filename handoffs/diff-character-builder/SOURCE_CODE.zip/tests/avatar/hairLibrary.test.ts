import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {PNG} from 'pngjs';
import {createCollectionRenderer} from '../../src/collection/render.js';
import {DEFAULT_COLLECTION} from '../../src/collection/model.js';
import {HAIR_COLOR_IDS} from '../../src/collection/hairPalettes.js';
import {hairDetails} from '../../src/collection/hairCatalog.js';
import {decodePng} from '../../src/avatar/raster.js';
import {validateCollectionPack} from '../../scripts/avatar/validateCollection.js';
const root=process.env.HAIR_LIBRARY_ROOT??'assets/avatar/atelier-r6',renderer=createCollectionRenderer(root);
const sha=(bytes:Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
const jobs=JSON.parse(await readFile('references/avatar-hair-library/prompts.json','utf8')).jobs as {id:string;source:string;group:string;texture:string;fringe:string}[];

test('all 65 Imagegen modules are real sources and extend the catalog to 100 hairstyles',async()=>{
 const m=await renderer.manifest();assert.equal(jobs.length,65);assert.equal(new Set(jobs.map(j=>j.id)).size,65);assert.equal(m.cosmetics.filter(c=>c.slot==='hair').length,100);
 const geometry=new Set<string>();
 for(const job of jobs){const item=m.cosmetics.find(c=>c.id===job.id)!;assert.ok(item,job.id);const source='references/avatar-hair-library/'+job.source;assert.equal(sha(await readFile(source)),m.pictureHashes[source]);assert.ok(item.layers.every(l=>l.source===source));assert.equal(hairDetails(item).texture,job.texture);assert.equal(hairDetails(item).fringe,job.fringe);assert.ok(item.hairMatch);
  if(job.group!=='Short'){assert.ok(item.layers.some(l=>l.region==='hair_back'));assert.ok(item.layers.some(l=>l.region==='hair_front'));}
  geometry.add(sha(Buffer.concat(await Promise.all(item.layers.map(l=>readFile(root+'/'+l.file))))));
 }
 assert.equal(geometry.size,65,'Two items use identical compiled layers');await validateCollectionPack(root);
});
test('new layers are full-size binary-alpha sprites with no per-item runtime transform',async()=>{
 const m=await renderer.manifest();for(const job of jobs)for(const layer of m.cosmetics.find(c=>c.id===job.id)!.layers){
  const png=PNG.sync.read(await readFile(root+'/'+layer.file));assert.equal(png.width,128);assert.equal(png.height,128);assert.equal(png.colorType,6);
  assert.ok(Array.from(png.data).some((value,i)=>i%4===3&&value===0));for(let i=3;i<png.data.length;i+=4)assert.ok(png.data[i]===0||png.data[i]===255);
  for(const key of ['x','y','offset','offsetX','offsetY','translate','scale','rotation'])assert.ok(!(key in layer),job.id+' has '+key);
 }
});
test('every new hairstyle preserves the eye pixels and neck on every head shape',async()=>{
 const m=await renderer.manifest(),heads=m.cosmetics.filter(c=>c.slot==='head'),eyes=m.cosmetics.find(c=>c.id===DEFAULT_COLLECTION.equipment.eyes)!;
 const eyeMask=decodePng(await readFile(root+'/'+eyes.layers[0].file));
 for(const job of jobs)for(const head of heads){
  const c={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hair:job.id,head:head.id}},bare=decodePng((await renderer.render(c,['hair'])).png),rendered=await renderer.render(c),out=decodePng(rendered.png);assert.equal(rendered.warnings.length,0);
  for(let i=0;i<16384;i++)if(eyeMask.data[i*4+3])assert.deepEqual(out.data.subarray(i*4,i*4+4),bare.data.subarray(i*4,i*4+4),job.id+' hides an eye on '+head.id);
  for(let y=35;y<=37;y++)for(let x=60;x<=67;x++)assert.deepEqual(out.pixel(x,y),bare.pixel(x,y),job.id+' covers the central neck');
 }
});
test('all 65 hairstyles have twelve distinct colorways with identical alpha and unchanged non-hair pixels',async()=>{
 const m=await renderer.manifest();for(const job of jobs){const hair=m.cosmetics.find(c=>c.id===job.id)!,c={...DEFAULT_COLLECTION,equipment:{...DEFAULT_COLLECTION.equipment,hair:job.id}},original=decodePng((await renderer.render(c)).png),masks=await Promise.all(hair.layers.map(l=>readFile(root+'/'+l.recolor!.mask).then(decodePng))),variants=new Set<string>();
  for(const hairColor of HAIR_COLOR_IDS){const r=await renderer.render({...c,hairColor}),out=decodePng(r.png);assert.equal(r.warnings.length,0);variants.add(sha(r.png));
   for(let i=0;i<16384;i++){assert.equal(out.data[i*4+3],original.data[i*4+3],job.id);if(!masks.some(mask=>mask.data[i*4+3]&&mask.data[i*4]))assert.deepEqual(out.data.subarray(i*4,i*4+4),original.data.subarray(i*4,i*4+4),job.id+' recolors a protected pixel');}
  }assert.equal(variants.size,12,job.id);
 }
});
test('the existing pack images and approved default retain their exact original bytes',async()=>{
 const baseline=JSON.parse(await readFile('artifacts/avatar-hair-library/baseline-manifest.json','utf8'));
 for(const [file,hash]of Object.entries(baseline.compiledHashes))assert.equal(sha(await readFile(root+'/'+file)),hash,file);
 const m=await renderer.manifest();assert.deepEqual((await renderer.render(DEFAULT_COLLECTION)).png,await readFile(root+'/'+m.master));assert.equal(m.frozenDefaultHash,baseline.frozenDefaultHash);
});
